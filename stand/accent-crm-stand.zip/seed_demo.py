"""Наполнение демонстрационного стенда EspoCRM вымышленными данными.

Скрипт работает через REST API EspoCRM (v1) и учётную запись администратора.
Данные полностью вымышленные: реальные клиенты ООО «Акцент Плюс» не используются.

Запуск:
    python seed_demo.py --url http://localhost:8080 --user admin --password ...

Повторный запуск безопасен: объекты ищутся по имени и не дублируются.
"""
import argparse
import base64
import json
import sys
import urllib.error
import urllib.parse
import urllib.request

CASES = [
    ("Заказ документа: письмо Минфина о вычете по НДФЛ", "Question", "Normal",
     "Требуется текст письма Минфина России о порядке применения вычета по НДФЛ "
     "за 2025 год. В комплекте клиента документ отсутствует.", "В работе"),
    ("Сбой после обновления комплекта", "Incident", "High",
     "После еженедельного обновления система не запускается, выдается сообщение об "
     "ошибке базы. Работа пользователя остановлена.", "В работе"),
    ("Подключение модуля «Строительство»", "Question", "Normal",
     "Клиент просит подключить отраслевой модуль и рассчитать стоимость продления.",
     "Назначено"),
    ("Консультация: поиск по карточке документа", "Question", "Low",
     "Пользователь не находит документ по реквизитам, нужна консультация по поиску.",
     "Новое"),
    ("Запись на обучение: базовый курс", "Question", "Low",
     "Просят записать двух сотрудников на ближайший базовый курс в учебном центре.",
     "Назначено"),
    ("Восстановление доступа в личный кабинет", "Incident", "Normal",
     "Пользователь сменил почту и не может войти в личный кабинет.", "Закрыто"),
    ("Заказ архивного акта 2019 года", "Question", "Normal",
     "Нужен архивный документ, отсутствующий в информационном банке.", "Закрыто"),
    ("Ошибка при печати документа", "Incident", "Normal",
     "При печати документа из системы выводится пустая страница.", "В работе"),
    ("Продление подписки: расчет стоимости", "Question", "High",
     "Клиент просит расчет продления на 12 месяцев с учетом скидки за объем.",
     "Назначено"),
    ("Настройка обновления через интернет", "Question", "Normal",
     "Клиент перешел на обновление через интернет, нужна настройка расписания.",
     "Новое"),
    ("Перенос системы на новый компьютер", "Incident", "Normal",
     "Требуется перенос комплекта на новый рабочий компьютер с сохранением настроек.",
     "В работе"),
    ("Вопрос по применению статьи 54.1 НК РФ", "Question", "Normal",
     "Клиент просит подборку судебной практики по статье.", "В работе"),
    ("Ошибка входа: неверный пароль", "Incident", "Low",
     "Пользователь трижды ввел пароль, учетная запись заблокирована.", "Закрыто"),
    ("Заказ документа: постановление Правительства РБ", "Question", "Normal",
     "Нужен текст постановления регионального правительства.", "Закрыто"),
    ("Консультация по закупкам: 44-ФЗ", "Question", "Normal",
     "Вопрос по применению нормы закона о закупках в бюджетном учреждении.", "Назначено"),
    ("Обновление не устанавливается", "Incident", "High",
     "Обновление прерывается на середине, повторный запуск не помогает.", "В работе"),
    ("Запрос коммерческого предложения", "Question", "Normal",
     "Новая организация просит подобрать комплект для юриста и бухгалтера.",
     "Новое"),
    ("Настройка группового доступа", "Question", "Low",
     "Нужно открыть доступ к системе для второго сотрудника отдела.", "Назначено"),
    ("Повторное обращение: статус заявки", "Question", "Low",
     "Клиент уточняет срок выполнения ранее заказанного документа.", "Закрыто"),
    ("Сбой печати форм в комплекте «Кадровик»", "Incident", "Normal",
     "Формы печатаются без полей, настройки не сохраняются.", "В работе"),
    ("Обучение: профессиональный уровень", "Question", "Low",
     "Запрос на обучение по профессиональному уровню для главного бухгалтера.",
     "Новое"),
    ("Заказ судебной практики по банкротству", "Question", "Normal",
     "Нужна подборка практики арбитражных судов за последний год.", "В работе"),
    ("Восстановление базы после сбоя питания", "Incident", "High",
     "После отключения электроэнергии база не открывается.", "Назначено"),
    ("Консультация по региональному выпуску", "Question", "Low",
     "Вопрос о составе документов регионального выпуска.", "Закрыто"),
    ("Ошибка авторизации в онлайн-версии", "Incident", "Normal",
     "Онлайн-версия не принимает учетные данные, локальная работает.", "В работе"),
    ("Заказ документа: обзор изменений законодательства", "Question", "Low",
     "Просят ежемесячный обзор изменений для бухгалтерии.", "Новое"),
    ("Настройка резервного копирования базы", "Question", "Normal",
     "Клиент просит настроить автоматическое резервное копирование.", "Назначено"),
    ("Проблема с отображением таблиц", "Incident", "Normal",
     "Таблицы в документах отображаются некорректно после смены разрешения экрана.",
     "В работе"),
    ("Продление договора: согласование условий", "Question", "High",
     "Клиент согласовывает условия продления, нужен проект допсоглашения.",
     "Назначено"),
    ("Закрытие месяца: отчет по обращениям", "Question", "Low",
     "Запрос формы отчета по обращениям за квартал.", "Закрыто"),
]

ACCOUNTS = [
    "ООО «Северная логистика»",
    "АО «Уралстройпроект»",
    "ГБУЗ «Городская поликлиника № 5»",
    "ООО «БашАгроТрейд»",
    "МУП «Водоканал»",
    "ООО «Торговый дом Кама»",
    "АНО «Центр развития образования»",
    "ООО «Финанс-Аудит»",
]

STATUS_KEYS = {
    "Новое": "New",
    "Назначено": "Assigned",
    "В работе": "Pending",
    "Закрыто": "Closed",
}

USERS = [
    ("ivanova", "Иванова", "Анна", "Петровна", "Оператор приема"),
    ("sidorov", "Сидоров", "Максим", "Олегович", "Исполнитель"),
    ("kozlova", "Козлова", "Марина", "Сергеевна", "Исполнитель"),
    ("petrov", "Петров", "Игорь", "Викторович", "Руководитель сервисного отдела"),
]


class Api:
    def __init__(self, url, user, password):
        self.url = url.rstrip('/')
        token = base64.b64encode(f'{user}:{password}'.encode()).decode()
        self.headers = {
            'Authorization': 'Basic ' + token,
            'Content-Type': 'application/json',
            'Accept': 'application/json',
        }

    def request(self, method, path, payload=None):
        data = json.dumps(payload).encode('utf-8') if payload is not None else None
        req = urllib.request.Request(self.url + path, data=data, headers=self.headers,
                                     method=method)
        try:
            with urllib.request.urlopen(req) as resp:
                body = resp.read().decode('utf-8')
                return json.loads(body) if body else {}
        except urllib.error.HTTPError as e:
            detail = e.read().decode('utf-8', 'replace')
            raise RuntimeError(f'{method} {path} -> {e.code}: {detail[:400]}') from None

    def find(self, entity, name):
        """Поиск по имени среди первых 500 записей (фильтр на стороне клиента)."""
        res = self.request('GET', f'/api/v1/{entity}?maxSize=200&select=id,name')
        for item in res.get('list', []):
            if item.get('name') == name:
                return item['id']
        return None

    def find_user(self, login):
        res = self.request('GET', '/api/v1/User?maxSize=200&select=id,userName')
        for item in res.get('list', []):
            if item.get('userName') == login:
                return item['id']
        return None

    def create(self, entity, payload):
        return self.request('POST', f'/api/v1/{entity}', payload)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--url', default='http://localhost:8080')
    ap.add_argument('--user', default='admin')
    ap.add_argument('--password', required=True)
    args = ap.parse_args()

    api = Api(args.url, args.user, args.password)

    users = {}
    for login, last, first, middle, position in USERS:
        existing = api.find_user(login)
        if existing:
            users[login] = existing
            print('пользователь есть:', login)
            continue
        res = api.create('User', {
            'userName': login,
            'firstName': first,
            'lastName': last,
            'middleName': middle,
            'title': position,
            'password': 'Demo' + login.capitalize() + '2026!',
            'passwordConfirm': 'Demo' + login.capitalize() + '2026!',
            'type': 'regular',
            'isActive': True,
            'emailAddress': f'{login}@demo.akcentplus.ru',
        })
        users[login] = res['id']
        print('пользователь создан:', login)

    accounts = []
    for name in ACCOUNTS:
        existing = api.find('Account', name)
        if existing:
            accounts.append(existing)
            continue
        res = api.create('Account', {'name': name, 'type': 'Customer',
                                     'description': 'Демонстрационный клиент'})
        accounts.append(res['id'])
        print('клиент создан:', name)

    contacts = []
    for i, account in enumerate(accounts):
        name = f'Демо Клиент {i + 1}'
        existing = api.find('Contact', name)
        if existing:
            contacts.append(existing)
            continue
        res = api.create('Contact', {
            'firstName': 'Демо',
            'lastName': f'Клиент {i + 1}',
            'emailAddress': f'client{i + 1}@demo.akcentplus.ru',
            'accountId': account,
        })
        contacts.append(res['id'])

    executors = [users['sidorov'], users['kozlova'], users['ivanova']]
    for i, (name, ctype, priority, description, status) in enumerate(CASES):
        payload = {
            'name': name,
            'type': ctype,
            'priority': priority,
            'description': description,
            'status': STATUS_KEYS[status],
            'accountId': accounts[i % len(accounts)],
            'contactId': contacts[i % len(contacts)],
            'assignedUserId': executors[i % len(executors)],
        }
        api.create('Case', payload)

    print(f'обращений создано: {len(CASES)}')
    print('готово')


if __name__ == '__main__':
    sys.exit(main())
