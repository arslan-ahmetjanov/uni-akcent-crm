<?php
return [
  'version' => '10.1.1',
  'currencyRates' => [
    'USD' => 1.0
  ],
  'cacheTimestamp' => 1794734836,
  'microtimeState' => 1794734836.094319,
  'appTimestamp' => 1794733012
];
