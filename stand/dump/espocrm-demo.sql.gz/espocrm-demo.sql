-- MySQL dump 10.13  Distrib 8.0.46, for Linux (x86_64)
--
-- Host: localhost    Database: espocrm
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(249) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `industry` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sic_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_address_street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_address_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_address_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_address_country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `billing_address_postal_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address_street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address_country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address_postal_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_locked` tinyint NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_CREATED_AT` (`created_at`,`deleted`),
  KEY `IDX_NAME` (`name`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES ('05e7f68d108176fc6','ООО «БашАгроТрейд»',0,NULL,'Customer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Демонстрационный клиент',0,'2026-11-15 09:01:46','2026-11-15 09:01:46','2026-11-15 09:01:58',NULL,'2f1e0b7f89ae3c497',NULL,NULL,1),('31d97c49e066562c5','АО «Уралстройпроект»',0,NULL,'Customer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Демонстрационный клиент',0,'2026-11-15 09:01:45','2026-11-15 09:01:45','2026-11-15 09:01:58',NULL,'2f1e0b7f89ae3c497',NULL,NULL,1),('3fdff7c1df3e0d18d','ООО «Торговый дом Кама»',0,NULL,'Customer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Демонстрационный клиент',0,'2026-11-15 09:01:47','2026-11-15 09:01:47','2026-11-15 09:01:59',NULL,'2f1e0b7f89ae3c497',NULL,NULL,1),('5872ce100493fa929','АНО «Центр развития образования»',0,NULL,'Customer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Демонстрационный клиент',0,'2026-11-15 09:01:47','2026-11-15 09:01:47','2026-11-15 09:01:57',NULL,'2f1e0b7f89ae3c497',NULL,NULL,1),('69c3fae08cc458585','ООО «Финанс-Аудит»',0,NULL,'Customer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Демонстрационный клиент',0,'2026-11-15 09:01:48','2026-11-15 09:01:48','2026-11-15 09:01:57',NULL,'2f1e0b7f89ae3c497',NULL,NULL,1),('a8e74ae736347bba7','ООО «Северная логистика»',0,NULL,'Customer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Демонстрационный клиент',0,'2026-11-15 09:01:45','2026-11-15 09:01:45','2026-11-15 09:01:58',NULL,'2f1e0b7f89ae3c497',NULL,NULL,1),('aec01fbd5ffab15aa','ГБУЗ «Городская поликлиника № 5»',0,NULL,'Customer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Демонстрационный клиент',0,'2026-11-15 09:01:46','2026-11-15 09:01:46','2026-11-15 09:01:58',NULL,'2f1e0b7f89ae3c497',NULL,NULL,1),('cab96c889d6e86e00','МУП «Водоканал»',0,NULL,'Customer',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Демонстрационный клиент',0,'2026-11-15 09:01:47','2026-11-15 09:01:47','2026-11-15 09:01:59',NULL,'2f1e0b7f89ae3c497',NULL,NULL,1);
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_contact`
--

DROP TABLE IF EXISTS `account_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_contact` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_inactive` tinyint DEFAULT '0',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ACCOUNT_ID_CONTACT_ID` (`account_id`,`contact_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_contact`
--

LOCK TABLES `account_contact` WRITE;
/*!40000 ALTER TABLE `account_contact` DISABLE KEYS */;
INSERT INTO `account_contact` VALUES (1,'a8e74ae736347bba7','40e512e4ee76a1d4c',NULL,0,0),(2,'31d97c49e066562c5','cf75a49bf4fbdc950',NULL,0,0),(3,'aec01fbd5ffab15aa','869e5631ffd4bb052',NULL,0,0),(4,'05e7f68d108176fc6','7a846e2436bbb7f3b',NULL,0,0),(5,'cab96c889d6e86e00','1873952383da2a4ee',NULL,0,0),(6,'3fdff7c1df3e0d18d','026aa6805f059dd51',NULL,0,0),(7,'5872ce100493fa929','b6d2ca787bd9318ff',NULL,0,0),(8,'69c3fae08cc458585','d426d7e7c574ff1ad',NULL,0,0);
/*!40000 ALTER TABLE `account_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_document`
--

DROP TABLE IF EXISTS `account_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_document` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `document_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ACCOUNT_ID_DOCUMENT_ID` (`account_id`,`document_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_DOCUMENT_ID` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_document`
--

LOCK TABLES `account_document` WRITE;
/*!40000 ALTER TABLE `account_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_portal_user`
--

DROP TABLE IF EXISTS `account_portal_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_portal_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ID_ACCOUNT_ID` (`user_id`,`account_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_portal_user`
--

LOCK TABLES `account_portal_user` WRITE;
/*!40000 ALTER TABLE `account_portal_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_portal_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account_target_list`
--

DROP TABLE IF EXISTS `account_target_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account_target_list` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opted_out` tinyint DEFAULT '0',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ACCOUNT_ID_TARGET_LIST_ID` (`account_id`,`target_list_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account_target_list`
--

LOCK TABLES `account_target_list` WRITE;
/*!40000 ALTER TABLE `account_target_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_target_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `action_history_record`
--

DROP TABLE IF EXISTS `action_history_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `action_history_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `number` bigint unsigned NOT NULL AUTO_INCREMENT,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `ip_address` varchar(39) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_token_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_log_record_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_TARGET` (`target_type`,`target_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_AUTH_TOKEN_ID` (`auth_token_id`),
  KEY `IDX_AUTH_LOG_RECORD_ID` (`auth_log_record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `action_history_record`
--

LOCK TABLES `action_history_record` WRITE;
/*!40000 ALTER TABLE `action_history_record` DISABLE KEYS */;
INSERT INTO `action_history_record` VALUES ('067261b234d041187',0,49,'Case',NULL,'create','2026-11-15 09:01:58','172.18.0.1','a4be3e56e0ed0bef6','2f1e0b7f89ae3c497',NULL,'0a5a6e5443cc01132'),('084e881461c941e0d',0,36,'Case',NULL,'create','2026-11-15 09:01:55','172.18.0.1','dd4aee2c0aae367df','2f1e0b7f89ae3c497',NULL,'733e3130192979c1b'),('0f909bd79b0729d8c',0,14,'Account',NULL,'create','2026-11-15 09:01:47','172.18.0.1','5872ce100493fa929','2f1e0b7f89ae3c497',NULL,'3f20df51a51e984b8'),('166d5a7c7870f5b88',0,13,'Account',NULL,'create','2026-11-15 09:01:47','172.18.0.1','3fdff7c1df3e0d18d','2f1e0b7f89ae3c497',NULL,'2256c8104bfc8c5cd'),('18ce8abb105dcfcc8',0,21,'Contact',NULL,'create','2026-11-15 09:01:51','172.18.0.1','026aa6805f059dd51','2f1e0b7f89ae3c497',NULL,'7ac84089c79e8d275'),('19aeedcdb523aa620',0,30,'Case',NULL,'create','2026-11-15 09:01:53','172.18.0.1','cee9cbea77de54915','2f1e0b7f89ae3c497',NULL,'740aa1dbd5847d50d'),('1d998790d9a00647d',0,38,'Case',NULL,'create','2026-11-15 09:01:55','172.18.0.1','a0fb7b2f12bae0c77','2f1e0b7f89ae3c497',NULL,'4c7c832c898cc58e7'),('218b50f877325cdd3',0,35,'Case',NULL,'create','2026-11-15 09:01:54','172.18.0.1','a615cdfea165e8422','2f1e0b7f89ae3c497',NULL,'04bc4e62a0e74538d'),('2431aa888a77e6534',0,50,'Case',NULL,'create','2026-11-15 09:01:58','172.18.0.1','31008b4847f19f412','2f1e0b7f89ae3c497',NULL,'d02fb13aa8cb96cf7'),('2609e57fdcbec6c8e',0,44,'Case',NULL,'create','2026-11-15 09:01:57','172.18.0.1','ba3e914dd98685eb9','2f1e0b7f89ae3c497',NULL,'8739d7a4a7d97d94a'),('28083f184bce4ef6a',0,31,'Case',NULL,'create','2026-11-15 09:01:54','172.18.0.1','50e213c04e65df5a9','2f1e0b7f89ae3c497',NULL,'7b19976378048e2bb'),('2f18fb0868058884c',0,33,'Case',NULL,'create','2026-11-15 09:01:54','172.18.0.1','478a3e886297a7c29','2f1e0b7f89ae3c497',NULL,'3daa2902ba44a9335'),('3370036d2b61906fc',0,45,'Case',NULL,'create','2026-11-15 09:01:57','172.18.0.1','2df27f5cb9c6fa34b','2f1e0b7f89ae3c497',NULL,'cabcf3eefc8535de6'),('424f643c1de9643ed',0,24,'Case',NULL,'create','2026-11-15 09:01:52','172.18.0.1','65a60b6ec788951ef','2f1e0b7f89ae3c497',NULL,'22da96b3264ceca3e'),('523e51b580c8b9192',0,57,'Case',NULL,'read','2026-11-15 09:06:41','172.18.0.1','620a42f1842ce4dec','2f1e0b7f89ae3c497','246dadc96b9ad34a1','3b187aecd8a30e728'),('60664a8835d8ba067',0,12,'Account',NULL,'create','2026-11-15 09:01:47','172.18.0.1','cab96c889d6e86e00','2f1e0b7f89ae3c497',NULL,'c47d988cad0d78f7e'),('6168773770eec2924',0,9,'Account',NULL,'create','2026-11-15 09:01:45','172.18.0.1','31d97c49e066562c5','2f1e0b7f89ae3c497',NULL,'30040fdf7f900583c'),('63991acc29c23f048',0,3,'User',NULL,'create','2026-11-15 08:57:37','172.18.0.1','39ce8dc9b1c5e0553','2f1e0b7f89ae3c497',NULL,'45a00e7c5b250bf26'),('66924147813bf3a72',0,29,'Case',NULL,'create','2026-11-15 09:01:53','172.18.0.1','ded6744bf77097e3e','2f1e0b7f89ae3c497',NULL,'21e423c7f347568d7'),('67da7086f967f74fa',0,27,'Case',NULL,'create','2026-11-15 09:01:53','172.18.0.1','293246eb718f79a6d','2f1e0b7f89ae3c497',NULL,'043635092cef96463'),('699c68ff76e3e7824',0,18,'Contact',NULL,'create','2026-11-15 09:01:49','172.18.0.1','869e5631ffd4bb052','2f1e0b7f89ae3c497',NULL,'b1942a102bec65d51'),('74a907390a05b028b',0,26,'Case',NULL,'create','2026-11-15 09:01:52','172.18.0.1','3a9cf76b6672706d0','2f1e0b7f89ae3c497',NULL,'f22f30dd7fe4d0e5a'),('7aa65a501fce3fd30',0,8,'Account',NULL,'create','2026-11-15 09:01:45','172.18.0.1','a8e74ae736347bba7','2f1e0b7f89ae3c497',NULL,'844e6fd3b33231e1d'),('8a11e065b4ed16ced',0,10,'Account',NULL,'create','2026-11-15 09:01:46','172.18.0.1','aec01fbd5ffab15aa','2f1e0b7f89ae3c497',NULL,'66a779b5661f48907'),('92d5f718d87fc4692',0,17,'Contact',NULL,'create','2026-11-15 09:01:49','172.18.0.1','cf75a49bf4fbdc950','2f1e0b7f89ae3c497',NULL,'be4605c32b5c871ad'),('9648a256f99964914',0,39,'Case',NULL,'create','2026-11-15 09:01:55','172.18.0.1','1abc8152e84b9e536','2f1e0b7f89ae3c497',NULL,'c3dc4b5d6f0b01c5e'),('98d601b02d52070d9',0,51,'Case',NULL,'create','2026-11-15 09:01:58','172.18.0.1','e5856416d61b70d80','2f1e0b7f89ae3c497',NULL,'593eb2bb1e846adbf'),('9c9952877aac6a732',0,15,'Account',NULL,'create','2026-11-15 09:01:48','172.18.0.1','69c3fae08cc458585','2f1e0b7f89ae3c497',NULL,'8c87b99a89b3930ed'),('9c9e590fdb3112788',0,43,'Case',NULL,'create','2026-11-15 09:01:56','172.18.0.1','63b051e166f107916','2f1e0b7f89ae3c497',NULL,'78cdd8bac0f07a75a'),('9fca4b55bfe6135b4',0,54,'User',NULL,'delete','2026-11-15 09:02:23','172.18.0.1','7955b99c06cb6e2fa','2f1e0b7f89ae3c497',NULL,'7af87b3d2e37c04e4'),('a010def7ce9838f4c',0,20,'Contact',NULL,'create','2026-11-15 09:01:50','172.18.0.1','1873952383da2a4ee','2f1e0b7f89ae3c497',NULL,'8d2d9cef8ce8f5e03'),('a0eac2f42ea7b03e8',0,53,'Case',NULL,'create','2026-11-15 09:01:59','172.18.0.1','620a42f1842ce4dec','2f1e0b7f89ae3c497',NULL,'6b737b208b0bbc543'),('a1ca6386380ad254e',0,48,'Case',NULL,'create','2026-11-15 09:01:58','172.18.0.1','949eca0fe2cdc9e46','2f1e0b7f89ae3c497',NULL,'49a352b43dfbadb38'),('a2eac5a2f2efbd3fb',0,37,'Case',NULL,'create','2026-11-15 09:01:55','172.18.0.1','101571574991cdfcc','2f1e0b7f89ae3c497',NULL,'d7f97bebf97e63ae4'),('a9eda6fda3d159704',0,6,'User',NULL,'create','2026-11-15 08:58:33','172.18.0.1','3869dda69e6770c35','2f1e0b7f89ae3c497',NULL,'753f048bbcf99dfc1'),('ab9f1337482474fb3',0,34,'Case',NULL,'create','2026-11-15 09:01:54','172.18.0.1','b71d6f8aa3d764ec8','2f1e0b7f89ae3c497',NULL,'5cb2dc0da9338a962'),('adbb96545eade6f85',0,41,'Case',NULL,'create','2026-11-15 09:01:56','172.18.0.1','5ed5d7d94b82a7bf7','2f1e0b7f89ae3c497',NULL,'97b3c5f27dee8e847'),('afb34e990fd85fdcb',0,2,'User',NULL,'create','2026-11-15 08:57:36','172.18.0.1','ee34b5ae997ac8935','2f1e0b7f89ae3c497',NULL,'f64489a1986688291'),('b262679a365c0c6a4',0,47,'Case',NULL,'create','2026-11-15 09:01:57','172.18.0.1','0b93c4296977533fc','2f1e0b7f89ae3c497',NULL,'a33574021b82dc0de'),('ba908bbb81fe26e98',0,4,'User',NULL,'create','2026-11-15 08:57:38','172.18.0.1','b276a07c9d460eef6','2f1e0b7f89ae3c497',NULL,'f80843c175c7478d8'),('c0f6ced6bb3041590',0,19,'Contact',NULL,'create','2026-11-15 09:01:50','172.18.0.1','7a846e2436bbb7f3b','2f1e0b7f89ae3c497',NULL,'ccd37dd5c56aa1664'),('c18dd4b7528cf867a',0,25,'Case',NULL,'create','2026-11-15 09:01:52','172.18.0.1','7836722a11c884c82','2f1e0b7f89ae3c497',NULL,'d4c0b4fc6642ad8f3'),('c22453c15a6f1c304',0,46,'Case',NULL,'create','2026-11-15 09:01:57','172.18.0.1','3063a6cbfe0357f7c','2f1e0b7f89ae3c497',NULL,'5fc9a224852b79398'),('c6ebe159380863564',0,5,'User',NULL,'create','2026-11-15 08:58:17','172.18.0.1','7955b99c06cb6e2fa','2f1e0b7f89ae3c497',NULL,'f786777f2edb398df'),('cb1c7214af4922a8a',0,22,'Contact',NULL,'create','2026-11-15 09:01:51','172.18.0.1','b6d2ca787bd9318ff','2f1e0b7f89ae3c497',NULL,'c13a916db6ce3e9ba'),('cb5f67e2cc07e075f',0,11,'Account',NULL,'create','2026-11-15 09:01:46','172.18.0.1','05e7f68d108176fc6','2f1e0b7f89ae3c497',NULL,'e4991fa7bd16cece3'),('cced3bc5823b5f3a8',0,42,'Case',NULL,'create','2026-11-15 09:01:56','172.18.0.1','2f3391890e9cf8f07','2f1e0b7f89ae3c497',NULL,'81e19b6da176d7e98'),('d21f2881acebe4791',0,52,'Case',NULL,'create','2026-11-15 09:01:59','172.18.0.1','1e8e4646ff308f743','2f1e0b7f89ae3c497',NULL,'f57b99ab9d6e7dbad'),('e924e6f47b66f46e4',0,1,'User',NULL,'create','2026-11-15 08:57:36','172.18.0.1','5345f9133074952bc','2f1e0b7f89ae3c497',NULL,'7d21faffec0201109'),('f1a001351aa4f7c96',0,16,'Contact',NULL,'create','2026-11-15 09:01:48','172.18.0.1','40e512e4ee76a1d4c','2f1e0b7f89ae3c497',NULL,'9c3fdc00d3a1960d4'),('f689d09bad23f0dab',0,40,'Case',NULL,'create','2026-11-15 09:01:56','172.18.0.1','ec6704302761c2e15','2f1e0b7f89ae3c497',NULL,'1abeee93025a4eef5'),('f70900d7b5bc255f3',0,55,'User',NULL,'delete','2026-11-15 09:02:23','172.18.0.1','3869dda69e6770c35','2f1e0b7f89ae3c497',NULL,'f09b1bd71677fcd6c'),('f8a90c7f5d96786fb',0,32,'Case',NULL,'create','2026-11-15 09:01:54','172.18.0.1','8c493904f49418113','2f1e0b7f89ae3c497',NULL,'38c9e2a48bf789f27'),('f8e56be1a0968d3f2',0,23,'Contact',NULL,'create','2026-11-15 09:01:51','172.18.0.1','d426d7e7c574ff1ad','2f1e0b7f89ae3c497',NULL,'cdeeec40f3d0ae5a1'),('fb55b4b7414bffdd1',0,7,'User',NULL,'create','2026-11-15 08:58:34','172.18.0.1','969a2b32b83dc0060','2f1e0b7f89ae3c497',NULL,'850f9c39352cc9526'),('fd933afb63fe057b6',0,56,'User',NULL,'delete','2026-11-15 09:02:23','172.18.0.1','969a2b32b83dc0060','2f1e0b7f89ae3c497',NULL,'ae2bbefe10245bddc'),('fe4d7edab50ffc695',0,28,'Case',NULL,'create','2026-11-15 09:01:53','172.18.0.1','2218cde2db4d2f8c6','2f1e0b7f89ae3c497',NULL,'01bd89277ef8ceb4c');
/*!40000 ALTER TABLE `action_history_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `address_country`
--

DROP TABLE IF EXISTS `address_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `address_country` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_preferred` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NAME` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address_country`
--

LOCK TABLES `address_country` WRITE;
/*!40000 ALTER TABLE `address_country` DISABLE KEYS */;
/*!40000 ALTER TABLE `address_country` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_log_record`
--

DROP TABLE IF EXISTS `app_log_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_log_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `number` bigint unsigned NOT NULL AUTO_INCREMENT,
  `created_at` datetime DEFAULT NULL,
  `message` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `level` varchar(9) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` int DEFAULT NULL,
  `exception_class` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `line` int DEFAULT NULL,
  `request_method` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_resource_path` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_url` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_LEVEL` (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_log_record`
--

LOCK TABLES `app_log_record` WRITE;
/*!40000 ALTER TABLE `app_log_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_log_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `app_secret`
--

DROP TABLE IF EXISTS `app_secret`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `app_secret` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `delete_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NAME_DELETE_ID` (`name`,`delete_id`),
  KEY `IDX_NAME` (`name`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `app_secret`
--

LOCK TABLES `app_secret` WRITE;
/*!40000 ALTER TABLE `app_secret` DISABLE KEYS */;
/*!40000 ALTER TABLE `app_secret` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `array_value`
--

DROP TABLE IF EXISTS `array_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `array_value` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `value` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attribute` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ENTITY_TYPE_VALUE` (`entity_type`,`value`),
  KEY `IDX_ENTITY_VALUE` (`entity_type`,`entity_id`,`value`),
  KEY `IDX_ENTITY` (`entity_id`,`entity_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `array_value`
--

LOCK TABLES `array_value` WRITE;
/*!40000 ALTER TABLE `array_value` DISABLE KEYS */;
/*!40000 ALTER TABLE `array_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `attachment`
--

DROP TABLE IF EXISTS `attachment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `attachment` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` bigint DEFAULT NULL,
  `field` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_being_uploaded` tinyint NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `role` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `storage` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `storage_file_path` varchar(260) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `global` tinyint NOT NULL DEFAULT '0',
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_PARENT` (`parent_type`,`parent_id`),
  KEY `IDX_RELATED` (`related_id`,`related_type`),
  KEY `IDX_SOURCE` (`source_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `attachment`
--

LOCK TABLES `attachment` WRITE;
/*!40000 ALTER TABLE `attachment` DISABLE KEYS */;
/*!40000 ALTER TABLE `attachment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_log_record`
--

DROP TABLE IF EXISTS `auth_log_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_log_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `username` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `is_denied` tinyint NOT NULL DEFAULT '0',
  `denial_reason` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_time` double DEFAULT NULL,
  `request_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `request_method` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authentication_method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portal_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_token_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_IP_ADDRESS` (`ip_address`),
  KEY `IDX_IP_ADDRESS_REQUEST_TIME` (`ip_address`,`request_time`),
  KEY `IDX_REQUEST_TIME` (`request_time`),
  KEY `IDX_USERNAME_IP_ADDRESS` (`username`,`ip_address`),
  KEY `IDX_PORTAL_ID` (`portal_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_AUTH_TOKEN_ID` (`auth_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_log_record`
--

LOCK TABLES `auth_log_record` WRITE;
/*!40000 ALTER TABLE `auth_log_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_log_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_token`
--

DROP TABLE IF EXISTS `auth_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_token` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `token` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `hash` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secret` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `password_version` int NOT NULL DEFAULT '0',
  `last_access` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portal_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_TOKEN` (`token`,`deleted`),
  KEY `IDX_HASH` (`hash`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_PORTAL_ID` (`portal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_token`
--

LOCK TABLES `auth_token` WRITE;
/*!40000 ALTER TABLE `auth_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authentication_provider`
--

DROP TABLE IF EXISTS `authentication_provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authentication_provider` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_client_id` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_client_secret` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_authorization_endpoint` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_user_info_endpoint` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_token_endpoint` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_jwks_endpoint` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_jwt_signature_algorithm_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `oidc_scopes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `oidc_create_user` tinyint NOT NULL DEFAULT '0',
  `oidc_username_claim` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'sub',
  `oidc_sync` tinyint NOT NULL DEFAULT '0',
  `oidc_logout_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_authorization_prompt` varchar(14) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `oidc_authorization_pkce` tinyint NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authentication_provider`
--

LOCK TABLES `authentication_provider` WRITE;
/*!40000 ALTER TABLE `authentication_provider` DISABLE KEYS */;
/*!40000 ALTER TABLE `authentication_provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `autofollow`
--

DROP TABLE IF EXISTS `autofollow`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `autofollow` (
  `id` int NOT NULL AUTO_INCREMENT,
  `deleted` tinyint DEFAULT '0',
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ENTITY_TYPE` (`entity_type`),
  KEY `IDX_USER` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `autofollow`
--

LOCK TABLES `autofollow` WRITE;
/*!40000 ALTER TABLE `autofollow` DISABLE KEYS */;
/*!40000 ALTER TABLE `autofollow` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `call`
--

DROP TABLE IF EXISTS `call`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Planned',
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `direction` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Outbound',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `uid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_DATE_START_STATUS` (`date_start`,`status`),
  KEY `IDX_DATE_START` (`date_start`,`deleted`),
  KEY `IDX_STATUS` (`status`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_ASSIGNED_USER_STATUS` (`assigned_user_id`,`status`),
  KEY `IDX_UID` (`uid`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `call`
--

LOCK TABLES `call` WRITE;
/*!40000 ALTER TABLE `call` DISABLE KEYS */;
/*!40000 ALTER TABLE `call` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `call_contact`
--

DROP TABLE IF EXISTS `call_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_contact` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `call_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CALL_ID_CONTACT_ID` (`call_id`,`contact_id`),
  KEY `IDX_CALL_ID` (`call_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `call_contact`
--

LOCK TABLES `call_contact` WRITE;
/*!40000 ALTER TABLE `call_contact` DISABLE KEYS */;
/*!40000 ALTER TABLE `call_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `call_lead`
--

DROP TABLE IF EXISTS `call_lead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_lead` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `call_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lead_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CALL_ID_LEAD_ID` (`call_id`,`lead_id`),
  KEY `IDX_CALL_ID` (`call_id`),
  KEY `IDX_LEAD_ID` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `call_lead`
--

LOCK TABLES `call_lead` WRITE;
/*!40000 ALTER TABLE `call_lead` DISABLE KEYS */;
/*!40000 ALTER TABLE `call_lead` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `call_user`
--

DROP TABLE IF EXISTS `call_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `call_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `call_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ID_CALL_ID` (`user_id`,`call_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_CALL_ID` (`call_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `call_user`
--

LOCK TABLES `call_user` WRITE;
/*!40000 ALTER TABLE `call_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `call_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign`
--

DROP TABLE IF EXISTS `campaign`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Planning',
  `type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Email',
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `budget` double DEFAULT NULL,
  `mail_merge_only_with_address` tinyint NOT NULL DEFAULT '1',
  `budget_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contacts_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `leads_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `accounts_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `users_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_AT` (`created_at`,`deleted`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_CONTACTS_TEMPLATE_ID` (`contacts_template_id`),
  KEY `IDX_LEADS_TEMPLATE_ID` (`leads_template_id`),
  KEY `IDX_ACCOUNTS_TEMPLATE_ID` (`accounts_template_id`),
  KEY `IDX_USERS_TEMPLATE_ID` (`users_template_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign`
--

LOCK TABLES `campaign` WRITE;
/*!40000 ALTER TABLE `campaign` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_log_record`
--

DROP TABLE IF EXISTS `campaign_log_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign_log_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `action` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action_date` datetime DEFAULT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `string_data` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `string_additional_data` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `application` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Espo',
  `created_at` datetime DEFAULT NULL,
  `is_test` tinyint NOT NULL DEFAULT '0',
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `object_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `object_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `queue_item_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ACTION_DATE` (`action_date`,`deleted`),
  KEY `IDX_ACTION` (`action`,`deleted`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_OBJECT` (`object_id`,`object_type`),
  KEY `IDX_QUEUE_ITEM_ID` (`queue_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_log_record`
--

LOCK TABLES `campaign_log_record` WRITE;
/*!40000 ALTER TABLE `campaign_log_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign_log_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_target_list`
--

DROP TABLE IF EXISTS `campaign_target_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign_target_list` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CAMPAIGN_ID_TARGET_LIST_ID` (`campaign_id`,`target_list_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_target_list`
--

LOCK TABLES `campaign_target_list` WRITE;
/*!40000 ALTER TABLE `campaign_target_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign_target_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_target_list_excluding`
--

DROP TABLE IF EXISTS `campaign_target_list_excluding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign_target_list_excluding` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CAMPAIGN_ID_TARGET_LIST_ID` (`campaign_id`,`target_list_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_target_list_excluding`
--

LOCK TABLES `campaign_target_list_excluding` WRITE;
/*!40000 ALTER TABLE `campaign_target_list_excluding` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign_target_list_excluding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `campaign_tracking_url`
--

DROP TABLE IF EXISTS `campaign_tracking_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `campaign_tracking_url` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Redirect',
  `message` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `modified_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `campaign_tracking_url`
--

LOCK TABLES `campaign_tracking_url` WRITE;
/*!40000 ALTER TABLE `campaign_tracking_url` DISABLE KEYS */;
/*!40000 ALTER TABLE `campaign_tracking_url` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `case`
--

DROP TABLE IF EXISTS `case`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `number` int unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'New',
  `priority` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Normal',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_internal` tinyint NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lead_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inbound_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_STATUS` (`status`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_ASSIGNED_USER_STATUS` (`assigned_user_id`,`status`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_LEAD_ID` (`lead_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_INBOUND_EMAIL_ID` (`inbound_email_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  FULLTEXT KEY `IDX_SYSTEM_FULL_TEXT_SEARCH` (`name`,`description`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case`
--

LOCK TABLES `case` WRITE;
/*!40000 ALTER TABLE `case` DISABLE KEYS */;
INSERT INTO `case` VALUES ('0b93c4296977533fc','Консультация по региональному выпуску',0,24,'Closed','Low','Question','Вопрос о составе документов регионального выпуска.',0,'2026-11-15 09:01:57','2026-11-15 09:01:57','2026-11-15 09:01:57','69c3fae08cc458585',NULL,'d426d7e7c574ff1ad',NULL,'2f1e0b7f89ae3c497',NULL,'5345f9133074952bc',1),('101571574991cdfcc','Заказ документа: постановление Правительства РБ',0,14,'Closed','Normal','Question','Нужен текст постановления регионального правительства.',0,'2026-11-15 09:01:55','2026-11-15 09:01:55','2026-11-15 09:01:55','3fdff7c1df3e0d18d',NULL,'026aa6805f059dd51',NULL,'2f1e0b7f89ae3c497',NULL,'39ce8dc9b1c5e0553',1),('1abc8152e84b9e536','Обновление не устанавливается',0,16,'Pending','High','Incident','Обновление прерывается на середине, повторный запуск не помогает.',0,'2026-11-15 09:01:55','2026-11-15 09:01:55','2026-11-15 09:01:55','69c3fae08cc458585',NULL,'d426d7e7c574ff1ad',NULL,'2f1e0b7f89ae3c497',NULL,'ee34b5ae997ac8935',1),('1e8e4646ff308f743','Продление договора: согласование условий',0,29,'Assigned','High','Question','Клиент согласовывает условия продления, нужен проект допсоглашения.',0,'2026-11-15 09:01:59','2026-11-15 09:01:59','2026-11-15 09:01:59','cab96c889d6e86e00',NULL,'1873952383da2a4ee',NULL,'2f1e0b7f89ae3c497',NULL,'39ce8dc9b1c5e0553',1),('2218cde2db4d2f8c6','Запись на обучение: базовый курс',0,5,'Assigned','Low','Question','Просят записать двух сотрудников на ближайший базовый курс в учебном центре.',0,'2026-11-15 09:01:53','2026-11-15 09:01:53','2026-11-15 09:01:53','cab96c889d6e86e00',NULL,'1873952383da2a4ee',NULL,'2f1e0b7f89ae3c497',NULL,'39ce8dc9b1c5e0553',1),('293246eb718f79a6d','Консультация: поиск по карточке документа',0,4,'New','Low','Question','Пользователь не находит документ по реквизитам, нужна консультация по поиску.',0,'2026-11-15 09:01:52','2026-11-15 09:01:52','2026-11-15 09:01:52','05e7f68d108176fc6',NULL,'7a846e2436bbb7f3b',NULL,'2f1e0b7f89ae3c497',NULL,'ee34b5ae997ac8935',1),('2df27f5cb9c6fa34b','Заказ судебной практики по банкротству',0,22,'Pending','Normal','Question','Нужна подборка практики арбитражных судов за последний год.',0,'2026-11-15 09:01:57','2026-11-15 09:01:57','2026-11-15 09:01:57','3fdff7c1df3e0d18d',NULL,'026aa6805f059dd51',NULL,'2f1e0b7f89ae3c497',NULL,'ee34b5ae997ac8935',1),('2f3391890e9cf8f07','Повторное обращение: статус заявки',0,19,'Closed','Low','Question','Клиент уточняет срок выполнения ранее заказанного документа.',0,'2026-11-15 09:01:56','2026-11-15 09:01:56','2026-11-15 09:01:56','aec01fbd5ffab15aa',NULL,'869e5631ffd4bb052',NULL,'2f1e0b7f89ae3c497',NULL,'ee34b5ae997ac8935',1),('3063a6cbfe0357f7c','Восстановление базы после сбоя питания',0,23,'Assigned','High','Incident','После отключения электроэнергии база не открывается.',0,'2026-11-15 09:01:57','2026-11-15 09:01:57','2026-11-15 09:01:57','5872ce100493fa929',NULL,'b6d2ca787bd9318ff',NULL,'2f1e0b7f89ae3c497',NULL,'39ce8dc9b1c5e0553',1),('31008b4847f19f412','Настройка резервного копирования базы',0,27,'Assigned','Normal','Question','Клиент просит настроить автоматическое резервное копирование.',0,'2026-11-15 09:01:58','2026-11-15 09:01:58','2026-11-15 09:01:58','aec01fbd5ffab15aa',NULL,'869e5631ffd4bb052',NULL,'2f1e0b7f89ae3c497',NULL,'5345f9133074952bc',1),('3a9cf76b6672706d0','Подключение модуля «Строительство»',0,3,'Assigned','Normal','Question','Клиент просит подключить отраслевой модуль и рассчитать стоимость продления.',0,'2026-11-15 09:01:52','2026-11-15 09:01:52','2026-11-15 09:01:52','aec01fbd5ffab15aa',NULL,'869e5631ffd4bb052',NULL,'2f1e0b7f89ae3c497',NULL,'5345f9133074952bc',1),('478a3e886297a7c29','Настройка обновления через интернет',0,10,'New','Normal','Question','Клиент перешел на обновление через интернет, нужна настройка расписания.',0,'2026-11-15 09:01:54','2026-11-15 09:01:54','2026-11-15 09:01:54','31d97c49e066562c5',NULL,'cf75a49bf4fbdc950',NULL,'2f1e0b7f89ae3c497',NULL,'ee34b5ae997ac8935',1),('50e213c04e65df5a9','Ошибка при печати документа',0,8,'Pending','Normal','Incident','При печати документа из системы выводится пустая страница.',0,'2026-11-15 09:01:53','2026-11-15 09:01:53','2026-11-15 09:01:53','69c3fae08cc458585',NULL,'d426d7e7c574ff1ad',NULL,'2f1e0b7f89ae3c497',NULL,'39ce8dc9b1c5e0553',1),('5ed5d7d94b82a7bf7','Настройка группового доступа',0,18,'Assigned','Low','Question','Нужно открыть доступ к системе для второго сотрудника отдела.',0,'2026-11-15 09:01:56','2026-11-15 09:01:56','2026-11-15 09:01:56','31d97c49e066562c5',NULL,'cf75a49bf4fbdc950',NULL,'2f1e0b7f89ae3c497',NULL,'5345f9133074952bc',1),('620a42f1842ce4dec','Закрытие месяца: отчет по обращениям',0,30,'Closed','Low','Question','Запрос формы отчета по обращениям за квартал.',0,'2026-11-15 09:01:59','2026-11-15 09:01:59','2026-11-15 09:01:59','3fdff7c1df3e0d18d',NULL,'026aa6805f059dd51',NULL,'2f1e0b7f89ae3c497',NULL,'5345f9133074952bc',1),('63b051e166f107916','Сбой печати форм в комплекте «Кадровик»',0,20,'Pending','Normal','Incident','Формы печатаются без полей, настройки не сохраняются.',0,'2026-11-15 09:01:56','2026-11-15 09:01:56','2026-11-15 09:01:56','05e7f68d108176fc6',NULL,'7a846e2436bbb7f3b',NULL,'2f1e0b7f89ae3c497',NULL,'39ce8dc9b1c5e0553',1),('65a60b6ec788951ef','Заказ документа: письмо Минфина о вычете по НДФЛ',0,1,'Pending','Normal','Question','Требуется текст письма Минфина России о порядке применения вычета по НДФЛ за 2025 год. В комплекте клиента документ отсутствует.',0,'2026-11-15 09:01:52','2026-11-15 09:01:52','2026-11-15 09:01:52','a8e74ae736347bba7',NULL,'40e512e4ee76a1d4c',NULL,'2f1e0b7f89ae3c497',NULL,'ee34b5ae997ac8935',1),('7836722a11c884c82','Сбой после обновления комплекта',0,2,'Pending','High','Incident','После еженедельного обновления система не запускается, выдается сообщение об ошибке базы. Работа пользователя остановлена.',0,'2026-11-15 09:01:52','2026-11-15 09:01:52','2026-11-15 09:01:52','31d97c49e066562c5',NULL,'cf75a49bf4fbdc950',NULL,'2f1e0b7f89ae3c497',NULL,'39ce8dc9b1c5e0553',1),('8c493904f49418113','Продление подписки: расчет стоимости',0,9,'Assigned','High','Question','Клиент просит расчет продления на 12 месяцев с учетом скидки за объем.',0,'2026-11-15 09:01:54','2026-11-15 09:01:54','2026-11-15 09:01:54','a8e74ae736347bba7',NULL,'40e512e4ee76a1d4c',NULL,'2f1e0b7f89ae3c497',NULL,'5345f9133074952bc',1),('949eca0fe2cdc9e46','Ошибка авторизации в онлайн-версии',0,25,'Pending','Normal','Incident','Онлайн-версия не принимает учетные данные, локальная работает.',0,'2026-11-15 09:01:58','2026-11-15 09:01:58','2026-11-15 09:01:58','a8e74ae736347bba7',NULL,'40e512e4ee76a1d4c',NULL,'2f1e0b7f89ae3c497',NULL,'ee34b5ae997ac8935',1),('a0fb7b2f12bae0c77','Консультация по закупкам: 44-ФЗ',0,15,'Assigned','Normal','Question','Вопрос по применению нормы закона о закупках в бюджетном учреждении.',0,'2026-11-15 09:01:55','2026-11-15 09:01:55','2026-11-15 09:01:55','5872ce100493fa929',NULL,'b6d2ca787bd9318ff',NULL,'2f1e0b7f89ae3c497',NULL,'5345f9133074952bc',1),('a4be3e56e0ed0bef6','Заказ документа: обзор изменений законодательства',0,26,'New','Low','Question','Просят ежемесячный обзор изменений для бухгалтерии.',0,'2026-11-15 09:01:58','2026-11-15 09:01:58','2026-11-15 09:01:58','31d97c49e066562c5',NULL,'cf75a49bf4fbdc950',NULL,'2f1e0b7f89ae3c497',NULL,'39ce8dc9b1c5e0553',1),('a615cdfea165e8422','Вопрос по применению статьи 54.1 НК РФ',0,12,'Pending','Normal','Question','Клиент просит подборку судебной практики по статье.',0,'2026-11-15 09:01:54','2026-11-15 09:01:54','2026-11-15 09:01:54','05e7f68d108176fc6',NULL,'7a846e2436bbb7f3b',NULL,'2f1e0b7f89ae3c497',NULL,'5345f9133074952bc',1),('b71d6f8aa3d764ec8','Перенос системы на новый компьютер',0,11,'Pending','Normal','Incident','Требуется перенос комплекта на новый рабочий компьютер с сохранением настроек.',0,'2026-11-15 09:01:54','2026-11-15 09:01:54','2026-11-15 09:01:54','aec01fbd5ffab15aa',NULL,'869e5631ffd4bb052',NULL,'2f1e0b7f89ae3c497',NULL,'39ce8dc9b1c5e0553',1),('ba3e914dd98685eb9','Обучение: профессиональный уровень',0,21,'New','Low','Question','Запрос на обучение по профессиональному уровню для главного бухгалтера.',0,'2026-11-15 09:01:57','2026-11-15 09:01:57','2026-11-15 09:01:57','cab96c889d6e86e00',NULL,'1873952383da2a4ee',NULL,'2f1e0b7f89ae3c497',NULL,'5345f9133074952bc',1),('cee9cbea77de54915','Заказ архивного акта 2019 года',0,7,'Closed','Normal','Question','Нужен архивный документ, отсутствующий в информационном банке.',0,'2026-11-15 09:01:53','2026-11-15 09:01:53','2026-11-15 09:01:53','5872ce100493fa929',NULL,'b6d2ca787bd9318ff',NULL,'2f1e0b7f89ae3c497',NULL,'ee34b5ae997ac8935',1),('dd4aee2c0aae367df','Ошибка входа: неверный пароль',0,13,'Closed','Low','Incident','Пользователь трижды ввел пароль, учетная запись заблокирована.',0,'2026-11-15 09:01:55','2026-11-15 09:01:55','2026-11-15 09:01:55','cab96c889d6e86e00',NULL,'1873952383da2a4ee',NULL,'2f1e0b7f89ae3c497',NULL,'ee34b5ae997ac8935',1),('ded6744bf77097e3e','Восстановление доступа в личный кабинет',0,6,'Closed','Normal','Incident','Пользователь сменил почту и не может войти в личный кабинет.',0,'2026-11-15 09:01:53','2026-11-15 09:01:53','2026-11-15 09:01:53','3fdff7c1df3e0d18d',NULL,'026aa6805f059dd51',NULL,'2f1e0b7f89ae3c497',NULL,'5345f9133074952bc',1),('e5856416d61b70d80','Проблема с отображением таблиц',0,28,'Pending','Normal','Incident','Таблицы в документах отображаются некорректно после смены разрешения экрана.',0,'2026-11-15 09:01:58','2026-11-15 09:01:58','2026-11-15 09:01:58','05e7f68d108176fc6',NULL,'7a846e2436bbb7f3b',NULL,'2f1e0b7f89ae3c497',NULL,'ee34b5ae997ac8935',1),('ec6704302761c2e15','Запрос коммерческого предложения',0,17,'New','Normal','Question','Новая организация просит подобрать комплект для юриста и бухгалтера.',0,'2026-11-15 09:01:56','2026-11-15 09:01:56','2026-11-15 09:01:56','a8e74ae736347bba7',NULL,'40e512e4ee76a1d4c',NULL,'2f1e0b7f89ae3c497',NULL,'39ce8dc9b1c5e0553',1);
/*!40000 ALTER TABLE `case` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `case_contact`
--

DROP TABLE IF EXISTS `case_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_contact` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `case_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CASE_ID_CONTACT_ID` (`case_id`,`contact_id`),
  KEY `IDX_CASE_ID` (`case_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_contact`
--

LOCK TABLES `case_contact` WRITE;
/*!40000 ALTER TABLE `case_contact` DISABLE KEYS */;
INSERT INTO `case_contact` VALUES (1,'65a60b6ec788951ef','40e512e4ee76a1d4c',0),(2,'7836722a11c884c82','cf75a49bf4fbdc950',0),(3,'3a9cf76b6672706d0','869e5631ffd4bb052',0),(4,'293246eb718f79a6d','7a846e2436bbb7f3b',0),(5,'2218cde2db4d2f8c6','1873952383da2a4ee',0),(6,'ded6744bf77097e3e','026aa6805f059dd51',0),(7,'cee9cbea77de54915','b6d2ca787bd9318ff',0),(8,'50e213c04e65df5a9','d426d7e7c574ff1ad',0),(9,'8c493904f49418113','40e512e4ee76a1d4c',0),(10,'478a3e886297a7c29','cf75a49bf4fbdc950',0),(11,'b71d6f8aa3d764ec8','869e5631ffd4bb052',0),(12,'a615cdfea165e8422','7a846e2436bbb7f3b',0),(13,'dd4aee2c0aae367df','1873952383da2a4ee',0),(14,'101571574991cdfcc','026aa6805f059dd51',0),(15,'a0fb7b2f12bae0c77','b6d2ca787bd9318ff',0),(16,'1abc8152e84b9e536','d426d7e7c574ff1ad',0),(17,'ec6704302761c2e15','40e512e4ee76a1d4c',0),(18,'5ed5d7d94b82a7bf7','cf75a49bf4fbdc950',0),(19,'2f3391890e9cf8f07','869e5631ffd4bb052',0),(20,'63b051e166f107916','7a846e2436bbb7f3b',0),(21,'ba3e914dd98685eb9','1873952383da2a4ee',0),(22,'2df27f5cb9c6fa34b','026aa6805f059dd51',0),(23,'3063a6cbfe0357f7c','b6d2ca787bd9318ff',0),(24,'0b93c4296977533fc','d426d7e7c574ff1ad',0),(25,'949eca0fe2cdc9e46','40e512e4ee76a1d4c',0),(26,'a4be3e56e0ed0bef6','cf75a49bf4fbdc950',0),(27,'31008b4847f19f412','869e5631ffd4bb052',0),(28,'e5856416d61b70d80','7a846e2436bbb7f3b',0),(29,'1e8e4646ff308f743','1873952383da2a4ee',0),(30,'620a42f1842ce4dec','026aa6805f059dd51',0);
/*!40000 ALTER TABLE `case_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `case_knowledge_base_article`
--

DROP TABLE IF EXISTS `case_knowledge_base_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_knowledge_base_article` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `case_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `knowledge_base_article_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CASE_ID_KNOWLEDGE_BASE_ARTICLE_ID` (`case_id`,`knowledge_base_article_id`),
  KEY `IDX_CASE_ID` (`case_id`),
  KEY `IDX_KNOWLEDGE_BASE_ARTICLE_ID` (`knowledge_base_article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_knowledge_base_article`
--

LOCK TABLES `case_knowledge_base_article` WRITE;
/*!40000 ALTER TABLE `case_knowledge_base_article` DISABLE KEYS */;
/*!40000 ALTER TABLE `case_knowledge_base_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `salutation_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `do_not_call` tinyint NOT NULL DEFAULT '0',
  `address_street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_postal_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `middle_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_CREATED_AT` (`created_at`,`deleted`),
  KEY `IDX_FIRST_NAME` (`first_name`,`deleted`),
  KEY `IDX_NAME` (`first_name`,`last_name`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES ('026aa6805f059dd51',0,NULL,'Демо','Клиент 6',NULL,0,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:51','2026-11-15 09:01:51',NULL,'2026-11-15 09:01:51','3fdff7c1df3e0d18d',NULL,'2f1e0b7f89ae3c497',NULL,NULL),('1873952383da2a4ee',0,NULL,'Демо','Клиент 5',NULL,0,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:50','2026-11-15 09:01:50',NULL,'2026-11-15 09:01:50','cab96c889d6e86e00',NULL,'2f1e0b7f89ae3c497',NULL,NULL),('40e512e4ee76a1d4c',0,NULL,'Демо','Клиент 1',NULL,0,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:48','2026-11-15 09:01:48',NULL,'2026-11-15 09:01:48','a8e74ae736347bba7',NULL,'2f1e0b7f89ae3c497',NULL,NULL),('7a846e2436bbb7f3b',0,NULL,'Демо','Клиент 4',NULL,0,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:50','2026-11-15 09:01:50',NULL,'2026-11-15 09:01:50','05e7f68d108176fc6',NULL,'2f1e0b7f89ae3c497',NULL,NULL),('869e5631ffd4bb052',0,NULL,'Демо','Клиент 3',NULL,0,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:49','2026-11-15 09:01:49',NULL,'2026-11-15 09:01:49','aec01fbd5ffab15aa',NULL,'2f1e0b7f89ae3c497',NULL,NULL),('b6d2ca787bd9318ff',0,NULL,'Демо','Клиент 7',NULL,0,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:51','2026-11-15 09:01:51',NULL,'2026-11-15 09:01:51','5872ce100493fa929',NULL,'2f1e0b7f89ae3c497',NULL,NULL),('cf75a49bf4fbdc950',0,NULL,'Демо','Клиент 2',NULL,0,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:49','2026-11-15 09:01:49',NULL,'2026-11-15 09:01:49','31d97c49e066562c5',NULL,'2f1e0b7f89ae3c497',NULL,NULL),('d426d7e7c574ff1ad',0,NULL,'Демо','Клиент 8',NULL,0,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:51','2026-11-15 09:01:51',NULL,'2026-11-15 09:01:51','69c3fae08cc458585',NULL,'2f1e0b7f89ae3c497',NULL,NULL);
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_document`
--

DROP TABLE IF EXISTS `contact_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_document` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `document_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CONTACT_ID_DOCUMENT_ID` (`contact_id`,`document_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_DOCUMENT_ID` (`document_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_document`
--

LOCK TABLES `contact_document` WRITE;
/*!40000 ALTER TABLE `contact_document` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_meeting`
--

DROP TABLE IF EXISTS `contact_meeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_meeting` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meeting_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CONTACT_ID_MEETING_ID` (`contact_id`,`meeting_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_MEETING_ID` (`meeting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_meeting`
--

LOCK TABLES `contact_meeting` WRITE;
/*!40000 ALTER TABLE `contact_meeting` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_meeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_opportunity`
--

DROP TABLE IF EXISTS `contact_opportunity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_opportunity` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opportunity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CONTACT_ID_OPPORTUNITY_ID` (`contact_id`,`opportunity_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_OPPORTUNITY_ID` (`opportunity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_opportunity`
--

LOCK TABLES `contact_opportunity` WRITE;
/*!40000 ALTER TABLE `contact_opportunity` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_opportunity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_target_list`
--

DROP TABLE IF EXISTS `contact_target_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_target_list` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opted_out` tinyint DEFAULT '0',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CONTACT_ID_TARGET_LIST_ID` (`contact_id`,`target_list_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_target_list`
--

LOCK TABLES `contact_target_list` WRITE;
/*!40000 ALTER TABLE `contact_target_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_target_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `currency` (
  `id` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `rate` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency`
--

LOCK TABLES `currency` WRITE;
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
INSERT INTO `currency` VALUES ('USD',1);
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency_record`
--

DROP TABLE IF EXISTS `currency_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `currency_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `code` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `delete_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CODE_DELETE_ID` (`code`,`delete_id`),
  KEY `IDX_CODE` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency_record`
--

LOCK TABLES `currency_record` WRITE;
/*!40000 ALTER TABLE `currency_record` DISABLE KEYS */;
INSERT INTO `currency_record` VALUES ('e8ceb3aa71e4d37b4',0,'USD','Active','0');
/*!40000 ALTER TABLE `currency_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency_record_rate`
--

DROP TABLE IF EXISTS `currency_record_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `currency_record_rate` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `base_code` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `delete_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `record_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rate` decimal(20,8) DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_RECORD_ID_BASE_CODE_DATE` (`record_id`,`base_code`,`date`,`delete_id`),
  KEY `IDX_RECORD_ID` (`record_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency_record_rate`
--

LOCK TABLES `currency_record_rate` WRITE;
/*!40000 ALTER TABLE `currency_record_rate` DISABLE KEYS */;
/*!40000 ALTER TABLE `currency_record_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dashboard_template`
--

DROP TABLE IF EXISTS `dashboard_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `dashboard_template` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `layout` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `dashlets_options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dashboard_template`
--

LOCK TABLES `dashboard_template` WRITE;
/*!40000 ALTER TABLE `dashboard_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document`
--

DROP TABLE IF EXISTS `document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `publish_date` date DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `file_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_FOLDER_ID` (`folder_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document`
--

LOCK TABLES `document` WRITE;
/*!40000 ALTER TABLE `document` DISABLE KEYS */;
/*!40000 ALTER TABLE `document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_folder`
--

DROP TABLE IF EXISTS `document_folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_folder` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_folder`
--

LOCK TABLES `document_folder` WRITE;
/*!40000 ALTER TABLE `document_folder` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_folder_path`
--

DROP TABLE IF EXISTS `document_folder_path`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_folder_path` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ascendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ASCENDOR_ID` (`ascendor_id`),
  KEY `IDX_DESCENDOR_ID` (`descendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_folder_path`
--

LOCK TABLES `document_folder_path` WRITE;
/*!40000 ALTER TABLE `document_folder_path` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_folder_path` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_lead`
--

DROP TABLE IF EXISTS `document_lead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_lead` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `document_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lead_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_DOCUMENT_ID_LEAD_ID` (`document_id`,`lead_id`),
  KEY `IDX_DOCUMENT_ID` (`document_id`),
  KEY `IDX_LEAD_ID` (`lead_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_lead`
--

LOCK TABLES `document_lead` WRITE;
/*!40000 ALTER TABLE `document_lead` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_lead` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `document_opportunity`
--

DROP TABLE IF EXISTS `document_opportunity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `document_opportunity` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `document_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opportunity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_DOCUMENT_ID_OPPORTUNITY_ID` (`document_id`,`opportunity_id`),
  KEY `IDX_DOCUMENT_ID` (`document_id`),
  KEY `IDX_OPPORTUNITY_ID` (`opportunity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `document_opportunity`
--

LOCK TABLES `document_opportunity` WRITE;
/*!40000 ALTER TABLE `document_opportunity` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_opportunity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email`
--

DROP TABLE IF EXISTS `email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `from_string` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_to_string` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_name_map` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_replied` tinyint NOT NULL DEFAULT '0',
  `message_id` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message_id_internal` varchar(500) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body_plain` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `body` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_html` tinyint NOT NULL DEFAULT '1',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Archived',
  `has_attachment` tinyint NOT NULL DEFAULT '0',
  `date_sent` datetime DEFAULT NULL,
  `delivery_date` datetime DEFAULT NULL,
  `send_at` datetime DEFAULT NULL,
  `is_auto_reply` tinyint NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `is_system` tinyint NOT NULL DEFAULT '0',
  `ics_contents` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `ics_event_uid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_status_folder` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_email_address_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sent_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `replied_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_event_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_event_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_DATE_SENT` (`date_sent`,`deleted`),
  KEY `IDX_DATE_SENT_STATUS` (`date_sent`,`status`,`deleted`),
  KEY `IDX_MESSAGE_ID` (`message_id`),
  KEY `IDX_ICS_EVENT_UID` (`ics_event_uid`),
  KEY `IDX_GROUP_STATUS_FOLDER` (`group_status_folder`),
  KEY `IDX_FROM_EMAIL_ADDRESS_ID` (`from_email_address_id`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_SENT_BY_ID` (`sent_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_REPLIED_ID` (`replied_id`),
  KEY `IDX_CREATED_EVENT` (`created_event_id`,`created_event_type`),
  KEY `IDX_GROUP_FOLDER_ID` (`group_folder_id`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  FULLTEXT KEY `IDX_SYSTEM_FULL_TEXT_SEARCH` (`name`,`body_plain`,`body`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email`
--

LOCK TABLES `email` WRITE;
/*!40000 ALTER TABLE `email` DISABLE KEYS */;
/*!40000 ALTER TABLE `email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_account`
--

DROP TABLE IF EXISTS `email_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_account` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `email_address` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `host` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `port` int DEFAULT '993',
  `security` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'SSL',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monitored_folders` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `sent_folder` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `folder_map` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `store_sent_emails` tinyint NOT NULL DEFAULT '0',
  `keep_fetched_emails_unread` tinyint NOT NULL DEFAULT '0',
  `fetch_validity_number` int DEFAULT '0',
  `fetch_since` date DEFAULT NULL,
  `fetch_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `connected_at` datetime DEFAULT NULL,
  `use_imap` tinyint NOT NULL DEFAULT '1',
  `use_smtp` tinyint NOT NULL DEFAULT '0',
  `smtp_host` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_port` int DEFAULT '587',
  `smtp_auth` tinyint NOT NULL DEFAULT '1',
  `smtp_security` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'TLS',
  `smtp_username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_auth_mechanism` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'login',
  `imap_handler` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_handler` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_EMAIL_FOLDER_ID` (`email_folder_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_account`
--

LOCK TABLES `email_account` WRITE;
/*!40000 ALTER TABLE `email_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_address`
--

DROP TABLE IF EXISTS `email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_address` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `lower` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invalid` tinyint NOT NULL DEFAULT '0',
  `opt_out` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IDX_LOWER` (`lower`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_address`
--

LOCK TABLES `email_address` WRITE;
/*!40000 ALTER TABLE `email_address` DISABLE KEYS */;
INSERT INTO `email_address` VALUES ('2f1e90ea754d02fe7','ivanova@demo.akcentplus.ru',0,'ivanova@demo.akcentplus.ru',0,0),('39f6e04e0630c859b','client4@demo.akcentplus.ru',0,'client4@demo.akcentplus.ru',0,0),('42d56eacea5db6f5c','sidorov@demo.akcentplus.ru',0,'sidorov@demo.akcentplus.ru',0,0),('6b24115c655a4edba','client2@demo.akcentplus.ru',0,'client2@demo.akcentplus.ru',0,0),('86adecf6822d69da8','client1@demo.akcentplus.ru',0,'client1@demo.akcentplus.ru',0,0),('9401c2ebd94a8b779','test2@demo.akcentplus.ru',0,'test2@demo.akcentplus.ru',0,0),('b2be734576dcfba1a','client8@demo.akcentplus.ru',0,'client8@demo.akcentplus.ru',0,0),('b93aed6637b540f43','client7@demo.akcentplus.ru',0,'client7@demo.akcentplus.ru',0,0),('be8d1d65f1473e235','client5@demo.akcentplus.ru',0,'client5@demo.akcentplus.ru',0,0),('d146caf6fb013e52e','kozlova@demo.akcentplus.ru',0,'kozlova@demo.akcentplus.ru',0,0),('e1000e1068de873a2','client3@demo.akcentplus.ru',0,'client3@demo.akcentplus.ru',0,0),('f0a6a2a5a98bf4972','client6@demo.akcentplus.ru',0,'client6@demo.akcentplus.ru',0,0),('fb5bad87be58a2bb6','petrov@demo.akcentplus.ru',0,'petrov@demo.akcentplus.ru',0,0);
/*!40000 ALTER TABLE `email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_email_account`
--

DROP TABLE IF EXISTS `email_email_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_email_account` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_EMAIL_ID_EMAIL_ACCOUNT_ID` (`email_id`,`email_account_id`),
  KEY `IDX_EMAIL_ID` (`email_id`),
  KEY `IDX_EMAIL_ACCOUNT_ID` (`email_account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_email_account`
--

LOCK TABLES `email_email_account` WRITE;
/*!40000 ALTER TABLE `email_email_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_email_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_email_address`
--

DROP TABLE IF EXISTS `email_email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_email_address` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_address_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_type` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_EMAIL_ID_EMAIL_ADDRESS_ID_ADDRESS_TYPE` (`email_id`,`email_address_id`,`address_type`),
  KEY `IDX_EMAIL_ID` (`email_id`),
  KEY `IDX_EMAIL_ADDRESS_ID` (`email_address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_email_address`
--

LOCK TABLES `email_email_address` WRITE;
/*!40000 ALTER TABLE `email_email_address` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_filter`
--

DROP TABLE IF EXISTS `email_filter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_filter` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `from` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body_contains` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `body_contains_all` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_global` tinyint NOT NULL DEFAULT '0',
  `action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Skip',
  `mark_as_read` tinyint NOT NULL DEFAULT '0',
  `skip_notification` tinyint NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_email_folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_EMAIL_FOLDER_ID` (`email_folder_id`),
  KEY `IDX_GROUP_EMAIL_FOLDER_ID` (`group_email_folder_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_filter`
--

LOCK TABLES `email_filter` WRITE;
/*!40000 ALTER TABLE `email_filter` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_filter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_folder`
--

DROP TABLE IF EXISTS `email_folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_folder` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `order` int DEFAULT NULL,
  `skip_notifications` tinyint NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_folder`
--

LOCK TABLES `email_folder` WRITE;
/*!40000 ALTER TABLE `email_folder` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_inbound_email`
--

DROP TABLE IF EXISTS `email_inbound_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_inbound_email` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inbound_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_EMAIL_ID_INBOUND_EMAIL_ID` (`email_id`,`inbound_email_id`),
  KEY `IDX_EMAIL_ID` (`email_id`),
  KEY `IDX_INBOUND_EMAIL_ID` (`inbound_email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_inbound_email`
--

LOCK TABLES `email_inbound_email` WRITE;
/*!40000 ALTER TABLE `email_inbound_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_inbound_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_queue_item`
--

DROP TABLE IF EXISTS `email_queue_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_queue_item` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempt_count` int DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `sent_at` datetime DEFAULT NULL,
  `email_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_test` tinyint NOT NULL DEFAULT '0',
  `mass_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_SENT_AT` (`sent_at`),
  KEY `IDX_MASS_EMAIL_ID` (`mass_email_id`),
  KEY `IDX_TARGET` (`target_id`,`target_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_queue_item`
--

LOCK TABLES `email_queue_item` WRITE;
/*!40000 ALTER TABLE `email_queue_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_queue_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_template`
--

DROP TABLE IF EXISTS `email_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_template` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `subject` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_html` tinyint NOT NULL DEFAULT '1',
  `status` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `one_off` tinyint NOT NULL DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `category_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IDX_CATEGORY_ID` (`category_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_template`
--

LOCK TABLES `email_template` WRITE;
/*!40000 ALTER TABLE `email_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_template_category`
--

DROP TABLE IF EXISTS `email_template_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_template_category` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `order` int DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_template_category`
--

LOCK TABLES `email_template_category` WRITE;
/*!40000 ALTER TABLE `email_template_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_template_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_template_category_path`
--

DROP TABLE IF EXISTS `email_template_category_path`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_template_category_path` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ascendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ASCENDOR_ID` (`ascendor_id`),
  KEY `IDX_DESCENDOR_ID` (`descendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_template_category_path`
--

LOCK TABLES `email_template_category_path` WRITE;
/*!40000 ALTER TABLE `email_template_category_path` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_template_category_path` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `email_user`
--

DROP TABLE IF EXISTS `email_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `email_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_read` tinyint DEFAULT '0',
  `is_important` tinyint DEFAULT '0',
  `in_trash` tinyint DEFAULT '0',
  `in_archive` tinyint DEFAULT '0',
  `folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_EMAIL_ID_USER_ID` (`email_id`,`user_id`),
  KEY `IDX_EMAIL_ID` (`email_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `email_user`
--

LOCK TABLES `email_user` WRITE;
/*!40000 ALTER TABLE `email_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `email_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity_collaborator`
--

DROP TABLE IF EXISTS `entity_collaborator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity_collaborator` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ENTITY_ID_USER_ID_ENTITY_TYPE` (`entity_id`,`user_id`,`entity_type`),
  KEY `IDX_ENTITY_ID` (`entity_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_collaborator`
--

LOCK TABLES `entity_collaborator` WRITE;
/*!40000 ALTER TABLE `entity_collaborator` DISABLE KEYS */;
INSERT INTO `entity_collaborator` VALUES (1,'65a60b6ec788951ef','ee34b5ae997ac8935','Case',0),(2,'7836722a11c884c82','39ce8dc9b1c5e0553','Case',0),(3,'3a9cf76b6672706d0','5345f9133074952bc','Case',0),(4,'293246eb718f79a6d','ee34b5ae997ac8935','Case',0),(5,'2218cde2db4d2f8c6','39ce8dc9b1c5e0553','Case',0),(6,'ded6744bf77097e3e','5345f9133074952bc','Case',0),(7,'cee9cbea77de54915','ee34b5ae997ac8935','Case',0),(8,'50e213c04e65df5a9','39ce8dc9b1c5e0553','Case',0),(9,'8c493904f49418113','5345f9133074952bc','Case',0),(10,'478a3e886297a7c29','ee34b5ae997ac8935','Case',0),(11,'b71d6f8aa3d764ec8','39ce8dc9b1c5e0553','Case',0),(12,'a615cdfea165e8422','5345f9133074952bc','Case',0),(13,'dd4aee2c0aae367df','ee34b5ae997ac8935','Case',0),(14,'101571574991cdfcc','39ce8dc9b1c5e0553','Case',0),(15,'a0fb7b2f12bae0c77','5345f9133074952bc','Case',0),(16,'1abc8152e84b9e536','ee34b5ae997ac8935','Case',0),(17,'ec6704302761c2e15','39ce8dc9b1c5e0553','Case',0),(18,'5ed5d7d94b82a7bf7','5345f9133074952bc','Case',0),(19,'2f3391890e9cf8f07','ee34b5ae997ac8935','Case',0),(20,'63b051e166f107916','39ce8dc9b1c5e0553','Case',0),(21,'ba3e914dd98685eb9','5345f9133074952bc','Case',0),(22,'2df27f5cb9c6fa34b','ee34b5ae997ac8935','Case',0),(23,'3063a6cbfe0357f7c','39ce8dc9b1c5e0553','Case',0),(24,'0b93c4296977533fc','5345f9133074952bc','Case',0),(25,'949eca0fe2cdc9e46','ee34b5ae997ac8935','Case',0),(26,'a4be3e56e0ed0bef6','39ce8dc9b1c5e0553','Case',0),(27,'31008b4847f19f412','5345f9133074952bc','Case',0),(28,'e5856416d61b70d80','ee34b5ae997ac8935','Case',0),(29,'1e8e4646ff308f743','39ce8dc9b1c5e0553','Case',0),(30,'620a42f1842ce4dec','5345f9133074952bc','Case',0);
/*!40000 ALTER TABLE `entity_collaborator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity_email_address`
--

DROP TABLE IF EXISTS `entity_email_address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity_email_address` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_address_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primary` tinyint DEFAULT '0',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ENTITY_ID_EMAIL_ADDRESS_ID_ENTITY_TYPE` (`entity_id`,`email_address_id`,`entity_type`),
  KEY `IDX_ENTITY_ID` (`entity_id`),
  KEY `IDX_EMAIL_ADDRESS_ID` (`email_address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_email_address`
--

LOCK TABLES `entity_email_address` WRITE;
/*!40000 ALTER TABLE `entity_email_address` DISABLE KEYS */;
INSERT INTO `entity_email_address` VALUES (1,'5345f9133074952bc','2f1e90ea754d02fe7','User',1,0),(2,'ee34b5ae997ac8935','42d56eacea5db6f5c','User',1,0),(3,'39ce8dc9b1c5e0553','d146caf6fb013e52e','User',1,0),(4,'b276a07c9d460eef6','fb5bad87be58a2bb6','User',1,0),(5,'3869dda69e6770c35','9401c2ebd94a8b779','User',1,0),(6,'40e512e4ee76a1d4c','86adecf6822d69da8','Contact',1,0),(7,'cf75a49bf4fbdc950','6b24115c655a4edba','Contact',1,0),(8,'869e5631ffd4bb052','e1000e1068de873a2','Contact',1,0),(9,'7a846e2436bbb7f3b','39f6e04e0630c859b','Contact',1,0),(10,'1873952383da2a4ee','be8d1d65f1473e235','Contact',1,0),(11,'026aa6805f059dd51','f0a6a2a5a98bf4972','Contact',1,0),(12,'b6d2ca787bd9318ff','b93aed6637b540f43','Contact',1,0),(13,'d426d7e7c574ff1ad','b2be734576dcfba1a','Contact',1,0);
/*!40000 ALTER TABLE `entity_email_address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity_phone_number`
--

DROP TABLE IF EXISTS `entity_phone_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity_phone_number` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `primary` tinyint DEFAULT '0',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ENTITY_ID_PHONE_NUMBER_ID_ENTITY_TYPE` (`entity_id`,`phone_number_id`,`entity_type`),
  KEY `IDX_ENTITY_ID` (`entity_id`),
  KEY `IDX_PHONE_NUMBER_ID` (`phone_number_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_phone_number`
--

LOCK TABLES `entity_phone_number` WRITE;
/*!40000 ALTER TABLE `entity_phone_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `entity_phone_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity_team`
--

DROP TABLE IF EXISTS `entity_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity_team` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ENTITY_ID_TEAM_ID_ENTITY_TYPE` (`entity_id`,`team_id`,`entity_type`),
  KEY `IDX_ENTITY_ID` (`entity_id`),
  KEY `IDX_TEAM_ID` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_team`
--

LOCK TABLES `entity_team` WRITE;
/*!40000 ALTER TABLE `entity_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `entity_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entity_user`
--

DROP TABLE IF EXISTS `entity_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entity_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ENTITY_ID_USER_ID_ENTITY_TYPE` (`entity_id`,`user_id`,`entity_type`),
  KEY `IDX_ENTITY_ID` (`entity_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entity_user`
--

LOCK TABLES `entity_user` WRITE;
/*!40000 ALTER TABLE `entity_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `entity_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `export`
--

DROP TABLE IF EXISTS `export`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `export` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `notify_on_finish` tinyint NOT NULL DEFAULT '0',
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attachment_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_ATTACHMENT` (`attachment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `export`
--

LOCK TABLES `export` WRITE;
/*!40000 ALTER TABLE `export` DISABLE KEYS */;
/*!40000 ALTER TABLE `export` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `extension`
--

DROP TABLE IF EXISTS `extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `extension` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `version` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `license_status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `license_status_message` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_installed` tinyint NOT NULL DEFAULT '0',
  `check_version_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_LICENSE_STATUS` (`license_status`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `extension`
--

LOCK TABLES `extension` WRITE;
/*!40000 ALTER TABLE `extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `external_account`
--

DROP TABLE IF EXISTS `external_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `external_account` (
  `id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `enabled` tinyint NOT NULL DEFAULT '0',
  `is_locked` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `external_account`
--

LOCK TABLES `external_account` WRITE;
/*!40000 ALTER TABLE `external_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `external_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_email_folder`
--

DROP TABLE IF EXISTS `group_email_folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_email_folder` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `order` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_email_folder`
--

LOCK TABLES `group_email_folder` WRITE;
/*!40000 ALTER TABLE `group_email_folder` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_email_folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_email_folder_team`
--

DROP TABLE IF EXISTS `group_email_folder_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `group_email_folder_team` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_email_folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_GROUP_EMAIL_FOLDER_ID_TEAM_ID` (`group_email_folder_id`,`team_id`),
  KEY `IDX_GROUP_EMAIL_FOLDER_ID` (`group_email_folder_id`),
  KEY `IDX_TEAM_ID` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_email_folder_team`
--

LOCK TABLES `group_email_folder_team` WRITE;
/*!40000 ALTER TABLE `group_email_folder_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_email_folder_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import`
--

DROP TABLE IF EXISTS `import`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `import` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `entity_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_index` int DEFAULT NULL,
  `params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `attribute_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `file_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import`
--

LOCK TABLES `import` WRITE;
/*!40000 ALTER TABLE `import` DISABLE KEYS */;
/*!40000 ALTER TABLE `import` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import_entity`
--

DROP TABLE IF EXISTS `import_entity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `import_entity` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `deleted` tinyint DEFAULT '0',
  `is_imported` tinyint NOT NULL DEFAULT '0',
  `is_updated` tinyint NOT NULL DEFAULT '0',
  `is_duplicate` tinyint NOT NULL DEFAULT '0',
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `import_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ENTITY_IMPORT` (`import_id`,`entity_type`),
  KEY `IDX_ENTITY` (`entity_id`,`entity_type`),
  KEY `IDX_IMPORT` (`import_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import_entity`
--

LOCK TABLES `import_entity` WRITE;
/*!40000 ALTER TABLE `import_entity` DISABLE KEYS */;
/*!40000 ALTER TABLE `import_entity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `import_error`
--

DROP TABLE IF EXISTS `import_error`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `import_error` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `row_index` int DEFAULT NULL,
  `export_row_index` int DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `validation_failures` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `row` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `import_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ROW_INDEX` (`row_index`),
  KEY `IDX_IMPORT_ROW_INDEX` (`import_id`,`row_index`),
  KEY `IDX_IMPORT_ID` (`import_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `import_error`
--

LOCK TABLES `import_error` WRITE;
/*!40000 ALTER TABLE `import_error` DISABLE KEYS */;
/*!40000 ALTER TABLE `import_error` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inbound_email`
--

DROP TABLE IF EXISTS `inbound_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inbound_email` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `email_address` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `host` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `port` int DEFAULT '993',
  `security` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'SSL',
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `monitored_folders` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `fetch_validity_number` int DEFAULT '0',
  `fetch_since` date DEFAULT NULL,
  `fetch_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `add_all_team_users` tinyint NOT NULL DEFAULT '1',
  `sent_folder` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `store_sent_emails` tinyint NOT NULL DEFAULT '0',
  `keep_fetched_emails_unread` tinyint NOT NULL DEFAULT '0',
  `connected_at` datetime DEFAULT NULL,
  `exclude_from_reply` tinyint NOT NULL DEFAULT '0',
  `use_imap` tinyint NOT NULL DEFAULT '1',
  `use_smtp` tinyint NOT NULL DEFAULT '0',
  `smtp_is_shared` tinyint NOT NULL DEFAULT '0',
  `smtp_is_for_mass_email` tinyint NOT NULL DEFAULT '0',
  `smtp_host` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_port` int DEFAULT '587',
  `smtp_auth` tinyint NOT NULL DEFAULT '1',
  `smtp_security` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'TLS',
  `smtp_username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_auth_mechanism` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'login',
  `create_case` tinyint NOT NULL DEFAULT '0',
  `case_distribution` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Direct-Assignment',
  `target_user_position` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply` tinyint NOT NULL DEFAULT '0',
  `reply_from_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_to_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_from_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imap_handler` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_handler` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `assign_to_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_email_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group_email_folder_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ASSIGN_TO_USER_ID` (`assign_to_user_id`),
  KEY `IDX_TEAM_ID` (`team_id`),
  KEY `IDX_REPLY_EMAIL_TEMPLATE_ID` (`reply_email_template_id`),
  KEY `IDX_GROUP_EMAIL_FOLDER_ID` (`group_email_folder_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inbound_email`
--

LOCK TABLES `inbound_email` WRITE;
/*!40000 ALTER TABLE `inbound_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `inbound_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inbound_email_team`
--

DROP TABLE IF EXISTS `inbound_email_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inbound_email_team` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `inbound_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_INBOUND_EMAIL_ID_TEAM_ID` (`inbound_email_id`,`team_id`),
  KEY `IDX_INBOUND_EMAIL_ID` (`inbound_email_id`),
  KEY `IDX_TEAM_ID` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inbound_email_team`
--

LOCK TABLES `inbound_email_team` WRITE;
/*!40000 ALTER TABLE `inbound_email_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `inbound_email_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `integration`
--

DROP TABLE IF EXISTS `integration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `integration` (
  `id` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `enabled` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `integration`
--

LOCK TABLES `integration` WRITE;
/*!40000 ALTER TABLE `integration` DISABLE KEYS */;
/*!40000 ALTER TABLE `integration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job`
--

DROP TABLE IF EXISTS `job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `execute_time` datetime DEFAULT NULL,
  `number` bigint unsigned NOT NULL AUTO_INCREMENT,
  `class_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `queue` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `group` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_group` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `executed_at` datetime DEFAULT NULL,
  `pid` int DEFAULT NULL,
  `attempts` int DEFAULT NULL,
  `target_id` varchar(48) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `failed_attempts` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `scheduled_job_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_EXECUTE_TIME` (`status`,`execute_time`),
  KEY `IDX_STATUS` (`status`,`deleted`),
  KEY `IDX_STATUS_SCHEDULED_JOB_ID_TARGET` (`status`,`scheduled_job_id`,`target_type`,`target_id`),
  KEY `IDX_SCHEDULED_JOB_ID` (`scheduled_job_id`)
) ENGINE=InnoDB AUTO_INCREMENT=519 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job`
--

LOCK TABLES `job` WRITE;
/*!40000 ALTER TABLE `job` DISABLE KEYS */;
INSERT INTO `job` VALUES ('00ac9825214eeb635','Send Email Reminders',0,'Success','2026-11-15 09:16:00',343,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:08','2026-11-15 09:16:08',295,1,NULL,NULL,NULL,'2026-11-15 09:14:08','2026-11-15 09:16:08','38c14103df40c8494'),('0138372e7fc4265f1','Submit Popup Reminders',0,'Success','2026-11-15 09:11:08',284,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:11:08','2026-11-15 09:11:08',166,1,NULL,NULL,NULL,'2026-11-15 09:11:08','2026-11-15 09:11:08','bcd1c259a799fac87'),('0175a15c767a35e83','Process Job Queue e0',0,'Success','2026-11-15 09:07:48',212,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:07:48','2026-11-15 09:07:48',73,1,NULL,NULL,NULL,'2026-11-15 09:07:48','2026-11-15 09:07:48','5f75cd3ef25340f25'),('019fc60b1abef41f4','Submit Popup Reminders',0,'Success','2026-11-15 09:19:28',457,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:19:28','2026-11-15 09:19:28',388,1,NULL,NULL,NULL,'2026-11-15 09:19:28','2026-11-15 09:19:28','bcd1c259a799fac87'),('01db421d899c95855','Process Job Queue q0',0,'Success','2026-11-15 09:07:18',202,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:07:18','2026-11-15 09:07:18',60,1,NULL,NULL,NULL,'2026-11-15 09:07:18','2026-11-15 09:07:18','5750be1f178c76fe9'),('02a7ae6f59a273c3d','Process Job Queue q0',0,'Success','2026-11-15 09:11:28',289,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:11:28','2026-11-15 09:11:28',172,1,NULL,NULL,NULL,'2026-11-15 09:11:28','2026-11-15 09:11:28','5750be1f178c76fe9'),('02bbe187711bebee3','Send Email Reminders',0,'Success','2026-11-15 09:02:00',68,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:01','2026-11-15 09:02:01',134,1,NULL,NULL,NULL,'2026-11-15 09:00:01','2026-11-15 09:02:01','38c14103df40c8494'),('030b089645604d12e','Process Job Queue q0',0,'Success','2026-11-15 09:20:18',475,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:18','2026-11-15 09:20:18',411,1,NULL,NULL,NULL,'2026-11-15 09:20:18','2026-11-15 09:20:18','5750be1f178c76fe9'),('03545fd59cd6080ad','Submit Popup Reminders',0,'Success','2026-11-15 09:02:41',129,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:41','2026-11-15 09:02:41',156,1,NULL,NULL,NULL,'2026-11-15 09:02:41','2026-11-15 09:02:41','bcd1c259a799fac87'),('03853d698b44acb73','Process Job Queue e0',0,'Success','2026-11-15 09:09:28',247,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:09:28','2026-11-15 09:09:28',118,1,NULL,NULL,NULL,'2026-11-15 09:09:28','2026-11-15 09:09:28','5f75cd3ef25340f25'),('03ae3cd820abde221','Submit Popup Reminders',0,'Success','2026-11-15 09:06:08',179,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:08','2026-11-15 09:06:08',33,1,NULL,NULL,NULL,'2026-11-15 09:06:08','2026-11-15 09:06:08','bcd1c259a799fac87'),('05a0455c5035ad215','Submit Popup Reminders',0,'Success','2026-11-15 09:00:51',91,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:51','2026-11-15 09:00:51',107,1,NULL,NULL,NULL,'2026-11-15 09:00:51','2026-11-15 09:00:51','bcd1c259a799fac87'),('05e4491f8e6d36721','Auth Token Control',0,'Success','2026-11-15 09:06:00',76,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:08','2026-11-15 09:06:08',26,1,NULL,NULL,NULL,'2026-11-15 09:00:01','2026-11-15 09:06:08','eeb2498dde7129c23'),('06cf4a44fa604b535','Submit Popup Reminders',0,'Success','2026-11-15 09:12:28',314,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:28','2026-11-15 09:12:28',203,1,NULL,NULL,NULL,'2026-11-15 09:12:28','2026-11-15 09:12:28','bcd1c259a799fac87'),('0819c9921b58d4055','Submit Popup Reminders',0,'Success','2026-11-15 09:03:41',148,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:03:41','2026-11-15 09:03:41',181,1,NULL,NULL,NULL,'2026-11-15 09:03:41','2026-11-15 09:03:41','bcd1c259a799fac87'),('08700e4e1cb705ec9','Process Job Queue e0',0,'Success','2026-11-15 09:06:48',193,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:48','2026-11-15 09:06:48',48,1,NULL,NULL,NULL,'2026-11-15 09:06:48','2026-11-15 09:06:48','5f75cd3ef25340f25'),('09d8725182eb3eb08','Auth Token Control',0,'Pending','2026-11-15 09:30:00',505,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-11-15 09:27:41','2026-11-15 09:27:41','eeb2498dde7129c23'),('0a2eb30c93106e507','Process Job Queue q0',0,'Success','2026-11-15 09:20:08',469,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:08','2026-11-15 09:20:08',407,1,NULL,NULL,NULL,'2026-11-15 09:20:08','2026-11-15 09:20:08','5750be1f178c76fe9'),('0ab399122ac1fdb4e','Process Job Queue e0',0,'Success','2026-11-15 09:00:01',71,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:01','2026-11-15 09:00:01',86,1,NULL,NULL,NULL,'2026-11-15 09:00:01','2026-11-15 09:00:01','5f75cd3ef25340f25'),('0afd1d79eea8d4c24','Submit Popup Reminders',0,'Success','2026-11-15 09:07:08',200,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:07:08','2026-11-15 09:07:08',58,1,NULL,NULL,NULL,'2026-11-15 09:07:08','2026-11-15 09:07:08','bcd1c259a799fac87'),('0b08efe25bda31638','Send Email Notifications',0,'Success','2026-11-15 09:04:00',116,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:04:01','2026-11-15 09:04:01',189,1,NULL,NULL,NULL,'2026-11-15 09:02:01','2026-11-15 09:04:01','e9d6c9980d694fb42'),('0bee5d16f2263418e','Process Job Queue e0',0,'Success','2026-11-15 09:01:41',106,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:41','2026-11-15 09:01:41',127,1,NULL,NULL,NULL,'2026-11-15 09:01:41','2026-11-15 09:01:41','5f75cd3ef25340f25'),('0cd41d2a5bd5cf1b3','Submit Popup Reminders',0,'Success','2026-11-15 08:59:21',58,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:59:21','2026-11-15 08:59:21',65,1,NULL,NULL,NULL,'2026-11-15 08:59:21','2026-11-15 08:59:21','bcd1c259a799fac87'),('0d2d6ab9abf51a57a','Process Job Queue q0',0,'Success','2026-11-15 09:20:58',487,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:58','2026-11-15 09:20:58',427,1,NULL,NULL,NULL,'2026-11-15 09:20:58','2026-11-15 09:20:58','5750be1f178c76fe9'),('0d97fcb09a932ea69','Process Job Queue e0',0,'Success','2026-11-15 09:01:51',109,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:51','2026-11-15 09:01:51',131,1,NULL,NULL,NULL,'2026-11-15 09:01:51','2026-11-15 09:01:51','5f75cd3ef25340f25'),('0ec655a59ca4d9325','Process Job Queue q0',0,'Success','2026-11-15 09:08:18',224,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:18','2026-11-15 09:08:18',88,1,NULL,NULL,NULL,'2026-11-15 09:08:18','2026-11-15 09:08:18','5750be1f178c76fe9'),('0f0aa57b40eca4284','Process Job Queue e0',0,'Success','2026-11-15 09:09:38',250,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:09:38','2026-11-15 09:09:38',122,1,NULL,NULL,NULL,'2026-11-15 09:09:38','2026-11-15 09:09:38','5f75cd3ef25340f25'),('0f524309c5067bcf0','Send Email Notifications',0,'Success','2026-11-15 08:58:00',15,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:01','2026-11-15 08:58:01',28,1,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 08:58:01','e9d6c9980d694fb42'),('1003521efbb6b343d','Process Job Queue q0',0,'Success','2026-11-15 09:17:18',410,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:17:18','2026-11-15 09:17:18',328,1,NULL,NULL,NULL,'2026-11-15 09:17:18','2026-11-15 09:17:18','5750be1f178c76fe9'),('1038befbf9eb17d65','Submit Popup Reminders',0,'Success','2026-11-15 09:18:18',435,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:18','2026-11-15 09:18:18',359,1,NULL,NULL,NULL,'2026-11-15 09:18:18','2026-11-15 09:18:18','bcd1c259a799fac87'),('10690102ce7cc8527','Submit Popup Reminders',0,'Success','2026-11-15 08:59:11',55,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:59:11','2026-11-15 08:59:11',61,1,NULL,NULL,NULL,'2026-11-15 08:59:11','2026-11-15 08:59:11','bcd1c259a799fac87'),('10e11c8caa81629c2','Process Job Queue e0',0,'Success','2026-11-15 09:03:51',150,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:03:51','2026-11-15 09:03:51',184,1,NULL,NULL,NULL,'2026-11-15 09:03:51','2026-11-15 09:03:51','5f75cd3ef25340f25'),('1133ef8eb4add11b8','Process Job Queue e0',0,'Success','2026-11-15 09:20:18',476,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:18','2026-11-15 09:20:18',412,1,NULL,NULL,NULL,'2026-11-15 09:20:18','2026-11-15 09:20:18','5f75cd3ef25340f25'),('1134c64e0adf1a3fc','Process Job Queue e0',0,'Success','2026-11-15 09:17:08',407,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:17:08','2026-11-15 09:17:08',325,1,NULL,NULL,NULL,'2026-11-15 09:17:08','2026-11-15 09:17:08','5f75cd3ef25340f25'),('118bdfff7021588fc','Process Job Queue e0',0,'Success','2026-11-15 09:03:31',144,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:03:31','2026-11-15 09:03:31',176,1,NULL,NULL,NULL,'2026-11-15 09:03:31','2026-11-15 09:03:31','5f75cd3ef25340f25'),('11b7a0e26e75dc6c7','Process Job Queue q1',0,'Success','2026-11-15 09:03:00',117,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:03:01','2026-11-15 09:03:01',162,1,NULL,NULL,NULL,'2026-11-15 09:02:01','2026-11-15 09:03:01','ea1678c7ea92717de'),('1215f324e72220d4e','Process Job Queue q1',0,'Success','2026-11-15 09:13:00',307,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:13:08','2026-11-15 09:13:08',217,1,NULL,NULL,NULL,'2026-11-15 09:12:08','2026-11-15 09:13:08','ea1678c7ea92717de'),('1320ab829726a9f3f','Process Job Queue e0',0,'Success','2026-11-15 09:05:28',163,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:05:28','2026-11-15 09:05:28',14,1,NULL,NULL,NULL,'2026-11-15 09:05:28','2026-11-15 09:05:28','5f75cd3ef25340f25'),('1354c3605162be0d0','Process Job Queue q1',0,'Success','2026-11-15 09:16:00',368,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:08','2026-11-15 09:16:08',298,1,NULL,NULL,NULL,'2026-11-15 09:15:08','2026-11-15 09:16:08','ea1678c7ea92717de'),('14c02e90fab356353','Submit Popup Reminders',0,'Success','2026-11-15 09:18:28',438,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:28','2026-11-15 09:18:28',363,1,NULL,NULL,NULL,'2026-11-15 09:18:28','2026-11-15 09:18:28','bcd1c259a799fac87'),('15615d98e225a18fa','Submit Popup Reminders',0,'Success','2026-11-15 09:07:58',216,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:07:58','2026-11-15 09:07:58',78,1,NULL,NULL,NULL,'2026-11-15 09:07:58','2026-11-15 09:07:58','bcd1c259a799fac87'),('161100579a1489d25','Process Job Queue e0',0,'Success','2026-11-15 09:02:01',114,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:01','2026-11-15 09:02:01',139,1,NULL,NULL,NULL,'2026-11-15 09:02:01','2026-11-15 09:02:01','5f75cd3ef25340f25'),('166254a1cf50db061','Process Job Queue q0',0,'Success','2026-11-15 09:19:18',452,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:19:18','2026-11-15 09:19:18',382,1,NULL,NULL,NULL,'2026-11-15 09:19:18','2026-11-15 09:19:18','5750be1f178c76fe9'),('16ee9624e0b656aa4','Process Job Queue q0',0,'Success','2026-11-15 09:03:31',143,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:03:31','2026-11-15 09:03:31',175,1,NULL,NULL,NULL,'2026-11-15 09:03:31','2026-11-15 09:03:31','5750be1f178c76fe9'),('18620d6d19ffa1458','Process Job Queue e0',0,'Success','2026-11-15 09:16:48',401,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:48','2026-11-15 09:16:48',316,1,NULL,NULL,NULL,'2026-11-15 09:16:48','2026-11-15 09:16:48','5f75cd3ef25340f25'),('19ff3234eef92778e','Process Job Queue q0',0,'Success','2026-11-15 09:17:48',419,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:17:48','2026-11-15 09:17:48',340,1,NULL,NULL,NULL,'2026-11-15 09:17:48','2026-11-15 09:17:48','5750be1f178c76fe9'),('1a66fa8f0f9b77af1','Process Job Queue e0',0,'Success','2026-11-15 09:08:28',228,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:28','2026-11-15 09:08:28',93,1,NULL,NULL,NULL,'2026-11-15 09:08:28','2026-11-15 09:08:28','5f75cd3ef25340f25'),('1a82e1dd39b9d1929','Process Job Queue e0',0,'Success','2026-11-15 09:19:48',462,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:19:48','2026-11-15 09:19:48',395,1,NULL,NULL,NULL,'2026-11-15 09:19:48','2026-11-15 09:19:48','5f75cd3ef25340f25'),('1a8f1a9f33d01a649','Submit Popup Reminders',0,'Success','2026-11-15 08:58:21',39,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:21','2026-11-15 08:58:21',40,1,NULL,NULL,NULL,'2026-11-15 08:58:21','2026-11-15 08:58:21','bcd1c259a799fac87'),('1b997429693bfed8c','Process Job Queue e0',0,'Success','2026-11-15 09:18:08',428,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:08','2026-11-15 09:18:08',354,1,NULL,NULL,NULL,'2026-11-15 09:18:08','2026-11-15 09:18:08','5f75cd3ef25340f25'),('1c7db020491b80005','Process Job Queue e0',0,'Success','2026-11-15 09:01:31',103,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:31','2026-11-15 09:01:31',123,1,NULL,NULL,NULL,'2026-11-15 09:01:31','2026-11-15 09:01:31','5f75cd3ef25340f25'),('1dd1ad83f8b240cc8','Submit Popup Reminders',0,'Success','2026-11-15 09:05:38',168,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:05:38','2026-11-15 09:05:38',16,1,NULL,NULL,NULL,'2026-11-15 09:05:38','2026-11-15 09:05:38','bcd1c259a799fac87'),('1e1340e9744349265','Submit Popup Reminders',0,'Success','2026-11-15 09:00:21',82,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:21','2026-11-15 09:00:21',95,1,NULL,NULL,NULL,'2026-11-15 09:00:21','2026-11-15 09:00:21','bcd1c259a799fac87'),('1e210142d03984947','Submit Popup Reminders',0,'Success','2026-11-15 09:11:48',297,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:11:48','2026-11-15 09:11:48',182,1,NULL,NULL,NULL,'2026-11-15 09:11:48','2026-11-15 09:11:48','bcd1c259a799fac87'),('1e650be2bcff007ab','Send Email Notifications',0,'Pending','2026-11-15 09:30:00',517,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-11-15 09:28:11','2026-11-15 09:28:11','e9d6c9980d694fb42'),('1e89e20b2ce6d2473','Process Job Queue e0',0,'Success','2026-11-15 09:03:21',141,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:03:21','2026-11-15 09:03:21',172,1,NULL,NULL,NULL,'2026-11-15 09:03:21','2026-11-15 09:03:21','5f75cd3ef25340f25'),('1eb7eff3f903a6ee9','Process Job Queue e0',0,'Success','2026-11-15 09:12:08',304,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:08','2026-11-15 09:12:08',194,1,NULL,NULL,NULL,'2026-11-15 09:12:08','2026-11-15 09:12:08','5f75cd3ef25340f25'),('201d08b7f84e4d1cd','Process Job Queue q0',0,'Success','2026-11-15 09:19:28',455,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:19:28','2026-11-15 09:19:28',386,1,NULL,NULL,NULL,'2026-11-15 09:19:28','2026-11-15 09:19:28','5750be1f178c76fe9'),('21f4c95224f85cd7f','Auth Token Control',0,'Success','2026-11-15 09:12:00',182,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:08','2026-11-15 09:12:08',188,1,NULL,NULL,NULL,'2026-11-15 09:06:08','2026-11-15 09:12:08','eeb2498dde7129c23'),('21f9c3983009ed3f5','Process Job Queue q0',0,'Success','2026-11-15 09:10:48',276,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:48','2026-11-15 09:10:48',155,1,NULL,NULL,NULL,'2026-11-15 09:10:48','2026-11-15 09:10:48','5750be1f178c76fe9'),('225ae559652fb0b2a','Submit Popup Reminders',0,'Success','2026-11-15 09:02:11',120,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:11','2026-11-15 09:02:11',144,1,NULL,NULL,NULL,'2026-11-15 09:02:11','2026-11-15 09:02:11','bcd1c259a799fac87'),('22a27dc1f3f92151c','Send Email Reminders',0,'Success','2026-11-15 09:06:00',152,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:08','2026-11-15 09:06:08',27,1,NULL,NULL,NULL,'2026-11-15 09:04:01','2026-11-15 09:06:08','38c14103df40c8494'),('2349e85bc6e445a06','Process Job Queue q0',0,'Success','2026-11-15 09:02:11',118,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:11','2026-11-15 09:02:11',142,1,NULL,NULL,NULL,'2026-11-15 09:02:11','2026-11-15 09:02:11','5750be1f178c76fe9'),('237b7f885553cae1b','Submit Popup Reminders',0,'Success','2026-11-15 09:17:58',424,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:17:58','2026-11-15 09:17:58',346,1,NULL,NULL,NULL,'2026-11-15 09:17:58','2026-11-15 09:17:58','bcd1c259a799fac87'),('249fae1a708396349','Send Scheduled Emails',0,'Success','2026-11-15 09:20:00',264,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:08','2026-11-15 09:20:08',402,1,NULL,NULL,NULL,'2026-11-15 09:10:08','2026-11-15 09:20:08','c96bb4400337657cf'),('24a60154f189b260f','Process Job Queue q0',0,'Success','2026-11-15 09:10:18',267,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:18','2026-11-15 09:10:18',143,1,NULL,NULL,NULL,'2026-11-15 09:10:18','2026-11-15 09:10:18','5750be1f178c76fe9'),('24fda023116771f23','Process Job Queue q0',0,'Success','2026-11-15 09:10:28',270,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:28','2026-11-15 09:10:28',147,1,NULL,NULL,NULL,'2026-11-15 09:10:28','2026-11-15 09:10:28','5750be1f178c76fe9'),('2501bcf0c71218348','Submit Popup Reminders',0,'Success','2026-11-15 09:14:38',358,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:38','2026-11-15 09:14:38',260,1,NULL,NULL,NULL,'2026-11-15 09:14:38','2026-11-15 09:14:38','bcd1c259a799fac87'),('25c084d1c55f69f9b','Process Job Queue e0',0,'Success','2026-11-15 09:12:18',310,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:18','2026-11-15 09:12:18',198,1,NULL,NULL,NULL,'2026-11-15 09:12:18','2026-11-15 09:12:18','5f75cd3ef25340f25'),('26b6d6666dab50704','Submit Popup Reminders',0,'Success','2026-11-15 09:12:08',305,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:08','2026-11-15 09:12:08',195,1,NULL,NULL,NULL,'2026-11-15 09:12:08','2026-11-15 09:12:08','bcd1c259a799fac87'),('270790704a9a13f5e','Process Job Queue e0',0,'Success','2026-11-15 09:20:58',488,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:58','2026-11-15 09:20:58',428,1,NULL,NULL,NULL,'2026-11-15 09:20:58','2026-11-15 09:20:58','5f75cd3ef25340f25'),('28ed87ed384ff503e','Process Job Queue e0',0,'Success','2026-11-15 09:05:38',167,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:05:38','2026-11-15 09:05:38',15,1,NULL,NULL,NULL,'2026-11-15 09:05:38','2026-11-15 09:05:38','5f75cd3ef25340f25'),('29a6761824b1d6ad0','Submit Popup Reminders',0,'Success','2026-11-15 09:15:08',367,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:15:08','2026-11-15 09:15:08',273,1,NULL,NULL,NULL,'2026-11-15 09:15:08','2026-11-15 09:15:08','bcd1c259a799fac87'),('29b0701ce229e5098','Clean-up',0,'Pending','2026-11-21 20:01:00',2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 08:57:21','12bc3005413458351'),('2a8f282cdfd4fe51a','Send Scheduled Emails',0,'Success','2026-11-15 09:00:00',14,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:01','2026-11-15 09:00:01',79,1,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 09:00:01','c96bb4400337657cf'),('2a9aca0f1e51e66d4','Process Job Queue e0',0,'Success','2026-11-15 09:11:58',299,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:11:58','2026-11-15 09:11:58',185,1,NULL,NULL,NULL,'2026-11-15 09:11:58','2026-11-15 09:11:58','5f75cd3ef25340f25'),('2ae1796d92983d3e2','Process Job Queue q0',0,'Success','2026-11-15 09:13:38',334,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:13:38','2026-11-15 09:13:38',230,1,NULL,NULL,NULL,'2026-11-15 09:13:38','2026-11-15 09:13:38','5750be1f178c76fe9'),('2b5432c58e208b7b4','Process Job Queue e0',0,'Success','2026-11-15 09:02:11',119,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:11','2026-11-15 09:02:11',143,1,NULL,NULL,NULL,'2026-11-15 09:02:11','2026-11-15 09:02:11','5f75cd3ef25340f25'),('2b6b4904340eee86f','Submit Popup Reminders',0,'Success','2026-11-15 09:20:38',483,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:38','2026-11-15 09:20:38',421,1,NULL,NULL,NULL,'2026-11-15 09:20:38','2026-11-15 09:20:38','bcd1c259a799fac87'),('2c95dfe29ec04b7c4','Control Knowledge Base Article Status',0,'Pending','2026-11-15 20:10:00',10,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 08:57:21','84fc0d8a0ff896000'),('2d01f881811f08655','Submit Popup Reminders',0,'Success','2026-11-15 09:27:51',508,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:27:51','2026-11-15 09:27:51',21,1,NULL,NULL,NULL,'2026-11-15 09:27:51','2026-11-15 09:27:51','bcd1c259a799fac87'),('2d11d75b9620a1891','Submit Popup Reminders',0,'Success','2026-11-15 09:18:58',447,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:58','2026-11-15 09:18:58',375,1,NULL,NULL,NULL,'2026-11-15 09:18:58','2026-11-15 09:18:58','bcd1c259a799fac87'),('2dcd339e9c8b87d86','Process Job Queue q0',0,'Success','2026-11-15 09:16:58',403,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:58','2026-11-15 09:16:58',319,1,NULL,NULL,NULL,'2026-11-15 09:16:58','2026-11-15 09:16:58','5750be1f178c76fe9'),('2e0bf79f670e9dc93','Process Job Queue q0',0,'Success','2026-11-15 09:08:38',230,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:38','2026-11-15 09:08:38',96,1,NULL,NULL,NULL,'2026-11-15 09:08:38','2026-11-15 09:08:38','5750be1f178c76fe9'),('2e35718076cec3d9b','Send Email Notifications',0,'Success','2026-11-15 09:00:00',32,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:01','2026-11-15 09:00:01',83,1,NULL,NULL,NULL,'2026-11-15 08:58:01','2026-11-15 09:00:01','e9d6c9980d694fb42'),('2e8b2dee96a7906a7','Submit Popup Reminders',0,'Success','2026-11-15 08:58:31',42,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:31','2026-11-15 08:58:31',44,1,NULL,NULL,NULL,'2026-11-15 08:58:31','2026-11-15 08:58:31','bcd1c259a799fac87'),('2ec3238203639aca7','Submit Popup Reminders',0,'Success','2026-11-15 09:00:01',72,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:01','2026-11-15 09:00:02',87,1,NULL,NULL,NULL,'2026-11-15 09:00:01','2026-11-15 09:00:02','bcd1c259a799fac87'),('2ecd4417d6b320b88','Submit Popup Reminders',0,'Success','2026-11-15 08:59:01',51,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:59:01','2026-11-15 08:59:01',57,1,NULL,NULL,NULL,'2026-11-15 08:59:01','2026-11-15 08:59:01','bcd1c259a799fac87'),('2f49729e5cf2b3eb7','Process Job Queue q0',0,'Success','2026-11-15 08:58:01',29,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:01','2026-11-15 08:58:01',30,1,NULL,NULL,NULL,'2026-11-15 08:58:01','2026-11-15 08:58:01','5750be1f178c76fe9'),('2fb969a1a7a018fb0','Process Job Queue e0',0,'Success','2026-11-15 09:00:31',84,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:31','2026-11-15 09:00:31',98,1,NULL,NULL,NULL,'2026-11-15 09:00:31','2026-11-15 09:00:31','5f75cd3ef25340f25'),('2fe621a079f411439','Submit Popup Reminders',0,'Success','2026-11-15 09:10:48',278,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:48','2026-11-15 09:10:48',157,1,NULL,NULL,NULL,'2026-11-15 09:10:48','2026-11-15 09:10:48','bcd1c259a799fac87'),('313b73ad8a3fd7ed5','Process Job Queue e0',0,'Success','2026-11-15 09:11:08',283,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:11:08','2026-11-15 09:11:08',165,1,NULL,NULL,NULL,'2026-11-15 09:11:08','2026-11-15 09:11:08','5f75cd3ef25340f25'),('317689c394376b610','Process Job Queue q1',0,'Success','2026-11-15 09:06:00',165,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:08','2026-11-15 09:06:08',30,1,NULL,NULL,NULL,'2026-11-15 09:05:28','2026-11-15 09:06:08','ea1678c7ea92717de'),('32587ecb8dbd6aadd','Submit Popup Reminders',0,'Success','2026-11-15 08:59:41',64,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:59:41','2026-11-15 08:59:41',73,1,NULL,NULL,NULL,'2026-11-15 08:59:41','2026-11-15 08:59:41','bcd1c259a799fac87'),('32d5666127989eaa8','Process Job Queue q0',0,'Success','2026-11-15 09:01:51',108,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:51','2026-11-15 09:01:51',130,1,NULL,NULL,NULL,'2026-11-15 09:01:51','2026-11-15 09:01:51','5750be1f178c76fe9'),('32e2ac827da4cb7fe','Process Job Queue q1',0,'Success','2026-11-15 09:21:00',474,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:27:42','2026-11-15 09:27:42',16,1,NULL,NULL,NULL,'2026-11-15 09:20:08','2026-11-15 09:27:42','ea1678c7ea92717de'),('3360a041ad0ff9a0d','Process Job Queue e0',0,'Success','2026-11-15 09:16:58',404,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:58','2026-11-15 09:16:58',320,1,NULL,NULL,NULL,'2026-11-15 09:16:58','2026-11-15 09:16:58','5f75cd3ef25340f25'),('34859b7a95f11611e','Process Job Queue q1',0,'Success','2026-11-15 09:07:00',181,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:07:08','2026-11-15 09:07:08',55,1,NULL,NULL,NULL,'2026-11-15 09:06:08','2026-11-15 09:07:08','ea1678c7ea92717de'),('34f536f350908df95','Process Job Queue q0',0,'Success','2026-11-15 09:10:08',260,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:08','2026-11-15 09:10:08',139,1,NULL,NULL,NULL,'2026-11-15 09:10:08','2026-11-15 09:10:08','5750be1f178c76fe9'),('352b4aaae7271b667','Process Job Queue e0',0,'Success','2026-11-15 09:02:21',122,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:21','2026-11-15 09:02:21',147,1,NULL,NULL,NULL,'2026-11-15 09:02:21','2026-11-15 09:02:21','5f75cd3ef25340f25'),('36df2c5431add668e','Submit Popup Reminders',0,'Success','2026-11-15 09:14:18',352,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:18','2026-11-15 09:14:18',252,1,NULL,NULL,NULL,'2026-11-15 09:14:18','2026-11-15 09:14:18','bcd1c259a799fac87'),('370918aa599f429f1','Process Job Queue q0',0,'Success','2026-11-15 09:12:38',315,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:38','2026-11-15 09:12:38',205,1,NULL,NULL,NULL,'2026-11-15 09:12:38','2026-11-15 09:12:38','5750be1f178c76fe9'),('38000ead959e6a28a','Process Job Queue q1',0,'Success','2026-11-15 09:20:00',451,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:08','2026-11-15 09:20:08',406,1,NULL,NULL,NULL,'2026-11-15 09:19:08','2026-11-15 09:20:08','ea1678c7ea92717de'),('385de3e476c6edcf0','Process Job Queue e0',0,'Success','2026-11-15 08:58:41',44,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:41','2026-11-15 08:58:41',47,1,NULL,NULL,NULL,'2026-11-15 08:58:41','2026-11-15 08:58:41','5f75cd3ef25340f25'),('39093e6b1f7bb89cb','Submit Popup Reminders',0,'Success','2026-11-15 08:58:11',36,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:11','2026-11-15 08:58:11',36,1,NULL,NULL,NULL,'2026-11-15 08:58:11','2026-11-15 08:58:11','bcd1c259a799fac87'),('393998e2c6e3e15a5','Process Job Queue q0',0,'Success','2026-11-15 09:19:48',461,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:19:48','2026-11-15 09:19:48',394,1,NULL,NULL,NULL,'2026-11-15 09:19:48','2026-11-15 09:19:48','5750be1f178c76fe9'),('3954c381444351949','Process Job Queue q0',0,'Success','2026-11-15 09:13:58',340,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:13:58','2026-11-15 09:13:58',238,1,NULL,NULL,NULL,'2026-11-15 09:13:58','2026-11-15 09:13:58','5750be1f178c76fe9'),('396446ded395b4587','Send Email Reminders',0,'Success','2026-11-15 09:04:00',111,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:04:01','2026-11-15 09:04:01',187,1,NULL,NULL,NULL,'2026-11-15 09:02:01','2026-11-15 09:04:01','38c14103df40c8494'),('3a77a2d20bdc0db39','Process Job Queue e0',0,'Success','2026-11-15 09:10:08',261,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:08','2026-11-15 09:10:08',140,1,NULL,NULL,NULL,'2026-11-15 09:10:08','2026-11-15 09:10:08','5f75cd3ef25340f25'),('3b3a71e5615555037','Process Job Queue e0',0,'Success','2026-11-15 09:01:11',97,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:11','2026-11-15 09:01:11',115,1,NULL,NULL,NULL,'2026-11-15 09:01:11','2026-11-15 09:01:11','5f75cd3ef25340f25'),('3bc90a3cda8f41b76','Process Job Queue e0',0,'Success','2026-11-15 09:28:11',515,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:28:11','2026-11-15 09:28:11',28,1,NULL,NULL,NULL,'2026-11-15 09:28:11','2026-11-15 09:28:11','5f75cd3ef25340f25'),('3c07c840b1ead4c1d','Process Job Queue e0',0,'Success','2026-11-15 09:08:38',231,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:38','2026-11-15 09:08:38',97,1,NULL,NULL,NULL,'2026-11-15 09:08:38','2026-11-15 09:08:38','5f75cd3ef25340f25'),('3c590d40c0561683d','Submit Popup Reminders',0,'Success','2026-11-15 09:08:48',235,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:48','2026-11-15 09:08:48',102,1,NULL,NULL,NULL,'2026-11-15 09:08:48','2026-11-15 09:08:48','bcd1c259a799fac87'),('3c6ab4a52bcc5e556','Process Job Queue q0',0,'Success','2026-11-15 09:03:41',146,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:03:41','2026-11-15 09:03:41',179,1,NULL,NULL,NULL,'2026-11-15 09:03:41','2026-11-15 09:03:41','5750be1f178c76fe9'),('3db73029eb6ece598','Process Job Queue q0',0,'Success','2026-11-15 09:03:51',149,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:03:51','2026-11-15 09:03:51',183,1,NULL,NULL,NULL,'2026-11-15 09:03:51','2026-11-15 09:03:51','5750be1f178c76fe9'),('3dcad0587043fe5bf','Dummy',0,'Pending','2026-11-15 19:01:00',11,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 08:57:21','8acb9d4370891b421'),('3dd6d5c7bc6934b2a','Process Job Queue e0',0,'Success','2026-11-15 09:13:48',338,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:13:48','2026-11-15 09:13:48',235,1,NULL,NULL,NULL,'2026-11-15 09:13:48','2026-11-15 09:13:48','5f75cd3ef25340f25'),('3ee67c424a2401f91','Process Job Queue q0',0,'Success','2026-11-15 09:09:08',239,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:09:08','2026-11-15 09:09:08',109,1,NULL,NULL,NULL,'2026-11-15 09:09:08','2026-11-15 09:09:08','5750be1f178c76fe9'),('3f214e0d4ffef5f7d','Process Job Queue e0',0,'Success','2026-11-15 09:02:31',125,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:31','2026-11-15 09:02:31',151,1,NULL,NULL,NULL,'2026-11-15 09:02:31','2026-11-15 09:02:31','5f75cd3ef25340f25'),('3fc07380a0af0d8f0','Process Job Queue q0',0,'Success','2026-11-15 09:11:58',298,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:11:58','2026-11-15 09:11:58',184,1,NULL,NULL,NULL,'2026-11-15 09:11:58','2026-11-15 09:11:58','5750be1f178c76fe9'),('403c9b54e87b00cd4','Submit Popup Reminders',0,'Success','2026-11-15 08:58:01',31,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:01','2026-11-15 08:58:01',32,1,NULL,NULL,NULL,'2026-11-15 08:58:01','2026-11-15 08:58:01','bcd1c259a799fac87'),('40e03837b1ffbefd2','Process Job Queue q0',0,'Success','2026-11-15 09:03:01',133,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:03:01','2026-11-15 09:03:01',163,1,NULL,NULL,NULL,'2026-11-15 09:03:01','2026-11-15 09:03:01','5750be1f178c76fe9'),('411484a98cce7ad71','Submit Popup Reminders',0,'Success','2026-11-15 09:28:11',516,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:28:11','2026-11-15 09:28:11',29,1,NULL,NULL,NULL,'2026-11-15 09:28:11','2026-11-15 09:28:11','bcd1c259a799fac87'),('418e4e84d0f2a676a','Process Job Queue e0',0,'Success','2026-11-15 09:20:28',479,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:28','2026-11-15 09:20:28',416,1,NULL,NULL,NULL,'2026-11-15 09:20:28','2026-11-15 09:20:28','5f75cd3ef25340f25'),('42bfb1fc6efa0a29a','Process Job Queue q0',0,'Success','2026-11-15 09:07:08',198,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:07:08','2026-11-15 09:07:08',56,1,NULL,NULL,NULL,'2026-11-15 09:07:08','2026-11-15 09:07:08','5750be1f178c76fe9'),('42e251e72d2306070','Submit Popup Reminders',0,'Success','2026-11-15 09:19:58',466,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:19:58','2026-11-15 09:19:58',400,1,NULL,NULL,NULL,'2026-11-15 09:19:58','2026-11-15 09:19:58','bcd1c259a799fac87'),('43885477f476d2fb7','Process Job Queue q0',0,'Success','2026-11-15 09:05:48',169,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:05:48','2026-11-15 09:05:48',18,1,NULL,NULL,NULL,'2026-11-15 09:05:48','2026-11-15 09:05:48','5750be1f178c76fe9'),('439312522fe37814d','Process Job Queue e0',0,'Success','2026-11-15 09:13:38',335,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:13:38','2026-11-15 09:13:38',231,1,NULL,NULL,NULL,'2026-11-15 09:13:38','2026-11-15 09:13:38','5f75cd3ef25340f25'),('43ad8f66a3be7d33c','Submit Popup Reminders',0,'Success','2026-11-15 09:06:48',194,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:48','2026-11-15 09:06:48',49,1,NULL,NULL,NULL,'2026-11-15 09:06:48','2026-11-15 09:06:48','bcd1c259a799fac87'),('43b583049ceb85903','Process Job Queue e0',0,'Success','2026-11-15 09:15:18',370,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:15:18','2026-11-15 09:15:18',276,1,NULL,NULL,NULL,'2026-11-15 09:15:18','2026-11-15 09:15:18','5f75cd3ef25340f25'),('44cadb01ef79e8bbc','Process Job Queue q0',0,'Success','2026-11-15 09:28:11',514,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:28:11','2026-11-15 09:28:11',27,1,NULL,NULL,NULL,'2026-11-15 09:28:11','2026-11-15 09:28:11','5750be1f178c76fe9'),('45162cd2ee3ae9fce','Check for New Versions of Installed Extensions',0,'Pending','2026-11-16 00:25:00',5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 08:57:21','3991133e504330b53'),('45342819607ed839c','Process Job Queue e0',0,'Success','2026-11-15 09:19:08',449,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:19:08','2026-11-15 09:19:08',379,1,NULL,NULL,NULL,'2026-11-15 09:19:08','2026-11-15 09:19:08','5f75cd3ef25340f25'),('457e71a7cd9c6e64b','Process Job Queue e0',0,'Success','2026-11-15 08:57:51',25,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:57:51','2026-11-15 08:57:51',23,1,NULL,NULL,NULL,'2026-11-15 08:57:51','2026-11-15 08:57:51','5f75cd3ef25340f25'),('460f6d8cb2c33f8df','Process Job Queue q0',0,'Success','2026-11-15 09:02:31',124,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:31','2026-11-15 09:02:31',150,1,NULL,NULL,NULL,'2026-11-15 09:02:31','2026-11-15 09:02:31','5750be1f178c76fe9'),('4658335560396e779','Submit Popup Reminders',0,'Success','2026-11-15 09:14:48',361,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:48','2026-11-15 09:14:48',264,1,NULL,NULL,NULL,'2026-11-15 09:14:48','2026-11-15 09:14:48','bcd1c259a799fac87'),('46599dce0d9a69f61','Process Job Queue q0',0,'Success','2026-11-15 09:09:38',249,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:09:38','2026-11-15 09:09:38',121,1,NULL,NULL,NULL,'2026-11-15 09:09:38','2026-11-15 09:09:38','5750be1f178c76fe9'),('46dad04b97ea54fd4','Process Job Queue e0',0,'Success','2026-11-15 09:17:28',414,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:17:28','2026-11-15 09:17:28',333,1,NULL,NULL,NULL,'2026-11-15 09:17:28','2026-11-15 09:17:28','5f75cd3ef25340f25'),('48a45c0495ed3b965','Process Job Queue q0',0,'Success','2026-11-15 08:59:21',56,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:59:21','2026-11-15 08:59:21',63,1,NULL,NULL,NULL,'2026-11-15 08:59:21','2026-11-15 08:59:21','5750be1f178c76fe9'),('4957c088e35ffdb42','Process Job Queue q0',0,'Success','2026-11-15 09:20:38',481,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:38','2026-11-15 09:20:38',419,1,NULL,NULL,NULL,'2026-11-15 09:20:38','2026-11-15 09:20:38','5750be1f178c76fe9'),('4be7cfd7c032fe082','Process Job Queue q0',0,'Success','2026-11-15 08:58:11',34,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:11','2026-11-15 08:58:11',34,1,NULL,NULL,NULL,'2026-11-15 08:58:11','2026-11-15 08:58:11','5750be1f178c76fe9'),('4bef68c857141f47a','Submit Popup Reminders',0,'Success','2026-11-15 08:57:31',20,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:57:31','2026-11-15 08:57:31',16,1,NULL,NULL,NULL,'2026-11-15 08:57:31','2026-11-15 08:57:31','bcd1c259a799fac87'),('4c130953962c23371','Send Email Reminders',0,'Success','2026-11-15 09:10:00',217,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:08','2026-11-15 09:10:08',135,1,NULL,NULL,NULL,'2026-11-15 09:08:08','2026-11-15 09:10:08','38c14103df40c8494'),('4c81e04e0576ee495','Process Job Queue q0',0,'Success','2026-11-15 09:17:38',416,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:17:38','2026-11-15 09:17:38',336,1,NULL,NULL,NULL,'2026-11-15 09:17:38','2026-11-15 09:17:38','5750be1f178c76fe9'),('4ce987e43ca9e70e2','Process Job Queue e0',0,'Success','2026-11-15 09:20:38',482,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:38','2026-11-15 09:20:38',420,1,NULL,NULL,NULL,'2026-11-15 09:20:38','2026-11-15 09:20:38','5f75cd3ef25340f25'),('4d0de56ab0aa7e5aa','Submit Popup Reminders',0,'Success','2026-11-15 08:59:51',67,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:59:51','2026-11-15 08:59:51',77,1,NULL,NULL,NULL,'2026-11-15 08:59:51','2026-11-15 08:59:51','bcd1c259a799fac87'),('4d1316816dc24ce99','Process Job Queue q0',0,'Success','2026-11-15 09:16:38',397,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:38','2026-11-15 09:16:38',311,1,NULL,NULL,NULL,'2026-11-15 09:16:38','2026-11-15 09:16:38','5750be1f178c76fe9'),('4d8009bb0dae7ed4c','Process Job Queue q0',0,'Success','2026-11-15 09:09:58',255,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:09:58','2026-11-15 09:09:58',129,1,NULL,NULL,NULL,'2026-11-15 09:09:58','2026-11-15 09:09:58','5750be1f178c76fe9'),('4de2550091501250c','Process Job Queue e0',0,'Success','2026-11-15 08:59:41',63,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:59:41','2026-11-15 08:59:41',72,1,NULL,NULL,NULL,'2026-11-15 08:59:41','2026-11-15 08:59:41','5f75cd3ef25340f25'),('4e4125bc11c5d91cf','Process Job Queue q0',0,'Success','2026-11-15 09:13:28',331,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:13:28','2026-11-15 09:13:28',226,1,NULL,NULL,NULL,'2026-11-15 09:13:28','2026-11-15 09:13:28','5750be1f178c76fe9'),('4e6d2c9412f0008bf','Process Job Queue e0',0,'Success','2026-11-15 09:08:18',225,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:18','2026-11-15 09:08:18',89,1,NULL,NULL,NULL,'2026-11-15 09:08:18','2026-11-15 09:08:18','5f75cd3ef25340f25'),('4eac8568d7cd30a2f','Submit Popup Reminders',0,'Success','2026-11-15 09:16:18',393,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:18','2026-11-15 09:16:18',305,1,NULL,NULL,NULL,'2026-11-15 09:16:18','2026-11-15 09:16:18','bcd1c259a799fac87'),('4ebad90e0e63c0e85','Submit Popup Reminders',0,'Success','2026-11-15 08:57:51',26,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:57:51','2026-11-15 08:57:51',24,1,NULL,NULL,NULL,'2026-11-15 08:57:51','2026-11-15 08:57:51','bcd1c259a799fac87'),('4f6237883673a3140','Process Job Queue e0',0,'Success','2026-11-15 08:59:11',54,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:59:11','2026-11-15 08:59:11',60,1,NULL,NULL,NULL,'2026-11-15 08:59:11','2026-11-15 08:59:11','5f75cd3ef25340f25'),('4f686a2bcd2f334f6','Submit Popup Reminders',0,'Success','2026-11-15 09:18:08',429,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:08','2026-11-15 09:18:08',355,1,NULL,NULL,NULL,'2026-11-15 09:18:08','2026-11-15 09:18:08','bcd1c259a799fac87'),('4f99306bfaafe42a6','Process Job Queue e0',0,'Success','2026-11-15 09:00:51',90,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:51','2026-11-15 09:00:51',106,1,NULL,NULL,NULL,'2026-11-15 09:00:51','2026-11-15 09:00:51','5f75cd3ef25340f25'),('503dd7105b07c0749','Submit Popup Reminders',0,'Success','2026-11-15 09:02:21',123,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:21','2026-11-15 09:02:21',148,1,NULL,NULL,NULL,'2026-11-15 09:02:21','2026-11-15 09:02:21','bcd1c259a799fac87'),('50d0fe3d3fce7efdc','Submit Popup Reminders',0,'Success','2026-11-15 09:17:08',408,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:17:08','2026-11-15 09:17:08',326,1,NULL,NULL,NULL,'2026-11-15 09:17:08','2026-11-15 09:17:08','bcd1c259a799fac87'),('515ea2e111135b15d','Process Job Queue q0',0,'Success','2026-11-15 09:18:08',427,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:08','2026-11-15 09:18:08',353,1,NULL,NULL,NULL,'2026-11-15 09:18:08','2026-11-15 09:18:08','5750be1f178c76fe9'),('51a944c2eefa540f3','Process Job Queue q0',0,'Success','2026-11-15 09:10:38',273,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:38','2026-11-15 09:10:38',151,1,NULL,NULL,NULL,'2026-11-15 09:10:38','2026-11-15 09:10:38','5750be1f178c76fe9'),('5234b1de4193d4013','Submit Popup Reminders',0,'Success','2026-11-15 09:17:48',421,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:17:48','2026-11-15 09:17:48',342,1,NULL,NULL,NULL,'2026-11-15 09:17:48','2026-11-15 09:17:48','bcd1c259a799fac87'),('523ea59c9ecbd8781','Process Webhook Queue',0,'Success','2026-11-15 09:22:00',468,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:27:42','2026-11-15 09:27:42',14,1,NULL,NULL,NULL,'2026-11-15 09:20:08','2026-11-15 09:27:42','4a6a036f21dffd48a'),('5268e1beffde6f999','Submit Popup Reminders',0,'Success','2026-11-15 08:58:41',45,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:41','2026-11-15 08:58:41',48,1,NULL,NULL,NULL,'2026-11-15 08:58:41','2026-11-15 08:58:41','bcd1c259a799fac87'),('5281ee302ee83c56b','Process Job Queue q1',0,'Success','2026-11-15 08:59:00',33,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:59:01','2026-11-15 08:59:01',54,1,NULL,NULL,NULL,'2026-11-15 08:58:01','2026-11-15 08:59:01','ea1678c7ea92717de'),('52d278655a9cf5938','Process Job Queue q1',0,'Success','2026-11-15 09:04:00',136,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:04:01','2026-11-15 09:04:01',190,1,NULL,NULL,NULL,'2026-11-15 09:03:01','2026-11-15 09:04:01','ea1678c7ea92717de'),('52d28351ac175f0ab','Submit Popup Reminders',0,'Success','2026-11-15 09:14:28',355,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:28','2026-11-15 09:14:28',256,1,NULL,NULL,NULL,'2026-11-15 09:14:28','2026-11-15 09:14:28','bcd1c259a799fac87'),('537fd79b7fc817202','Send Email Reminders',0,'Success','2026-11-15 09:14:00',301,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:08','2026-11-15 09:14:08',242,1,NULL,NULL,NULL,'2026-11-15 09:12:08','2026-11-15 09:14:08','38c14103df40c8494'),('546086ad719a67ca0','Process Job Queue q0',0,'Success','2026-11-15 09:14:08',345,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:08','2026-11-15 09:14:08',246,1,NULL,NULL,NULL,'2026-11-15 09:14:08','2026-11-15 09:14:08','5750be1f178c76fe9'),('5474aa5d1367ae0bd','Submit Popup Reminders',0,'Success','2026-11-15 09:00:41',88,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:41','2026-11-15 09:00:41',103,1,NULL,NULL,NULL,'2026-11-15 09:00:41','2026-11-15 09:00:41','bcd1c259a799fac87'),('551afdcf18decf2ab','Send Email Reminders',0,'Success','2026-11-15 08:58:00',4,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:01','2026-11-15 08:58:01',26,1,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 08:58:01','38c14103df40c8494'),('55fc0697b1df27440','Submit Popup Reminders',0,'Success','2026-11-15 09:28:01',511,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:28:01','2026-11-15 09:28:01',25,1,NULL,NULL,NULL,'2026-11-15 09:28:01','2026-11-15 09:28:01','bcd1c259a799fac87'),('56460c456e8b4e4d4','Process Job Queue e0',0,'Success','2026-11-15 09:13:58',341,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:13:58','2026-11-15 09:13:58',239,1,NULL,NULL,NULL,'2026-11-15 09:13:58','2026-11-15 09:13:58','5f75cd3ef25340f25'),('564baec30a0f7a822','Submit Popup Reminders',0,'Success','2026-11-15 09:11:28',291,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:11:28','2026-11-15 09:11:28',174,1,NULL,NULL,NULL,'2026-11-15 09:11:28','2026-11-15 09:11:28','bcd1c259a799fac87'),('56b295c970d2ff609','Send Mass Emails',0,'Pending','2026-11-15 09:30:00',262,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-11-15 09:10:08','2026-11-15 09:10:08','8413c58638261267b'),('5779b301975a04c39','Process Job Queue e0',0,'Success','2026-11-15 09:19:18',453,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:19:18','2026-11-15 09:19:18',383,1,NULL,NULL,NULL,'2026-11-15 09:19:18','2026-11-15 09:19:18','5f75cd3ef25340f25'),('57aa46a6810254365','Process Job Queue q1',0,'Success','2026-11-15 09:10:00',242,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:08','2026-11-15 09:10:08',138,1,NULL,NULL,NULL,'2026-11-15 09:09:08','2026-11-15 09:10:08','ea1678c7ea92717de'),('57b38a1d0abcaef74','Process Job Queue e0',0,'Success','2026-11-15 09:00:41',87,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:41','2026-11-15 09:00:41',102,1,NULL,NULL,NULL,'2026-11-15 09:00:41','2026-11-15 09:00:41','5f75cd3ef25340f25'),('58268cd4cdfdadbf7','Process Job Queue q0',0,'Success','2026-11-15 09:08:58',236,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:58','2026-11-15 09:08:58',104,1,NULL,NULL,NULL,'2026-11-15 09:08:58','2026-11-15 09:08:58','5750be1f178c76fe9'),('5850bfe716c86e2a5','Submit Popup Reminders',0,'Success','2026-11-15 09:07:18',204,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:07:18','2026-11-15 09:07:18',62,1,NULL,NULL,NULL,'2026-11-15 09:07:18','2026-11-15 09:07:18','bcd1c259a799fac87'),('5875cd26bd0381339','Process Job Queue e0',0,'Success','2026-11-15 09:10:38',274,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:38','2026-11-15 09:10:38',152,1,NULL,NULL,NULL,'2026-11-15 09:10:38','2026-11-15 09:10:38','5f75cd3ef25340f25'),('588f22a454d75642f','Process Job Queue q0',0,'Success','2026-11-15 09:02:21',121,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:21','2026-11-15 09:02:21',146,1,NULL,NULL,NULL,'2026-11-15 09:02:21','2026-11-15 09:02:21','5750be1f178c76fe9'),('58c9f11405ac7582f','Process Job Queue e0',0,'Success','2026-11-15 09:00:11',78,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:11','2026-11-15 09:00:11',90,1,NULL,NULL,NULL,'2026-11-15 09:00:11','2026-11-15 09:00:11','5f75cd3ef25340f25'),('594f8905076354c43','Process Job Queue q0',0,'Success','2026-11-15 09:05:58',172,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:05:58','2026-11-15 09:05:58',22,1,NULL,NULL,NULL,'2026-11-15 09:05:58','2026-11-15 09:05:58','5750be1f178c76fe9'),('59a4397d2ef0c827a','Process Job Queue q0',0,'Success','2026-11-15 09:00:51',89,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:51','2026-11-15 09:00:51',105,1,NULL,NULL,NULL,'2026-11-15 09:00:51','2026-11-15 09:00:51','5750be1f178c76fe9'),('5a31e42a7e9475b94','Submit Popup Reminders',0,'Success','2026-11-15 09:03:21',142,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:03:21','2026-11-15 09:03:21',173,1,NULL,NULL,NULL,'2026-11-15 09:03:21','2026-11-15 09:03:21','bcd1c259a799fac87'),('5ae7f3a5307e6b012','Process Job Queue q0',0,'Success','2026-11-15 09:08:08',219,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:08','2026-11-15 09:08:08',84,1,NULL,NULL,NULL,'2026-11-15 09:08:08','2026-11-15 09:08:08','5750be1f178c76fe9'),('5b9c4fdfc01c5ff8a','Process Job Queue q0',0,'Success','2026-11-15 09:01:01',92,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:01','2026-11-15 09:01:01',110,1,NULL,NULL,NULL,'2026-11-15 09:01:01','2026-11-15 09:01:01','5750be1f178c76fe9'),('5c03a6c45074c7ad2','Submit Popup Reminders',0,'Success','2026-11-15 09:00:31',85,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:31','2026-11-15 09:00:31',99,1,NULL,NULL,NULL,'2026-11-15 09:00:31','2026-11-15 09:00:31','bcd1c259a799fac87'),('5c3b602b490aff2f6','Process Job Queue e0',0,'Success','2026-11-15 08:58:11',35,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:11','2026-11-15 08:58:11',35,1,NULL,NULL,NULL,'2026-11-15 08:58:11','2026-11-15 08:58:11','5f75cd3ef25340f25'),('5cdb62e4f73c85ace','Process Job Queue e0',0,'Success','2026-11-15 09:11:38',293,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:11:38','2026-11-15 09:11:38',177,1,NULL,NULL,NULL,'2026-11-15 09:11:38','2026-11-15 09:11:38','5f75cd3ef25340f25'),('5d8d36bf7d14f6e11','Process Job Queue q1',0,'Success','2026-11-15 09:08:00',201,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:08','2026-11-15 09:08:08',83,1,NULL,NULL,NULL,'2026-11-15 09:07:08','2026-11-15 09:08:08','ea1678c7ea92717de'),('5ebf1b9e8a77e7220','Process Job Queue q0',0,'Success','2026-11-15 09:18:18',433,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:18','2026-11-15 09:18:18',357,1,NULL,NULL,NULL,'2026-11-15 09:18:18','2026-11-15 09:18:18','5750be1f178c76fe9'),('5f0a40b69d80575dd','Submit Popup Reminders',0,'Success','2026-11-15 09:04:11',161,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:04:11','2026-11-15 09:04:11',197,1,NULL,NULL,NULL,'2026-11-15 09:04:11','2026-11-15 09:04:11','bcd1c259a799fac87'),('5f31e29056b613498','Process Job Queue e0',0,'Success','2026-11-15 09:01:21',100,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:21','2026-11-15 09:01:21',119,1,NULL,NULL,NULL,'2026-11-15 09:01:21','2026-11-15 09:01:21','5f75cd3ef25340f25'),('5f52cfbc8cbb644d1','Submit Popup Reminders',0,'Success','2026-11-15 09:13:58',342,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:13:58','2026-11-15 09:13:58',240,1,NULL,NULL,NULL,'2026-11-15 09:13:58','2026-11-15 09:13:58','bcd1c259a799fac87'),('604c831cdea95d146','Process Job Queue q0',0,'Success','2026-11-15 09:18:28',436,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:28','2026-11-15 09:18:28',361,1,NULL,NULL,NULL,'2026-11-15 09:18:28','2026-11-15 09:18:28','5750be1f178c76fe9'),('60c978761e1568ed7','Process Job Queue q0',0,'Success','2026-11-15 09:13:08',324,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:13:08','2026-11-15 09:13:08',218,1,NULL,NULL,NULL,'2026-11-15 09:13:08','2026-11-15 09:13:08','5750be1f178c76fe9'),('6128f81261f75a5a5','Submit Popup Reminders',0,'Success','2026-11-15 09:15:38',377,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:15:38','2026-11-15 09:15:38',285,1,NULL,NULL,NULL,'2026-11-15 09:15:38','2026-11-15 09:15:38','bcd1c259a799fac87'),('61988e67f4bc075a8','Process Job Queue q0',0,'Success','2026-11-15 09:10:58',279,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:58','2026-11-15 09:10:58',159,1,NULL,NULL,NULL,'2026-11-15 09:10:58','2026-11-15 09:10:58','5750be1f178c76fe9'),('61c808fe5f3852aa4','Process Job Queue e0',0,'Success','2026-11-15 08:58:51',47,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:51','2026-11-15 08:58:51',51,1,NULL,NULL,NULL,'2026-11-15 08:58:51','2026-11-15 08:58:51','5f75cd3ef25340f25'),('62344c9b37a1ee123','Process Job Queue e0',0,'Success','2026-11-15 09:12:28',313,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:28','2026-11-15 09:12:28',202,1,NULL,NULL,NULL,'2026-11-15 09:12:28','2026-11-15 09:12:28','5f75cd3ef25340f25'),('62475da6ca2fe8322','Submit Popup Reminders',0,'Success','2026-11-15 09:16:58',405,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:58','2026-11-15 09:16:58',321,1,NULL,NULL,NULL,'2026-11-15 09:16:58','2026-11-15 09:16:58','bcd1c259a799fac87'),('62b0a1d1a95800af0','Submit Popup Reminders',0,'Success','2026-11-15 09:20:58',489,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:58','2026-11-15 09:20:58',429,1,NULL,NULL,NULL,'2026-11-15 09:20:58','2026-11-15 09:20:58','bcd1c259a799fac87'),('6447dce0f20340775','Submit Popup Reminders',0,'Success','2026-11-15 09:01:01',94,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:01','2026-11-15 09:01:01',112,1,NULL,NULL,NULL,'2026-11-15 09:01:01','2026-11-15 09:01:01','bcd1c259a799fac87'),('6668b014375dfdb60','Submit Popup Reminders',0,'Success','2026-11-15 09:01:51',110,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:51','2026-11-15 09:01:51',132,1,NULL,NULL,NULL,'2026-11-15 09:01:51','2026-11-15 09:01:51','bcd1c259a799fac87'),('685d425c72a685ca6','Process Job Queue e0',0,'Success','2026-11-15 09:07:08',199,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:07:08','2026-11-15 09:07:08',57,1,NULL,NULL,NULL,'2026-11-15 09:07:08','2026-11-15 09:07:08','5f75cd3ef25340f25'),('688462a62d2402f24','Process Job Queue e0',0,'Success','2026-11-15 09:15:08',366,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:15:08','2026-11-15 09:15:08',272,1,NULL,NULL,NULL,'2026-11-15 09:15:08','2026-11-15 09:15:08','5f75cd3ef25340f25'),('68ad96aaba9f8eee1','Submit Popup Reminders',0,'Success','2026-11-15 09:04:01',156,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:04:01','2026-11-15 09:04:01',193,1,NULL,NULL,NULL,'2026-11-15 09:04:01','2026-11-15 09:04:01','bcd1c259a799fac87'),('69413f05cc30993ac','Process Job Queue e0',0,'Success','2026-11-15 09:08:58',237,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:58','2026-11-15 09:08:58',105,1,NULL,NULL,NULL,'2026-11-15 09:08:58','2026-11-15 09:08:58','5f75cd3ef25340f25'),('69a3b318d371289ed','Process Job Queue e0',0,'Success','2026-11-15 09:17:18',411,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:17:18','2026-11-15 09:17:18',329,1,NULL,NULL,NULL,'2026-11-15 09:17:18','2026-11-15 09:17:18','5f75cd3ef25340f25'),('6a45becb62c3f8df1','Send Email Notifications',0,'Success','2026-11-15 09:22:00',473,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:27:42','2026-11-15 09:27:42',15,1,NULL,NULL,NULL,'2026-11-15 09:20:08','2026-11-15 09:27:42','e9d6c9980d694fb42'),('6a7c60579372f3b0d','Process Job Queue e0',0,'Success','2026-11-15 09:07:18',203,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:07:18','2026-11-15 09:07:18',61,1,NULL,NULL,NULL,'2026-11-15 09:07:18','2026-11-15 09:07:18','5f75cd3ef25340f25'),('6b25b4b8d9d619027','Send Mass Emails',0,'Success','2026-11-15 09:10:00',9,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:08','2026-11-15 09:10:08',133,1,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 09:10:08','8413c58638261267b'),('6b7bd2da0dcca1a0b','Process Webhook Queue',0,'Success','2026-11-15 09:16:00',344,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:08','2026-11-15 09:16:08',296,1,NULL,NULL,NULL,'2026-11-15 09:14:08','2026-11-15 09:16:08','4a6a036f21dffd48a'),('6bd6facb966ae5d84','Process Job Queue q0',0,'Success','2026-11-15 09:21:08',490,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:27:42','2026-11-15 09:27:42',17,1,NULL,NULL,NULL,'2026-11-15 09:21:08','2026-11-15 09:27:42','5750be1f178c76fe9'),('6d53e15b4546aa973','Process Job Queue q0',0,'Success','2026-11-15 09:11:08',282,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:11:08','2026-11-15 09:11:08',164,1,NULL,NULL,NULL,'2026-11-15 09:11:08','2026-11-15 09:11:08','5750be1f178c76fe9'),('6d6d8d5ddde228b0d','Process Job Queue q0',0,'Success','2026-11-15 09:05:28',162,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:05:28','2026-11-15 09:05:28',13,1,NULL,NULL,NULL,'2026-11-15 09:05:28','2026-11-15 09:05:28','5750be1f178c76fe9'),('6d7eb21381f1ae68e','Process Job Queue e0',0,'Success','2026-11-15 09:09:08',240,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:09:08','2026-11-15 09:09:08',110,1,NULL,NULL,NULL,'2026-11-15 09:09:08','2026-11-15 09:09:08','5f75cd3ef25340f25'),('6e33c8ebc11e66e49','Process Job Queue e0',0,'Success','2026-11-15 09:08:48',234,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:48','2026-11-15 09:08:48',101,1,NULL,NULL,NULL,'2026-11-15 09:08:48','2026-11-15 09:08:48','5f75cd3ef25340f25'),('6eed8306d009e66b7','Process Job Queue e0',0,'Success','2026-11-15 09:10:58',280,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:58','2026-11-15 09:10:58',160,1,NULL,NULL,NULL,'2026-11-15 09:10:58','2026-11-15 09:10:58','5f75cd3ef25340f25'),('6f6c8ad8c89e989f2','Submit Popup Reminders',0,'Success','2026-11-15 09:13:28',333,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:13:28','2026-11-15 09:13:28',228,1,NULL,NULL,NULL,'2026-11-15 09:13:28','2026-11-15 09:13:28','bcd1c259a799fac87'),('6fc2c2caa69efbfa5','Process Job Queue e0',0,'Success','2026-11-15 09:09:58',256,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:09:58','2026-11-15 09:09:58',130,1,NULL,NULL,NULL,'2026-11-15 09:09:58','2026-11-15 09:09:58','5f75cd3ef25340f25'),('7015e900ee51287e3','Process Job Queue e0',0,'Success','2026-11-15 09:04:11',160,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:04:11','2026-11-15 09:04:11',196,1,NULL,NULL,NULL,'2026-11-15 09:04:11','2026-11-15 09:04:11','5f75cd3ef25340f25'),('70c7ce6b8384eefd2','Process Job Queue q0',0,'Success','2026-11-15 09:15:08',365,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:15:08','2026-11-15 09:15:08',271,1,NULL,NULL,NULL,'2026-11-15 09:15:08','2026-11-15 09:15:08','5750be1f178c76fe9'),('71074d2dcdb65d6d9','Process Job Queue q0',0,'Success','2026-11-15 09:17:58',422,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:17:58','2026-11-15 09:17:58',344,1,NULL,NULL,NULL,'2026-11-15 09:17:58','2026-11-15 09:17:58','5750be1f178c76fe9'),('71d682e4eaeec96c7','Process Job Queue q0',0,'Success','2026-11-15 08:58:21',37,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:21','2026-11-15 08:58:21',38,1,NULL,NULL,NULL,'2026-11-15 08:58:21','2026-11-15 08:58:21','5750be1f178c76fe9'),('72b4de4fb8e98b5a2','Submit Popup Reminders',0,'Success','2026-11-15 09:08:38',232,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:38','2026-11-15 09:08:38',98,1,NULL,NULL,NULL,'2026-11-15 09:08:38','2026-11-15 09:08:38','bcd1c259a799fac87'),('72e13da86fb9834ce','Process Job Queue e0',0,'Success','2026-11-15 09:03:41',147,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:03:41','2026-11-15 09:03:41',180,1,NULL,NULL,NULL,'2026-11-15 09:03:41','2026-11-15 09:03:41','5f75cd3ef25340f25'),('72f77a642e627554c','Submit Popup Reminders',0,'Success','2026-11-15 09:11:58',300,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:11:58','2026-11-15 09:11:58',186,1,NULL,NULL,NULL,'2026-11-15 09:11:58','2026-11-15 09:11:58','bcd1c259a799fac87'),('734c1560fec6b962c','Process Webhook Queue',0,'Success','2026-11-15 09:14:00',302,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:08','2026-11-15 09:14:08',243,1,NULL,NULL,NULL,'2026-11-15 09:12:08','2026-11-15 09:14:08','4a6a036f21dffd48a'),('7351db7a88a26d4da','Process Job Queue e0',0,'Success','2026-11-15 09:16:38',398,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:38','2026-11-15 09:16:38',312,1,NULL,NULL,NULL,'2026-11-15 09:16:38','2026-11-15 09:16:38','5f75cd3ef25340f25'),('740ae189af5b1ad87','Process Job Queue q0',0,'Success','2026-11-15 08:58:51',46,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:51','2026-11-15 08:58:51',50,1,NULL,NULL,NULL,'2026-11-15 08:58:51','2026-11-15 08:58:51','5750be1f178c76fe9'),('7488a0023cc8b8ce0','Process Job Queue q0',0,'Success','2026-11-15 09:12:18',309,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:18','2026-11-15 09:12:18',197,1,NULL,NULL,NULL,'2026-11-15 09:12:18','2026-11-15 09:12:18','5750be1f178c76fe9'),('757cc552313b4f085','Process Job Queue e0',0,'Success','2026-11-15 08:59:51',66,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:59:51','2026-11-15 08:59:51',76,1,NULL,NULL,NULL,'2026-11-15 08:59:51','2026-11-15 08:59:51','5f75cd3ef25340f25'),('75f4ea5e8319f97de','Process Job Queue q1',0,'Success','2026-11-15 09:15:00',349,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:15:08','2026-11-15 09:15:08',270,1,NULL,NULL,NULL,'2026-11-15 09:14:08','2026-11-15 09:15:08','ea1678c7ea92717de'),('7641316c03cd6e426','Submit Popup Reminders',0,'Success','2026-11-15 09:10:18',269,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:18','2026-11-15 09:10:18',145,1,NULL,NULL,NULL,'2026-11-15 09:10:18','2026-11-15 09:10:18','bcd1c259a799fac87'),('77364534bb6f1187e','Submit Popup Reminders',0,'Success','2026-11-15 09:18:48',444,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:48','2026-11-15 09:18:48',371,1,NULL,NULL,NULL,'2026-11-15 09:18:48','2026-11-15 09:18:48','bcd1c259a799fac87'),('77805013a11ea9de5','Submit Popup Reminders',0,'Success','2026-11-15 09:08:18',226,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:18','2026-11-15 09:08:18',90,1,NULL,NULL,NULL,'2026-11-15 09:08:18','2026-11-15 09:08:18','bcd1c259a799fac87'),('77a8bb5bc266665c4','Process Job Queue q0',0,'Success','2026-11-15 08:59:31',59,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:59:31','2026-11-15 08:59:31',67,1,NULL,NULL,NULL,'2026-11-15 08:59:31','2026-11-15 08:59:31','5750be1f178c76fe9'),('77bd1705edd8f6bc9','Process Job Queue e0',0,'Success','2026-11-15 09:18:48',443,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:48','2026-11-15 09:18:48',370,1,NULL,NULL,NULL,'2026-11-15 09:18:48','2026-11-15 09:18:48','5f75cd3ef25340f25'),('789a5f052d4f0691c','Send Email Reminders',0,'Success','2026-11-15 09:00:00',27,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:01','2026-11-15 09:00:01',81,1,NULL,NULL,NULL,'2026-11-15 08:58:01','2026-11-15 09:00:01','38c14103df40c8494'),('790c7fb0d7831b882','Process Job Queue q0',0,'Success','2026-11-15 09:11:38',292,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:11:38','2026-11-15 09:11:38',176,1,NULL,NULL,NULL,'2026-11-15 09:11:38','2026-11-15 09:11:38','5750be1f178c76fe9'),('79be7ca6a4c7dfd8d','Submit Popup Reminders',0,'Success','2026-11-15 09:06:18',185,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:18','2026-11-15 09:06:18',37,1,NULL,NULL,NULL,'2026-11-15 09:06:18','2026-11-15 09:06:18','bcd1c259a799fac87'),('79d769d866bb9c5ec','Process Job Queue e0',0,'Success','2026-11-15 09:06:08',178,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:08','2026-11-15 09:06:08',32,1,NULL,NULL,NULL,'2026-11-15 09:06:08','2026-11-15 09:06:08','5f75cd3ef25340f25'),('7b13ed9417f359040','Process Job Queue q0',0,'Success','2026-11-15 09:00:11',77,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:11','2026-11-15 09:00:11',89,1,NULL,NULL,NULL,'2026-11-15 09:00:11','2026-11-15 09:00:11','5750be1f178c76fe9'),('7bac727c1826466ce','Process Webhook Queue',0,'Success','2026-11-15 09:00:00',28,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:01','2026-11-15 09:00:01',82,1,NULL,NULL,NULL,'2026-11-15 08:58:01','2026-11-15 09:00:01','4a6a036f21dffd48a'),('7bba6884a0d718d14','Process Job Queue q0',0,'Success','2026-11-15 09:14:38',356,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:38','2026-11-15 09:14:38',258,1,NULL,NULL,NULL,'2026-11-15 09:14:38','2026-11-15 09:14:38','5750be1f178c76fe9'),('7c6c1b01c6e81c3f0','Process Job Queue e0',0,'Success','2026-11-15 08:58:21',38,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:21','2026-11-15 08:58:21',39,1,NULL,NULL,NULL,'2026-11-15 08:58:21','2026-11-15 08:58:21','5f75cd3ef25340f25'),('7cd3eda8628f6f688','Submit Popup Reminders',0,'Success','2026-11-15 09:20:18',477,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:18','2026-11-15 09:20:18',413,1,NULL,NULL,NULL,'2026-11-15 09:20:18','2026-11-15 09:20:18','bcd1c259a799fac87'),('7d9b5c88cd28071cc','Process Job Queue e0',0,'Success','2026-11-15 09:17:48',420,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:17:48','2026-11-15 09:17:48',341,1,NULL,NULL,NULL,'2026-11-15 09:17:48','2026-11-15 09:17:48','5f75cd3ef25340f25'),('7e3aa9a3d50840635','Submit Popup Reminders',0,'Success','2026-11-15 09:10:38',275,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:38','2026-11-15 09:10:38',153,1,NULL,NULL,NULL,'2026-11-15 09:10:38','2026-11-15 09:10:38','bcd1c259a799fac87'),('7e51602df90d4ac13','Submit Popup Reminders',0,'Success','2026-11-15 09:19:08',450,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:19:08','2026-11-15 09:19:08',380,1,NULL,NULL,NULL,'2026-11-15 09:19:08','2026-11-15 09:19:08','bcd1c259a799fac87'),('7ea835314887ae985','Process Webhook Queue',0,'Success','2026-11-15 09:20:00',426,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:08','2026-11-15 09:20:08',404,1,NULL,NULL,NULL,'2026-11-15 09:18:08','2026-11-15 09:20:08','4a6a036f21dffd48a'),('7f6388bd675d9b995','Process Job Queue e0',0,'Success','2026-11-15 09:19:38',459,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:19:38','2026-11-15 09:19:38',391,1,NULL,NULL,NULL,'2026-11-15 09:19:38','2026-11-15 09:19:38','5f75cd3ef25340f25'),('80e0eaaa6c97d77b4','Process Job Queue e0',0,'Success','2026-11-15 09:13:08',325,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:13:08','2026-11-15 09:13:08',219,1,NULL,NULL,NULL,'2026-11-15 09:13:08','2026-11-15 09:13:08','5f75cd3ef25340f25'),('80ef0feba9f3b0286','Submit Popup Reminders',0,'Success','2026-11-15 09:03:51',151,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:03:51','2026-11-15 09:03:51',185,1,NULL,NULL,NULL,'2026-11-15 09:03:51','2026-11-15 09:03:51','bcd1c259a799fac87'),('815f0b540e65adebc','Process Job Queue q0',0,'Success','2026-11-15 09:07:38',208,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:07:38','2026-11-15 09:07:38',68,1,NULL,NULL,NULL,'2026-11-15 09:07:38','2026-11-15 09:07:38','5750be1f178c76fe9'),('81f2df744e11c9117','Send Email Reminders',0,'Success','2026-11-15 09:12:00',258,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:08','2026-11-15 09:12:08',189,1,NULL,NULL,NULL,'2026-11-15 09:10:08','2026-11-15 09:12:08','38c14103df40c8494'),('82187a1fddb37e46e','Submit Popup Reminders',0,'Success','2026-11-15 09:01:41',107,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:41','2026-11-15 09:01:41',128,1,NULL,NULL,NULL,'2026-11-15 09:01:41','2026-11-15 09:01:41','bcd1c259a799fac87'),('82812c07a8fb10342','Submit Popup Reminders',0,'Success','2026-11-15 09:13:48',339,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:13:48','2026-11-15 09:13:48',236,1,NULL,NULL,NULL,'2026-11-15 09:13:48','2026-11-15 09:13:48','bcd1c259a799fac87'),('82ddf46f82b5e479e','Process Webhook Queue',0,'Success','2026-11-15 08:58:00',6,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:01','2026-11-15 08:58:01',27,1,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 08:58:01','4a6a036f21dffd48a'),('82e343b249b9fb06a','Process Job Queue e0',0,'Success','2026-11-15 08:57:41',22,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:57:41','2026-11-15 08:57:41',19,1,NULL,NULL,NULL,'2026-11-15 08:57:41','2026-11-15 08:57:41','5f75cd3ef25340f25'),('8326c5bf9184f1a10','Process Job Queue q0',0,'Success','2026-11-15 09:08:28',227,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:28','2026-11-15 09:08:28',92,1,NULL,NULL,NULL,'2026-11-15 09:08:28','2026-11-15 09:08:28','5750be1f178c76fe9'),('83a447f7a7ee505bc','Submit Popup Reminders',0,'Success','2026-11-15 09:17:28',415,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:17:28','2026-11-15 09:17:28',334,1,NULL,NULL,NULL,'2026-11-15 09:17:28','2026-11-15 09:17:28','bcd1c259a799fac87'),('83f6e4de43eccc7b3','Process Job Queue q0',0,'Success','2026-11-15 09:27:51',506,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:27:51','2026-11-15 09:27:51',19,1,NULL,NULL,NULL,'2026-11-15 09:27:51','2026-11-15 09:27:51','5750be1f178c76fe9'),('868d315c67a3a6af1','Process Job Queue q0',0,'Success','2026-11-15 09:00:21',80,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:21','2026-11-15 09:00:21',93,1,NULL,NULL,NULL,'2026-11-15 09:00:21','2026-11-15 09:00:21','5750be1f178c76fe9'),('86af0bcfd303bbfb9','Process Job Queue q0',0,'Success','2026-11-15 09:07:48',211,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:07:48','2026-11-15 09:07:48',72,1,NULL,NULL,NULL,'2026-11-15 09:07:48','2026-11-15 09:07:48','5750be1f178c76fe9'),('87b3c5d8da230f9e3','Auth Token Control',0,'Success','2026-11-15 09:18:00',308,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:08','2026-11-15 09:18:08',348,1,NULL,NULL,NULL,'2026-11-15 09:12:08','2026-11-15 09:18:08','eeb2498dde7129c23'),('87ca6d165fee97a3d','Process Job Queue e0',0,'Success','2026-11-15 09:11:48',296,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:11:48','2026-11-15 09:11:48',181,1,NULL,NULL,NULL,'2026-11-15 09:11:48','2026-11-15 09:11:48','5f75cd3ef25340f25'),('886943eed0f05ed2f','Process Job Queue e0',0,'Success','2026-11-15 09:05:58',173,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:05:58','2026-11-15 09:05:58',23,1,NULL,NULL,NULL,'2026-11-15 09:05:58','2026-11-15 09:05:58','5f75cd3ef25340f25'),('88fe9473e4113a0f5','Send Scheduled Emails',0,'Pending','2026-11-15 09:30:00',472,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-11-15 09:20:08','2026-11-15 09:20:08','c96bb4400337657cf'),('8900a2c42960d9160','Process Job Queue e0',0,'Success','2026-11-15 09:12:48',319,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:48','2026-11-15 09:12:48',210,1,NULL,NULL,NULL,'2026-11-15 09:12:48','2026-11-15 09:12:48','5f75cd3ef25340f25'),('8a75a5a46c8d4013a','Process Job Queue q0',0,'Success','2026-11-15 09:15:48',378,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:15:48','2026-11-15 09:15:48',287,1,NULL,NULL,NULL,'2026-11-15 09:15:48','2026-11-15 09:15:48','5750be1f178c76fe9'),('8abe3ebdfb2f1eea0','Submit Popup Reminders',0,'Success','2026-11-15 09:05:28',164,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:05:28','2026-11-15 09:05:28',15,1,NULL,NULL,NULL,'2026-11-15 09:05:28','2026-11-15 09:05:28','bcd1c259a799fac87'),('8ae48f730a53f1d47','Send Email Reminders',0,'Success','2026-11-15 09:20:00',425,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:08','2026-11-15 09:20:08',403,1,NULL,NULL,NULL,'2026-11-15 09:18:08','2026-11-15 09:20:08','38c14103df40c8494'),('8b9f9f730d49dbefe','Process Job Queue e0',0,'Success','2026-11-15 09:06:18',184,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:18','2026-11-15 09:06:18',36,1,NULL,NULL,NULL,'2026-11-15 09:06:18','2026-11-15 09:06:18','5f75cd3ef25340f25'),('8dbfa297f133ceb85','Submit Popup Reminders',0,'Success','2026-11-15 09:09:28',248,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:09:28','2026-11-15 09:09:28',119,1,NULL,NULL,NULL,'2026-11-15 09:09:28','2026-11-15 09:09:28','bcd1c259a799fac87'),('8e28e6983afa10413','Process Job Queue e0',0,'Success','2026-11-15 09:11:18',287,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:11:18','2026-11-15 09:11:18',169,1,NULL,NULL,NULL,'2026-11-15 09:11:18','2026-11-15 09:11:18','5f75cd3ef25340f25'),('8ed3d25b4ff0730e0','Send Email Reminders',0,'Pending','2026-11-15 09:30:00',512,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-11-15 09:28:11','2026-11-15 09:28:11','38c14103df40c8494'),('8fe494d04b1585f39','Process Job Queue q0',0,'Success','2026-11-15 09:16:08',386,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:08','2026-11-15 09:16:08',299,1,NULL,NULL,NULL,'2026-11-15 09:16:08','2026-11-15 09:16:08','5750be1f178c76fe9'),('90214feb185220822','Process Job Queue q0',0,'Success','2026-11-15 09:19:58',464,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:19:58','2026-11-15 09:19:58',398,1,NULL,NULL,NULL,'2026-11-15 09:19:58','2026-11-15 09:19:58','5750be1f178c76fe9'),('90532a2a85a5d2821','Submit Popup Reminders',0,'Success','2026-11-15 09:07:38',210,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:07:38','2026-11-15 09:07:38',70,1,NULL,NULL,NULL,'2026-11-15 09:07:38','2026-11-15 09:07:38','bcd1c259a799fac87'),('90a36cb5225817272','Process Job Queue q0',0,'Success','2026-11-15 09:18:58',445,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:58','2026-11-15 09:18:58',373,1,NULL,NULL,NULL,'2026-11-15 09:18:58','2026-11-15 09:18:58','5750be1f178c76fe9'),('90c76fb3d7045d208','Submit Popup Reminders',0,'Success','2026-11-15 09:19:48',463,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:19:48','2026-11-15 09:19:48',396,1,NULL,NULL,NULL,'2026-11-15 09:19:48','2026-11-15 09:19:48','bcd1c259a799fac87'),('9129f0532c85323c2','Send Email Notifications',0,'Success','2026-11-15 09:16:00',348,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:08','2026-11-15 09:16:08',297,1,NULL,NULL,NULL,'2026-11-15 09:14:08','2026-11-15 09:16:08','e9d6c9980d694fb42'),('9180aff7301eb42a0','Process Job Queue q0',0,'Success','2026-11-15 09:04:11',159,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:04:11','2026-11-15 09:04:11',195,1,NULL,NULL,NULL,'2026-11-15 09:04:11','2026-11-15 09:04:11','5750be1f178c76fe9'),('918f5162409989e0f','Submit Popup Reminders',0,'Success','2026-11-15 09:06:58',197,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:58','2026-11-15 09:06:58',53,1,NULL,NULL,NULL,'2026-11-15 09:06:58','2026-11-15 09:06:58','bcd1c259a799fac87'),('91c6db68b2a0a2681','Process Job Queue q1',0,'Success','2026-11-15 09:00:00',52,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:01','2026-11-15 09:00:01',84,1,NULL,NULL,NULL,'2026-11-15 08:59:01','2026-11-15 09:00:01','ea1678c7ea92717de'),('93d3822ee6d4b7bde','Process Job Queue q0',0,'Success','2026-11-15 09:12:48',318,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:48','2026-11-15 09:12:48',209,1,NULL,NULL,NULL,'2026-11-15 09:12:48','2026-11-15 09:12:48','5750be1f178c76fe9'),('93f4da594884ec8ca','Process Job Queue q0',0,'Success','2026-11-15 08:57:21',7,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 08:57:21',12,1,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 08:57:21','5750be1f178c76fe9'),('940441c4c97984685','Submit Popup Reminders',0,'Success','2026-11-15 09:02:31',126,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:31','2026-11-15 09:02:31',152,1,NULL,NULL,NULL,'2026-11-15 09:02:31','2026-11-15 09:02:31','bcd1c259a799fac87'),('95597491be283314d','Submit Popup Reminders',0,'Success','2026-11-15 09:09:58',257,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:09:58','2026-11-15 09:09:58',131,1,NULL,NULL,NULL,'2026-11-15 09:09:58','2026-11-15 09:09:58','bcd1c259a799fac87'),('959511779eb2092d6','Submit Popup Reminders',0,'Success','2026-11-15 09:02:01',115,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:01','2026-11-15 09:02:01',140,1,NULL,NULL,NULL,'2026-11-15 09:02:01','2026-11-15 09:02:01','bcd1c259a799fac87'),('95f4594e419c232d0','Process Job Queue q1',0,'Success','2026-11-15 09:09:00',223,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:09:08','2026-11-15 09:09:08',108,1,NULL,NULL,NULL,'2026-11-15 09:08:08','2026-11-15 09:09:08','ea1678c7ea92717de'),('96096d098bda49d82','Submit Popup Reminders',0,'Success','2026-11-15 09:03:01',135,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:03:01','2026-11-15 09:03:01',165,1,NULL,NULL,NULL,'2026-11-15 09:03:01','2026-11-15 09:03:01','bcd1c259a799fac87'),('996cf0f42ae025c4a','Process Job Queue q0',0,'Success','2026-11-15 09:03:21',140,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:03:21','2026-11-15 09:03:21',171,1,NULL,NULL,NULL,'2026-11-15 09:03:21','2026-11-15 09:03:21','5750be1f178c76fe9'),('997e592b84aec53ce','Process Job Queue e0',0,'Success','2026-11-15 09:07:58',215,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:07:58','2026-11-15 09:07:58',77,1,NULL,NULL,NULL,'2026-11-15 09:07:58','2026-11-15 09:07:58','5f75cd3ef25340f25'),('99e1dea0c2d74df88','Process Job Queue q0',0,'Success','2026-11-15 09:01:21',99,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:21','2026-11-15 09:01:21',118,1,NULL,NULL,NULL,'2026-11-15 09:01:21','2026-11-15 09:01:21','5750be1f178c76fe9'),('9a1e8b48800a9d2b5','Submit Popup Reminders',0,'Success','2026-11-15 09:09:48',254,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:09:48','2026-11-15 09:09:48',127,1,NULL,NULL,NULL,'2026-11-15 09:09:48','2026-11-15 09:09:48','bcd1c259a799fac87'),('9a350763e16f9e046','Process Job Queue q0',0,'Success','2026-11-15 09:13:18',328,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:13:18','2026-11-15 09:13:18',222,1,NULL,NULL,NULL,'2026-11-15 09:13:18','2026-11-15 09:13:18','5750be1f178c76fe9'),('9a455a0b7e196f4c5','Process Job Queue q0',0,'Success','2026-11-15 09:06:48',192,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:48','2026-11-15 09:06:48',47,1,NULL,NULL,NULL,'2026-11-15 09:06:48','2026-11-15 09:06:48','5750be1f178c76fe9'),('9c4e35923c36e8fbd','Process Job Queue q0',0,'Success','2026-11-15 09:14:28',353,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:28','2026-11-15 09:14:28',254,1,NULL,NULL,NULL,'2026-11-15 09:14:28','2026-11-15 09:14:28','5750be1f178c76fe9'),('9c81e2f0eb8799d13','Submit Popup Reminders',0,'Success','2026-11-15 09:08:58',238,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:58','2026-11-15 09:08:58',106,1,NULL,NULL,NULL,'2026-11-15 09:08:58','2026-11-15 09:08:58','bcd1c259a799fac87'),('9d07b327e7153a9fb','Submit Popup Reminders',0,'Success','2026-11-15 09:06:38',191,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:38','2026-11-15 09:06:38',45,1,NULL,NULL,NULL,'2026-11-15 09:06:38','2026-11-15 09:06:38','bcd1c259a799fac87'),('9d76530324e323560','Process Job Queue q0',0,'Success','2026-11-15 09:00:01',70,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:01','2026-11-15 09:00:01',85,1,NULL,NULL,NULL,'2026-11-15 09:00:01','2026-11-15 09:00:01','5750be1f178c76fe9'),('9d9173c518dd9c763','Submit Popup Reminders',0,'Success','2026-11-15 09:00:11',79,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:11','2026-11-15 09:00:11',91,1,NULL,NULL,NULL,'2026-11-15 09:00:11','2026-11-15 09:00:11','bcd1c259a799fac87'),('9da7b8fec1f1617c8','Submit Popup Reminders',0,'Success','2026-11-15 09:10:28',272,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:28','2026-11-15 09:10:28',149,1,NULL,NULL,NULL,'2026-11-15 09:10:28','2026-11-15 09:10:28','bcd1c259a799fac87'),('9dd29c21dedd62c78','Submit Popup Reminders',0,'Success','2026-11-15 09:16:28',396,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:28','2026-11-15 09:16:28',309,1,NULL,NULL,NULL,'2026-11-15 09:16:28','2026-11-15 09:16:28','bcd1c259a799fac87'),('9e34deade86468498','Process Job Queue e0',0,'Success','2026-11-15 09:01:01',93,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:01','2026-11-15 09:01:01',111,1,NULL,NULL,NULL,'2026-11-15 09:01:01','2026-11-15 09:01:01','5f75cd3ef25340f25'),('9ecb31d1f784a7fbe','Submit Popup Reminders',0,'Success','2026-11-15 09:07:28',207,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:07:28','2026-11-15 09:07:28',66,1,NULL,NULL,NULL,'2026-11-15 09:07:28','2026-11-15 09:07:28','bcd1c259a799fac87'),('9fdd6a6bb0c4730e7','Process Job Queue q0',0,'Success','2026-11-15 09:16:18',391,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:18','2026-11-15 09:16:18',303,1,NULL,NULL,NULL,'2026-11-15 09:16:18','2026-11-15 09:16:18','5750be1f178c76fe9'),('9fefd80f82883fe1f','Process Job Queue q0',0,'Success','2026-11-15 09:06:18',183,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:18','2026-11-15 09:06:18',35,1,NULL,NULL,NULL,'2026-11-15 09:06:18','2026-11-15 09:06:18','5750be1f178c76fe9'),('a00129c775ac538c6','Process Job Queue q1',0,'Success','2026-11-15 09:05:00',158,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:05:28','2026-11-15 09:05:28',12,1,NULL,NULL,NULL,'2026-11-15 09:04:01','2026-11-15 09:05:28','ea1678c7ea92717de'),('a02a9136c78abaf43','Process Job Queue q0',0,'Success','2026-11-15 09:00:31',83,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:31','2026-11-15 09:00:31',97,1,NULL,NULL,NULL,'2026-11-15 09:00:31','2026-11-15 09:00:31','5750be1f178c76fe9'),('a039badacee596121','Process Job Queue q0',0,'Success','2026-11-15 09:17:28',413,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:17:28','2026-11-15 09:17:28',332,1,NULL,NULL,NULL,'2026-11-15 09:17:28','2026-11-15 09:17:28','5750be1f178c76fe9'),('a08975bb73f442dbc','Process Job Queue q0',0,'Success','2026-11-15 09:15:18',369,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:15:18','2026-11-15 09:15:18',275,1,NULL,NULL,NULL,'2026-11-15 09:15:18','2026-11-15 09:15:18','5750be1f178c76fe9'),('a0bd034e34c90835b','Process Job Queue q0',0,'Success','2026-11-15 09:09:18',243,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:09:18','2026-11-15 09:09:18',113,1,NULL,NULL,NULL,'2026-11-15 09:09:18','2026-11-15 09:09:18','5750be1f178c76fe9'),('a0d2c44da39e26287','Process Job Queue q0',0,'Success','2026-11-15 09:01:11',96,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:11','2026-11-15 09:01:11',114,1,NULL,NULL,NULL,'2026-11-15 09:01:11','2026-11-15 09:01:11','5750be1f178c76fe9'),('a0fcf5556d2315c09','Process Job Queue q0',0,'Success','2026-11-15 08:59:51',65,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:59:51','2026-11-15 08:59:51',75,1,NULL,NULL,NULL,'2026-11-15 08:59:51','2026-11-15 08:59:51','5750be1f178c76fe9'),('a10fe6abab15b6b79','Submit Popup Reminders',0,'Success','2026-11-15 09:12:48',320,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:48','2026-11-15 09:12:48',211,1,NULL,NULL,NULL,'2026-11-15 09:12:48','2026-11-15 09:12:48','bcd1c259a799fac87'),('a136b035cd27be566','Submit Popup Reminders',0,'Success','2026-11-15 09:15:28',374,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:15:28','2026-11-15 09:15:28',281,1,NULL,NULL,NULL,'2026-11-15 09:15:28','2026-11-15 09:15:28','bcd1c259a799fac87'),('a15be6758b1a69885','Process Job Queue e0',0,'Success','2026-11-15 09:10:18',268,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:18','2026-11-15 09:10:18',144,1,NULL,NULL,NULL,'2026-11-15 09:10:18','2026-11-15 09:10:18','5f75cd3ef25340f25'),('a1d56fffd3aed909e','Submit Popup Reminders',0,'Success','2026-11-15 09:18:38',441,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:38','2026-11-15 09:18:38',367,1,NULL,NULL,NULL,'2026-11-15 09:18:38','2026-11-15 09:18:38','bcd1c259a799fac87'),('a1f55629392e8fa79','Process Job Queue e0',0,'Success','2026-11-15 09:02:51',131,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:51','2026-11-15 09:02:51',159,1,NULL,NULL,NULL,'2026-11-15 09:02:51','2026-11-15 09:02:51','5f75cd3ef25340f25'),('a219aa10e97f2b7cc','Send Email Notifications',0,'Success','2026-11-15 09:20:00',430,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:08','2026-11-15 09:20:08',405,1,NULL,NULL,NULL,'2026-11-15 09:18:08','2026-11-15 09:20:08','e9d6c9980d694fb42'),('a2bf737d5ba47f87f','Submit Popup Reminders',0,'Success','2026-11-15 09:11:38',294,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:11:38','2026-11-15 09:11:38',178,1,NULL,NULL,NULL,'2026-11-15 09:11:38','2026-11-15 09:11:38','bcd1c259a799fac87'),('a2eb4205963a6d223','Process Job Queue e0',0,'Success','2026-11-15 09:08:08',220,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:08','2026-11-15 09:08:08',85,1,NULL,NULL,NULL,'2026-11-15 09:08:08','2026-11-15 09:08:08','5f75cd3ef25340f25'),('a47d52c12b8ec7dc6','Process Webhook Queue',0,'Success','2026-11-15 09:06:00',153,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:08','2026-11-15 09:06:08',28,1,NULL,NULL,NULL,'2026-11-15 09:04:01','2026-11-15 09:06:08','4a6a036f21dffd48a'),('a50ddeaf7c15e3185','Process Job Queue q0',0,'Success','2026-11-15 09:06:28',186,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:28','2026-11-15 09:06:28',39,1,NULL,NULL,NULL,'2026-11-15 09:06:28','2026-11-15 09:06:28','5750be1f178c76fe9'),('a69fa5af6d9b40ca5','Submit Popup Reminders',0,'Success','2026-11-15 09:12:58',323,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:58','2026-11-15 09:12:58',215,1,NULL,NULL,NULL,'2026-11-15 09:12:58','2026-11-15 09:12:58','bcd1c259a799fac87'),('a6d5015a5a51d785a','Process Job Queue q0',0,'Success','2026-11-15 09:20:28',478,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:28','2026-11-15 09:20:28',415,1,NULL,NULL,NULL,'2026-11-15 09:20:28','2026-11-15 09:20:28','5750be1f178c76fe9'),('a6fc5a0bb0b6a8b0f','Process Job Queue q0',0,'Success','2026-11-15 08:57:41',21,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:57:41','2026-11-15 08:57:41',18,1,NULL,NULL,NULL,'2026-11-15 08:57:41','2026-11-15 08:57:41','5750be1f178c76fe9'),('a84d683569761187c','Submit Popup Reminders',0,'Success','2026-11-15 09:08:08',221,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:08','2026-11-15 09:08:08',86,1,NULL,NULL,NULL,'2026-11-15 09:08:08','2026-11-15 09:08:08','bcd1c259a799fac87'),('a8bf47ff71a43e4de','Process Job Queue e0',0,'Success','2026-11-15 09:19:58',465,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:19:58','2026-11-15 09:19:58',399,1,NULL,NULL,NULL,'2026-11-15 09:19:58','2026-11-15 09:19:58','5f75cd3ef25340f25'),('a8dc9053f760e04bd','Send Email Notifications',0,'Success','2026-11-15 09:10:00',222,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:08','2026-11-15 09:10:08',137,1,NULL,NULL,NULL,'2026-11-15 09:08:08','2026-11-15 09:10:08','e9d6c9980d694fb42'),('a9133bd2632819bf8','Process Job Queue e0',0,'Success','2026-11-15 09:20:08',470,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:08','2026-11-15 09:20:08',408,1,NULL,NULL,NULL,'2026-11-15 09:20:08','2026-11-15 09:20:08','5f75cd3ef25340f25'),('a9297ca856d5ef24a','Process Job Queue q0',0,'Success','2026-11-15 09:18:38',439,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:38','2026-11-15 09:18:38',365,1,NULL,NULL,NULL,'2026-11-15 09:18:38','2026-11-15 09:18:38','5750be1f178c76fe9'),('a93a5bb0d5c4e446d','Process Job Queue q0',0,'Success','2026-11-15 08:57:51',24,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:57:51','2026-11-15 08:57:51',22,1,NULL,NULL,NULL,'2026-11-15 08:57:51','2026-11-15 08:57:51','5750be1f178c76fe9'),('a9d00326e96079cb8','Process Job Queue q0',0,'Success','2026-11-15 08:59:01',49,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:59:01','2026-11-15 08:59:01',55,1,NULL,NULL,NULL,'2026-11-15 08:59:01','2026-11-15 08:59:01','5750be1f178c76fe9'),('aa5cfc76599de899a','Process Job Queue q0',0,'Success','2026-11-15 09:02:01',113,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:01','2026-11-15 09:02:01',138,1,NULL,NULL,NULL,'2026-11-15 09:02:01','2026-11-15 09:02:01','5750be1f178c76fe9'),('ac1e45fb77ca8bcc3','Process Job Queue e0',0,'Success','2026-11-15 09:07:28',206,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:07:28','2026-11-15 09:07:28',65,1,NULL,NULL,NULL,'2026-11-15 09:07:28','2026-11-15 09:07:28','5f75cd3ef25340f25'),('acb05bcceec38d9fe','Process Job Queue q0',0,'Success','2026-11-15 09:16:48',400,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:48','2026-11-15 09:16:48',315,1,NULL,NULL,NULL,'2026-11-15 09:16:48','2026-11-15 09:16:48','5750be1f178c76fe9'),('ace399e9a5d091774','Process Job Queue e0',0,'Success','2026-11-15 09:20:48',485,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:48','2026-11-15 09:20:48',424,1,NULL,NULL,NULL,'2026-11-15 09:20:48','2026-11-15 09:20:48','5f75cd3ef25340f25'),('ad3ee7e8eb5845a82','Process Job Queue e0',0,'Success','2026-11-15 09:13:28',332,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:13:28','2026-11-15 09:13:28',227,1,NULL,NULL,NULL,'2026-11-15 09:13:28','2026-11-15 09:13:28','5f75cd3ef25340f25'),('adc539a502d9dc131','Process Job Queue q0',0,'Success','2026-11-15 09:00:41',86,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:41','2026-11-15 09:00:41',101,1,NULL,NULL,NULL,'2026-11-15 09:00:41','2026-11-15 09:00:41','5750be1f178c76fe9'),('af19754ab3a720a52','Process Job Queue e0',0,'Success','2026-11-15 09:02:41',128,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:41','2026-11-15 09:02:41',155,1,NULL,NULL,NULL,'2026-11-15 09:02:41','2026-11-15 09:02:41','5f75cd3ef25340f25'),('af43e644d53dfaaa2','Process Job Queue e0',0,'Success','2026-11-15 09:11:28',290,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:11:28','2026-11-15 09:11:28',173,1,NULL,NULL,NULL,'2026-11-15 09:11:28','2026-11-15 09:11:28','5f75cd3ef25340f25'),('b062aeabf0b7c68f4','Send Email Reminders',0,'Success','2026-11-15 09:18:00',384,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:08','2026-11-15 09:18:08',349,1,NULL,NULL,NULL,'2026-11-15 09:16:08','2026-11-15 09:18:08','38c14103df40c8494'),('b0e27460afcaa0298','Process Job Queue q0',0,'Success','2026-11-15 09:06:08',177,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:08','2026-11-15 09:06:08',31,1,NULL,NULL,NULL,'2026-11-15 09:06:08','2026-11-15 09:06:08','5750be1f178c76fe9'),('b0f53e1caf236a4d6','Process Job Queue q0',0,'Success','2026-11-15 09:14:48',359,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:48','2026-11-15 09:14:48',262,1,NULL,NULL,NULL,'2026-11-15 09:14:48','2026-11-15 09:14:48','5750be1f178c76fe9'),('b15db446cebb27d37','Process Job Queue e0',0,'Success','2026-11-15 09:00:21',81,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:21','2026-11-15 09:00:21',94,1,NULL,NULL,NULL,'2026-11-15 09:00:21','2026-11-15 09:00:21','5f75cd3ef25340f25'),('b2ab795767d7efe3b','Submit Popup Reminders',0,'Success','2026-11-15 09:05:58',174,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:05:58','2026-11-15 09:05:58',24,1,NULL,NULL,NULL,'2026-11-15 09:05:58','2026-11-15 09:05:58','bcd1c259a799fac87'),('b3107974bc20a477c','Process Job Queue q1',0,'Success','2026-11-15 09:01:00',75,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:01','2026-11-15 09:01:01',109,1,NULL,NULL,NULL,'2026-11-15 09:00:01','2026-11-15 09:01:01','ea1678c7ea92717de'),('b31dc0dbbaafa2efb','Process Job Queue q0',0,'Success','2026-11-15 09:02:41',127,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:41','2026-11-15 09:02:41',154,1,NULL,NULL,NULL,'2026-11-15 09:02:41','2026-11-15 09:02:41','5750be1f178c76fe9'),('b38228a2c8fea2db0','Process Job Queue q0',0,'Success','2026-11-15 09:12:28',312,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:28','2026-11-15 09:12:28',201,1,NULL,NULL,NULL,'2026-11-15 09:12:28','2026-11-15 09:12:28','5750be1f178c76fe9'),('b4155e75203562992','Process Job Queue q0',0,'Success','2026-11-15 09:20:48',484,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:48','2026-11-15 09:20:48',423,1,NULL,NULL,NULL,'2026-11-15 09:20:48','2026-11-15 09:20:48','5750be1f178c76fe9'),('b487a89a0ef8be1ef','Process Job Queue q0',0,'Success','2026-11-15 09:03:11',137,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:03:11','2026-11-15 09:03:11',167,1,NULL,NULL,NULL,'2026-11-15 09:03:11','2026-11-15 09:03:11','5750be1f178c76fe9'),('b4baa6ccba1ddafe8','Submit Popup Reminders',0,'Success','2026-11-15 08:57:41',23,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:57:41','2026-11-15 08:57:41',20,1,NULL,NULL,NULL,'2026-11-15 08:57:41','2026-11-15 08:57:41','bcd1c259a799fac87'),('b4e958e7a6bcc264d','Process Job Queue q0',0,'Success','2026-11-15 09:18:48',442,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:48','2026-11-15 09:18:48',369,1,NULL,NULL,NULL,'2026-11-15 09:18:48','2026-11-15 09:18:48','5750be1f178c76fe9'),('b4f86d6d66d3b0aff','Submit Popup Reminders',0,'Success','2026-11-15 09:20:08',471,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:08','2026-11-15 09:20:08',409,1,NULL,NULL,NULL,'2026-11-15 09:20:08','2026-11-15 09:20:08','bcd1c259a799fac87'),('b52205b9d222762af','Submit Popup Reminders',0,'Success','2026-11-15 09:20:48',486,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:48','2026-11-15 09:20:48',425,1,NULL,NULL,NULL,'2026-11-15 09:20:48','2026-11-15 09:20:48','bcd1c259a799fac87'),('b59efb9973fb5f307','Process Job Queue q1',0,'Success','2026-11-15 09:02:00',95,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:01','2026-11-15 09:02:01',137,1,NULL,NULL,NULL,'2026-11-15 09:01:01','2026-11-15 09:02:01','ea1678c7ea92717de'),('b5e18fcfac60104e8','Submit Popup Reminders',0,'Success','2026-11-15 08:59:31',61,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:59:31','2026-11-15 08:59:31',69,1,NULL,NULL,NULL,'2026-11-15 08:59:31','2026-11-15 08:59:31','bcd1c259a799fac87'),('b76bff5f3745cade4','Process Job Queue q1',0,'Pending','2026-11-15 09:29:00',518,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-11-15 09:28:11','2026-11-15 09:28:11','ea1678c7ea92717de'),('b77f98ef3d182b191','Process Job Queue e0',0,'Success','2026-11-15 09:16:18',392,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:18','2026-11-15 09:16:18',304,1,NULL,NULL,NULL,'2026-11-15 09:16:18','2026-11-15 09:16:18','5f75cd3ef25340f25'),('b883b941541998841','Submit Popup Reminders',0,'Success','2026-11-15 09:15:18',371,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:15:18','2026-11-15 09:15:18',277,1,NULL,NULL,NULL,'2026-11-15 09:15:18','2026-11-15 09:15:18','bcd1c259a799fac87'),('b99f5994a94c11679','Process Job Queue q0',0,'Success','2026-11-15 09:19:38',458,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:19:38','2026-11-15 09:19:38',390,1,NULL,NULL,NULL,'2026-11-15 09:19:38','2026-11-15 09:19:38','5750be1f178c76fe9'),('ba200b694fb7f73d2','Process Job Queue e0',0,'Success','2026-11-15 09:06:28',187,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:28','2026-11-15 09:06:28',40,1,NULL,NULL,NULL,'2026-11-15 09:06:28','2026-11-15 09:06:28','5f75cd3ef25340f25'),('ba59b17e0d28be6d9','Process Job Queue q0',0,'Success','2026-11-15 09:02:51',130,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:51','2026-11-15 09:02:51',158,1,NULL,NULL,NULL,'2026-11-15 09:02:51','2026-11-15 09:02:51','5750be1f178c76fe9'),('bb1e3a68a5e57404e','Process Webhook Queue',0,'Pending','2026-11-15 09:30:00',513,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-11-15 09:28:11','2026-11-15 09:28:11','4a6a036f21dffd48a'),('bb388b880613a1009','Submit Popup Reminders',0,'Success','2026-11-15 09:19:38',460,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:19:38','2026-11-15 09:19:38',392,1,NULL,NULL,NULL,'2026-11-15 09:19:38','2026-11-15 09:19:38','bcd1c259a799fac87'),('bba350ac0141732bb','Process Job Queue q0',0,'Success','2026-11-15 09:15:28',372,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:15:28','2026-11-15 09:15:28',279,1,NULL,NULL,NULL,'2026-11-15 09:15:28','2026-11-15 09:15:28','5750be1f178c76fe9'),('bbc4bc927ef705c0d','Send Email Notifications',0,'Success','2026-11-15 09:08:00',180,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:08','2026-11-15 09:08:08',82,1,NULL,NULL,NULL,'2026-11-15 09:06:08','2026-11-15 09:08:08','e9d6c9980d694fb42'),('bd287fe9b9d36b19a','Process Job Queue e0',0,'Success','2026-11-15 09:14:08',346,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:08','2026-11-15 09:14:08',247,1,NULL,NULL,NULL,'2026-11-15 09:14:08','2026-11-15 09:14:08','5f75cd3ef25340f25'),('bdcdf513b05e0c946','Submit Popup Reminders',0,'Success','2026-11-15 09:14:08',347,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:08','2026-11-15 09:14:08',248,1,NULL,NULL,NULL,'2026-11-15 09:14:08','2026-11-15 09:14:08','bcd1c259a799fac87'),('bdd1fe19873c4185c','Process Webhook Queue',0,'Success','2026-11-15 09:18:00',385,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:08','2026-11-15 09:18:08',350,1,NULL,NULL,NULL,'2026-11-15 09:16:08','2026-11-15 09:18:08','4a6a036f21dffd48a'),('bf2848570c23c6f99','Process Job Queue e0',0,'Success','2026-11-15 09:14:18',351,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:18','2026-11-15 09:14:18',251,1,NULL,NULL,NULL,'2026-11-15 09:14:18','2026-11-15 09:14:18','5f75cd3ef25340f25'),('bf4f02fd328684b9e','Submit Popup Reminders',0,'Success','2026-11-15 09:14:58',364,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:58','2026-11-15 09:14:58',268,1,NULL,NULL,NULL,'2026-11-15 09:14:58','2026-11-15 09:14:58','bcd1c259a799fac87'),('bfa51d4569c03d943','Submit Popup Reminders',0,'Success','2026-11-15 09:09:18',245,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:09:18','2026-11-15 09:09:18',115,1,NULL,NULL,NULL,'2026-11-15 09:09:18','2026-11-15 09:09:18','bcd1c259a799fac87'),('bfb1074549ea644ae','OAuth Server Control',0,'Pending','2026-11-15 19:03:00',3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 08:57:21','31b38e5ba1a9db741'),('c008009aed1bfa5ff','Process Job Queue q0',0,'Success','2026-11-15 09:11:18',286,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:11:18','2026-11-15 09:11:18',168,1,NULL,NULL,NULL,'2026-11-15 09:11:18','2026-11-15 09:11:18','5750be1f178c76fe9'),('c085f06d7882172c7','Process Job Queue e0',0,'Success','2026-11-15 09:14:28',354,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:28','2026-11-15 09:14:28',255,1,NULL,NULL,NULL,'2026-11-15 09:14:28','2026-11-15 09:14:28','5f75cd3ef25340f25'),('c13cab8f8e1599f6d','Process Job Queue e0',0,'Success','2026-11-15 09:15:28',373,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:15:28','2026-11-15 09:15:28',280,1,NULL,NULL,NULL,'2026-11-15 09:15:28','2026-11-15 09:15:28','5f75cd3ef25340f25'),('c1f96899bdebd4f6d','Process Job Queue e0',0,'Success','2026-11-15 09:18:18',434,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:18','2026-11-15 09:18:18',358,1,NULL,NULL,NULL,'2026-11-15 09:18:18','2026-11-15 09:18:18','5f75cd3ef25340f25'),('c2364d648ebf27f2d','Submit Popup Reminders',0,'Success','2026-11-15 09:01:31',104,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:31','2026-11-15 09:01:31',124,1,NULL,NULL,NULL,'2026-11-15 09:01:31','2026-11-15 09:01:31','bcd1c259a799fac87'),('c34d27244ea35df2a','Check for New Version',0,'Pending','2026-11-16 00:15:00',12,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 08:57:21','aae0063f8388741f2'),('c425800102ace26b5','Process Job Queue q1',0,'Success','2026-11-15 08:58:00',16,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:01','2026-11-15 08:58:01',29,1,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 08:58:01','ea1678c7ea92717de'),('c5d3328f13637e862','Process Job Queue e0',0,'Success','2026-11-15 09:12:38',316,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:38','2026-11-15 09:12:38',206,1,NULL,NULL,NULL,'2026-11-15 09:12:38','2026-11-15 09:12:38','5f75cd3ef25340f25'),('c5e2134ea37227bff','Process Job Queue e0',0,'Success','2026-11-15 09:09:48',253,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:09:48','2026-11-15 09:09:48',126,1,NULL,NULL,NULL,'2026-11-15 09:09:48','2026-11-15 09:09:48','5f75cd3ef25340f25'),('c6631798a6f6c3253','Process Webhook Queue',0,'Success','2026-11-15 09:08:00',176,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:08','2026-11-15 09:08:08',81,1,NULL,NULL,NULL,'2026-11-15 09:06:08','2026-11-15 09:08:08','4a6a036f21dffd48a'),('c7215e85ccefa2fa8','Process Job Queue q1',0,'Success','2026-11-15 09:18:00',409,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:08','2026-11-15 09:18:08',352,1,NULL,NULL,NULL,'2026-11-15 09:17:08','2026-11-15 09:18:08','ea1678c7ea92717de'),('c72bcb126f2d6d443','Submit Popup Reminders',0,'Success','2026-11-15 09:09:08',241,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:09:08','2026-11-15 09:09:08',111,1,NULL,NULL,NULL,'2026-11-15 09:09:08','2026-11-15 09:09:08','bcd1c259a799fac87'),('c8237922aeba86824','Process Job Queue e0',0,'Success','2026-11-15 09:05:48',170,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:05:48','2026-11-15 09:05:48',19,1,NULL,NULL,NULL,'2026-11-15 09:05:48','2026-11-15 09:05:48','5f75cd3ef25340f25'),('c83ef8196a66ead15','Process Job Queue e0',0,'Success','2026-11-15 08:59:31',60,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:59:31','2026-11-15 08:59:31',68,1,NULL,NULL,NULL,'2026-11-15 08:59:31','2026-11-15 08:59:31','5f75cd3ef25340f25'),('c86da1f75c38a7ea9','Process Job Queue q1',0,'Success','2026-11-15 09:17:00',390,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:17:08','2026-11-15 09:17:08',323,1,NULL,NULL,NULL,'2026-11-15 09:16:08','2026-11-15 09:17:08','ea1678c7ea92717de'),('c8a414413733d9e6a','Submit Popup Reminders',0,'Success','2026-11-15 09:10:58',281,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:58','2026-11-15 09:10:58',161,1,NULL,NULL,NULL,'2026-11-15 09:10:58','2026-11-15 09:10:58','bcd1c259a799fac87'),('c9026dbeb5e8cbd78','Process Job Queue q0',0,'Success','2026-11-15 09:12:58',321,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:58','2026-11-15 09:12:58',213,1,NULL,NULL,NULL,'2026-11-15 09:12:58','2026-11-15 09:12:58','5750be1f178c76fe9'),('cbce902527a79c9d2','Process Job Queue q0',0,'Success','2026-11-15 08:59:11',53,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:59:11','2026-11-15 08:59:11',59,1,NULL,NULL,NULL,'2026-11-15 08:59:11','2026-11-15 08:59:11','5750be1f178c76fe9'),('cc11bc1f12fc7e54c','Send Email Reminders',0,'Success','2026-11-15 09:22:00',467,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:27:41','2026-11-15 09:27:42',13,1,NULL,NULL,NULL,'2026-11-15 09:20:08','2026-11-15 09:27:42','38c14103df40c8494'),('cc4109aabb401cce5','Process Job Queue e0',0,'Success','2026-11-15 08:58:31',41,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:31','2026-11-15 08:58:31',43,1,NULL,NULL,NULL,'2026-11-15 08:58:31','2026-11-15 08:58:31','5f75cd3ef25340f25'),('ccb0c2716a04644ff','Process Job Queue e0',0,'Success','2026-11-15 08:59:21',57,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:59:21','2026-11-15 08:59:21',64,1,NULL,NULL,NULL,'2026-11-15 08:59:21','2026-11-15 08:59:21','5f75cd3ef25340f25'),('cceb3f43ac34d714e','Process Job Queue e0',0,'Success','2026-11-15 08:59:01',50,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:59:01','2026-11-15 08:59:01',56,1,NULL,NULL,NULL,'2026-11-15 08:59:01','2026-11-15 08:59:01','5f75cd3ef25340f25'),('cd01da99e0f7504bb','Process Job Queue q0',0,'Success','2026-11-15 08:58:31',40,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:31','2026-11-15 08:58:31',42,1,NULL,NULL,NULL,'2026-11-15 08:58:31','2026-11-15 08:58:31','5750be1f178c76fe9'),('cdfa09bd3cd233d00','Process Webhook Queue',0,'Success','2026-11-15 09:10:00',218,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:08','2026-11-15 09:10:08',136,1,NULL,NULL,NULL,'2026-11-15 09:08:08','2026-11-15 09:10:08','4a6a036f21dffd48a'),('ce37175e8aa15deb3','Submit Popup Reminders',0,'Success','2026-11-15 09:13:08',326,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:13:08','2026-11-15 09:13:08',220,1,NULL,NULL,NULL,'2026-11-15 09:13:08','2026-11-15 09:13:08','bcd1c259a799fac87'),('cf0148cbb999525d1','Submit Popup Reminders',0,'Success','2026-11-15 09:16:38',399,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:38','2026-11-15 09:16:38',313,1,NULL,NULL,NULL,'2026-11-15 09:16:38','2026-11-15 09:16:38','bcd1c259a799fac87'),('cf41c74baf2697768','Submit Popup Reminders',0,'Success','2026-11-15 09:02:51',132,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:51','2026-11-15 09:02:51',160,1,NULL,NULL,NULL,'2026-11-15 09:02:51','2026-11-15 09:02:51','bcd1c259a799fac87'),('cfe259b90d48a704c','Process Job Queue e0',0,'Success','2026-11-15 09:17:38',417,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:17:38','2026-11-15 09:17:38',337,1,NULL,NULL,NULL,'2026-11-15 09:17:38','2026-11-15 09:17:38','5f75cd3ef25340f25'),('d0762949acba1fa40','Process Job Queue e0',0,'Success','2026-11-15 09:12:58',322,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:58','2026-11-15 09:12:58',214,1,NULL,NULL,NULL,'2026-11-15 09:12:58','2026-11-15 09:12:58','5f75cd3ef25340f25'),('d07ce05915c9f3583','Process Job Queue e0',0,'Success','2026-11-15 09:14:48',360,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:48','2026-11-15 09:14:48',263,1,NULL,NULL,NULL,'2026-11-15 09:14:48','2026-11-15 09:14:48','5f75cd3ef25340f25'),('d151f91cc640473a4','Submit Popup Reminders',0,'Success','2026-11-15 09:11:18',288,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:11:18','2026-11-15 09:11:18',170,1,NULL,NULL,NULL,'2026-11-15 09:11:18','2026-11-15 09:11:18','bcd1c259a799fac87'),('d1b53394031a898a8','Process Job Queue e0',0,'Success','2026-11-15 09:03:11',138,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:03:11','2026-11-15 09:03:11',168,1,NULL,NULL,NULL,'2026-11-15 09:03:11','2026-11-15 09:03:11','5f75cd3ef25340f25'),('d20487de7346e621b','Process Job Queue e0',0,'Success','2026-11-15 09:16:28',395,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:28','2026-11-15 09:16:28',308,1,NULL,NULL,NULL,'2026-11-15 09:16:28','2026-11-15 09:16:28','5f75cd3ef25340f25'),('d2a5af45a7f2f58de','Send Email Notifications',0,'Success','2026-11-15 09:06:00',157,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:08','2026-11-15 09:06:08',29,1,NULL,NULL,NULL,'2026-11-15 09:04:01','2026-11-15 09:06:08','e9d6c9980d694fb42'),('d2cd0f4866ab22088','Process Job Queue q1',0,'Success','2026-11-15 09:19:00',431,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:19:08','2026-11-15 09:19:08',377,1,NULL,NULL,NULL,'2026-11-15 09:18:08','2026-11-15 09:19:08','ea1678c7ea92717de'),('d2fa6dedce0031d13','Process Job Queue e0',0,'Success','2026-11-15 09:10:28',271,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:28','2026-11-15 09:10:28',148,1,NULL,NULL,NULL,'2026-11-15 09:10:28','2026-11-15 09:10:28','5f75cd3ef25340f25'),('d35e3a8a3db540760','Process Job Queue q1',0,'Success','2026-11-15 09:14:00',327,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:08','2026-11-15 09:14:08',245,1,NULL,NULL,NULL,'2026-11-15 09:13:08','2026-11-15 09:14:08','ea1678c7ea92717de'),('d3d9387b70098327c','Process Job Queue q0',0,'Success','2026-11-15 09:11:48',295,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:11:48','2026-11-15 09:11:48',180,1,NULL,NULL,NULL,'2026-11-15 09:11:48','2026-11-15 09:11:48','5750be1f178c76fe9'),('d44bbc3f885b21b61','Process Job Queue e0',0,'Success','2026-11-15 09:04:01',155,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:04:01','2026-11-15 09:04:01',192,1,NULL,NULL,NULL,'2026-11-15 09:04:01','2026-11-15 09:04:01','5f75cd3ef25340f25'),('d45d3dda0ebb812ef','Send Email Notifications',0,'Success','2026-11-15 09:02:00',74,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:01','2026-11-15 09:02:01',136,1,NULL,NULL,NULL,'2026-11-15 09:00:01','2026-11-15 09:02:01','e9d6c9980d694fb42'),('d4d8cbeb7bb302cb5','Process Job Queue e0',0,'Success','2026-11-15 09:15:58',382,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:15:58','2026-11-15 09:15:58',292,1,NULL,NULL,NULL,'2026-11-15 09:15:58','2026-11-15 09:15:58','5f75cd3ef25340f25'),('d4d933eba80d28c37','Submit Popup Reminders',0,'Success','2026-11-15 09:15:48',380,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:15:48','2026-11-15 09:15:48',289,1,NULL,NULL,NULL,'2026-11-15 09:15:48','2026-11-15 09:15:48','bcd1c259a799fac87'),('d5096a8e29f3d989d','Auth Token Control',0,'Success','2026-11-15 09:00:00',17,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:00:01','2026-11-15 09:00:01',80,1,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 09:00:01','eeb2498dde7129c23'),('d594a73048049ef33','Submit Popup Reminders',0,'Success','2026-11-15 09:07:48',213,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:07:48','2026-11-15 09:07:48',74,1,NULL,NULL,NULL,'2026-11-15 09:07:48','2026-11-15 09:07:48','bcd1c259a799fac87'),('d5ab6d60e981edd26','Process Job Queue q0',0,'Success','2026-11-15 09:15:58',381,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:15:58','2026-11-15 09:15:58',291,1,NULL,NULL,NULL,'2026-11-15 09:15:58','2026-11-15 09:15:58','5750be1f178c76fe9'),('d5d6e877fab8d15e4','Process Job Queue q0',0,'Success','2026-11-15 09:14:18',350,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:18','2026-11-15 09:14:18',250,1,NULL,NULL,NULL,'2026-11-15 09:14:18','2026-11-15 09:14:18','5750be1f178c76fe9'),('d7cb10a7d0b833c24','Process Job Queue q0',0,'Success','2026-11-15 09:07:28',205,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:07:28','2026-11-15 09:07:28',64,1,NULL,NULL,NULL,'2026-11-15 09:07:28','2026-11-15 09:07:28','5750be1f178c76fe9'),('d814e5a039b1f8c7e','Process Job Queue q1',0,'Success','2026-11-15 09:11:00',266,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:11:08','2026-11-15 09:11:08',163,1,NULL,NULL,NULL,'2026-11-15 09:10:08','2026-11-15 09:11:08','ea1678c7ea92717de'),('d8420345b168f7bd6','Submit Popup Reminders',0,'Success','2026-11-15 09:01:11',98,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:11','2026-11-15 09:01:11',116,1,NULL,NULL,NULL,'2026-11-15 09:01:11','2026-11-15 09:01:11','bcd1c259a799fac87'),('d872b18e9662bce80','Process Job Queue e0',0,'Success','2026-11-15 09:06:38',190,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:38','2026-11-15 09:06:38',44,1,NULL,NULL,NULL,'2026-11-15 09:06:38','2026-11-15 09:06:38','5f75cd3ef25340f25'),('d97d25b088b77304c','Process Job Queue e0',0,'Success','2026-11-15 09:18:28',437,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:28','2026-11-15 09:18:28',362,1,NULL,NULL,NULL,'2026-11-15 09:18:28','2026-11-15 09:18:28','5f75cd3ef25340f25'),('da167965da0a4a6df','Process Job Queue q0',0,'Success','2026-11-15 09:16:28',394,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:28','2026-11-15 09:16:28',307,1,NULL,NULL,NULL,'2026-11-15 09:16:28','2026-11-15 09:16:28','5750be1f178c76fe9'),('da5b121df80641ec3','Auth Token Control',0,'Pending','2026-11-15 09:30:00',504,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-11-15 09:27:41','2026-11-15 09:27:41','eeb2498dde7129c23'),('db2f58f7a4f220ca8','Send Email Reminders',0,'Success','2026-11-15 09:08:00',175,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:08','2026-11-15 09:08:08',80,1,NULL,NULL,NULL,'2026-11-15 09:06:08','2026-11-15 09:08:08','38c14103df40c8494'),('db7623e237181bddd','Submit Popup Reminders',0,'Success','2026-11-15 09:09:38',251,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:09:38','2026-11-15 09:09:38',123,1,NULL,NULL,NULL,'2026-11-15 09:09:38','2026-11-15 09:09:38','bcd1c259a799fac87'),('dba8ea026464ac4ce','Submit Popup Reminders',0,'Success','2026-11-15 09:05:48',171,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:05:48','2026-11-15 09:05:48',20,1,NULL,NULL,NULL,'2026-11-15 09:05:48','2026-11-15 09:05:48','bcd1c259a799fac87'),('dc080d2ccc4e64647','Submit Popup Reminders',0,'Success','2026-11-15 09:17:18',412,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:17:18','2026-11-15 09:17:18',330,1,NULL,NULL,NULL,'2026-11-15 09:17:18','2026-11-15 09:17:18','bcd1c259a799fac87'),('ddbf646d99de753ff','Process Job Queue q1',0,'Success','2026-11-15 09:12:00',285,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:08','2026-11-15 09:12:08',192,1,NULL,NULL,NULL,'2026-11-15 09:11:08','2026-11-15 09:12:08','ea1678c7ea92717de'),('ddc1e8ef878ff869b','Process Webhook Queue',0,'Success','2026-11-15 09:02:00',69,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:02:01','2026-11-15 09:02:01',135,1,NULL,NULL,NULL,'2026-11-15 09:00:01','2026-11-15 09:02:01','4a6a036f21dffd48a'),('de0166a498276c039','Process Job Queue e0',0,'Success','2026-11-15 09:16:08',387,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:08','2026-11-15 09:16:08',300,1,NULL,NULL,NULL,'2026-11-15 09:16:08','2026-11-15 09:16:08','5f75cd3ef25340f25'),('e00492d9df37aa373','Process Job Queue q0',0,'Success','2026-11-15 09:06:58',195,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:58','2026-11-15 09:06:58',51,1,NULL,NULL,NULL,'2026-11-15 09:06:58','2026-11-15 09:06:58','5750be1f178c76fe9'),('e0990f02e68eaab76','Process Job Queue e0',0,'Success','2026-11-15 09:17:58',423,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:17:58','2026-11-15 09:17:58',345,1,NULL,NULL,NULL,'2026-11-15 09:17:58','2026-11-15 09:17:58','5f75cd3ef25340f25'),('e0d996a7041718a0a','Process Job Queue e0',0,'Success','2026-11-15 09:15:38',376,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:15:38','2026-11-15 09:15:38',284,1,NULL,NULL,NULL,'2026-11-15 09:15:38','2026-11-15 09:15:38','5f75cd3ef25340f25'),('e1801313e90b05b6b','Process Job Queue e0',0,'Success','2026-11-15 09:28:01',510,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:28:01','2026-11-15 09:28:01',24,1,NULL,NULL,NULL,'2026-11-15 09:28:01','2026-11-15 09:28:01','5f75cd3ef25340f25'),('e3a50907641b1f115','Process Job Queue e0',0,'Success','2026-11-15 09:09:18',244,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:09:18','2026-11-15 09:09:18',114,1,NULL,NULL,NULL,'2026-11-15 09:09:18','2026-11-15 09:09:18','5f75cd3ef25340f25'),('e3c53a45df03d1c3a','Process Job Queue q0',0,'Success','2026-11-15 09:06:38',189,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:38','2026-11-15 09:06:38',43,1,NULL,NULL,NULL,'2026-11-15 09:06:38','2026-11-15 09:06:38','5750be1f178c76fe9'),('e45dcf8da9b299a11','Process Job Queue q0',0,'Success','2026-11-15 09:05:38',166,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:05:38','2026-11-15 09:05:38',14,1,NULL,NULL,NULL,'2026-11-15 09:05:38','2026-11-15 09:05:38','5750be1f178c76fe9'),('e52e00e2cc26c2e30','Process Webhook Queue',0,'Success','2026-11-15 09:12:00',259,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:08','2026-11-15 09:12:08',190,1,NULL,NULL,NULL,'2026-11-15 09:10:08','2026-11-15 09:12:08','4a6a036f21dffd48a'),('e5849b072c24d5134','Send Scheduled Emails',0,'Success','2026-11-15 09:10:00',73,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:08','2026-11-15 09:10:08',134,1,NULL,NULL,NULL,'2026-11-15 09:00:01','2026-11-15 09:10:08','c96bb4400337657cf'),('e5ad6cc7c962d250c','Send Email Notifications',0,'Success','2026-11-15 09:18:00',389,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:08','2026-11-15 09:18:08',351,1,NULL,NULL,NULL,'2026-11-15 09:16:08','2026-11-15 09:18:08','e9d6c9980d694fb42'),('e5af26ed8681d8580','Process Webhook Queue',0,'Success','2026-11-15 09:04:00',112,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:04:01','2026-11-15 09:04:01',188,1,NULL,NULL,NULL,'2026-11-15 09:02:01','2026-11-15 09:04:01','4a6a036f21dffd48a'),('e7076a97485397525','Auth Token Control',0,'Success','2026-11-15 09:24:00',432,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:27:41','2026-11-15 09:27:42',13,1,NULL,NULL,NULL,'2026-11-15 09:18:08','2026-11-15 09:27:42','eeb2498dde7129c23'),('e76a46d91ef727157','Process Job Queue q0',0,'Success','2026-11-15 09:19:08',448,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:19:08','2026-11-15 09:19:08',378,1,NULL,NULL,NULL,'2026-11-15 09:19:08','2026-11-15 09:19:08','5750be1f178c76fe9'),('e783612582b94bcdf','Submit Popup Reminders',0,'Success','2026-11-15 09:12:38',317,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:38','2026-11-15 09:12:38',207,1,NULL,NULL,NULL,'2026-11-15 09:12:38','2026-11-15 09:12:38','bcd1c259a799fac87'),('e81c998babac12ebc','Submit Popup Reminders',0,'Success','2026-11-15 09:01:21',101,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:21','2026-11-15 09:01:21',120,1,NULL,NULL,NULL,'2026-11-15 09:01:21','2026-11-15 09:01:21','bcd1c259a799fac87'),('e886da5f238b6c91b','Process Job Queue e0',0,'Success','2026-11-15 09:14:58',363,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:58','2026-11-15 09:14:58',267,1,NULL,NULL,NULL,'2026-11-15 09:14:58','2026-11-15 09:14:58','5f75cd3ef25340f25'),('e886dd0336cad1943','Send Email Notifications',0,'Success','2026-11-15 09:12:00',265,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:08','2026-11-15 09:12:08',191,1,NULL,NULL,NULL,'2026-11-15 09:10:08','2026-11-15 09:12:08','e9d6c9980d694fb42'),('e8ff43257c3e72d4e','Process Job Queue q0',0,'Success','2026-11-15 09:09:48',252,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:09:48','2026-11-15 09:09:48',125,1,NULL,NULL,NULL,'2026-11-15 09:09:48','2026-11-15 09:09:48','5750be1f178c76fe9'),('e9d33d03724dc9985','Process Job Queue e0',0,'Success','2026-11-15 09:19:28',456,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:19:28','2026-11-15 09:19:28',387,1,NULL,NULL,NULL,'2026-11-15 09:19:28','2026-11-15 09:19:28','5f75cd3ef25340f25'),('e9f2337e11203ac6a','Process Job Queue q0',0,'Success','2026-11-15 09:14:58',362,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:58','2026-11-15 09:14:58',266,1,NULL,NULL,NULL,'2026-11-15 09:14:58','2026-11-15 09:14:58','5750be1f178c76fe9'),('ead85522fe505ad2d','Submit Popup Reminders',0,'Success','2026-11-15 09:03:31',145,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:03:31','2026-11-15 09:03:31',177,1,NULL,NULL,NULL,'2026-11-15 09:03:31','2026-11-15 09:03:31','bcd1c259a799fac87'),('ead8ada55be7779e7','Submit Popup Reminders',0,'Success','2026-11-15 08:57:21',13,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 08:57:21',14,1,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 08:57:21','bcd1c259a799fac87'),('ebf5ea7ee584bc5a8','Process Job Queue q0',0,'Success','2026-11-15 09:13:48',337,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:13:48','2026-11-15 09:13:48',234,1,NULL,NULL,NULL,'2026-11-15 09:13:48','2026-11-15 09:13:48','5750be1f178c76fe9'),('ec4ef8aa4f52ef62e','Process Job Queue e0',0,'Success','2026-11-15 09:10:48',277,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:48','2026-11-15 09:10:48',156,1,NULL,NULL,NULL,'2026-11-15 09:10:48','2026-11-15 09:10:48','5f75cd3ef25340f25'),('ec7ad5a5270b9bbac','Submit Popup Reminders',0,'Success','2026-11-15 09:16:48',402,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:48','2026-11-15 09:16:48',317,1,NULL,NULL,NULL,'2026-11-15 09:16:48','2026-11-15 09:16:48','bcd1c259a799fac87'),('ee37f712df247f7cf','Process Job Queue q0',0,'Success','2026-11-15 08:59:41',62,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:59:41','2026-11-15 08:59:41',71,1,NULL,NULL,NULL,'2026-11-15 08:59:41','2026-11-15 08:59:41','5750be1f178c76fe9'),('ef59d7f31fef8d7ac','Send Email Notifications',0,'Success','2026-11-15 09:14:00',306,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:08','2026-11-15 09:14:08',244,1,NULL,NULL,NULL,'2026-11-15 09:12:08','2026-11-15 09:14:08','e9d6c9980d694fb42'),('efc8026e65320fb80','Submit Popup Reminders',0,'Success','2026-11-15 09:17:38',418,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:17:38','2026-11-15 09:17:38',338,1,NULL,NULL,NULL,'2026-11-15 09:17:38','2026-11-15 09:17:38','bcd1c259a799fac87'),('f16aa4b4c0ae313a2','Submit Popup Reminders',0,'Success','2026-11-15 09:03:11',139,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:03:11','2026-11-15 09:03:11',169,1,NULL,NULL,NULL,'2026-11-15 09:03:11','2026-11-15 09:03:11','bcd1c259a799fac87'),('f1760c64cc80a8dc2','Submit Popup Reminders',0,'Success','2026-11-15 09:13:38',336,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:13:38','2026-11-15 09:13:38',232,1,NULL,NULL,NULL,'2026-11-15 09:13:38','2026-11-15 09:13:38','bcd1c259a799fac87'),('f218c89f6319c9f08','Sync Currency Rates',0,'Pending','2026-11-15 19:02:00',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 08:57:21','0199adc75e4a5b384'),('f26a23eb7c0edb0d7','Process Job Queue q0',0,'Success','2026-11-15 09:01:41',105,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:41','2026-11-15 09:01:41',126,1,NULL,NULL,NULL,'2026-11-15 09:01:41','2026-11-15 09:01:41','5750be1f178c76fe9'),('f28436594dc156100','Submit Popup Reminders',0,'Success','2026-11-15 09:13:18',330,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:13:18','2026-11-15 09:13:18',224,1,NULL,NULL,NULL,'2026-11-15 09:13:18','2026-11-15 09:13:18','bcd1c259a799fac87'),('f3b490a6f2dfbf810','Process Job Queue e0',0,'Success','2026-11-15 09:03:01',134,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:03:01','2026-11-15 09:03:01',164,1,NULL,NULL,NULL,'2026-11-15 09:03:01','2026-11-15 09:03:01','5f75cd3ef25340f25'),('f3ccfb805721de9e7','Process Job Queue e0',0,'Success','2026-11-15 08:57:31',19,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:57:31','2026-11-15 08:57:31',15,1,NULL,NULL,NULL,'2026-11-15 08:57:31','2026-11-15 08:57:31','5f75cd3ef25340f25'),('f4c86ebc30b085efd','Process Job Queue e0',0,'Success','2026-11-15 09:06:58',196,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:58','2026-11-15 09:06:58',52,1,NULL,NULL,NULL,'2026-11-15 09:06:58','2026-11-15 09:06:58','5f75cd3ef25340f25'),('f5d6ee6b1c2fbda54','Submit Popup Reminders',0,'Success','2026-11-15 09:06:28',188,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:06:28','2026-11-15 09:06:28',41,1,NULL,NULL,NULL,'2026-11-15 09:06:28','2026-11-15 09:06:28','bcd1c259a799fac87'),('f65346952a662b65b','Process Job Queue e0',0,'Success','2026-11-15 09:27:51',507,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:27:51','2026-11-15 09:27:51',20,1,NULL,NULL,NULL,'2026-11-15 09:27:51','2026-11-15 09:27:51','5f75cd3ef25340f25'),('f684fa8a60640e9c9','Process Job Queue q0',0,'Success','2026-11-15 09:15:38',375,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:15:38','2026-11-15 09:15:38',283,1,NULL,NULL,NULL,'2026-11-15 09:15:38','2026-11-15 09:15:38','5750be1f178c76fe9'),('f6a07b91f25760741','Process Job Queue q0',0,'Success','2026-11-15 09:12:08',303,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:08','2026-11-15 09:12:08',193,1,NULL,NULL,NULL,'2026-11-15 09:12:08','2026-11-15 09:12:08','5750be1f178c76fe9'),('f72484608c1996d12','Process Job Queue q0',0,'Success','2026-11-15 09:04:01',154,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:04:01','2026-11-15 09:04:01',191,1,NULL,NULL,NULL,'2026-11-15 09:04:01','2026-11-15 09:04:01','5750be1f178c76fe9'),('f7c18f2c846c5afea','Process Job Queue e0',0,'Success','2026-11-15 08:57:21',8,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 08:57:21',13,1,NULL,NULL,NULL,'2026-11-15 08:57:21','2026-11-15 08:57:21','5f75cd3ef25340f25'),('f7f3e14e2708b0de0','Process Job Queue q0',0,'Success','2026-11-15 08:58:41',43,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:41','2026-11-15 08:58:41',46,1,NULL,NULL,NULL,'2026-11-15 08:58:41','2026-11-15 08:58:41','5750be1f178c76fe9'),('f89018affee30e7af','Process Job Queue q0',0,'Success','2026-11-15 09:09:28',246,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:09:28','2026-11-15 09:09:28',117,1,NULL,NULL,NULL,'2026-11-15 09:09:28','2026-11-15 09:09:28','5750be1f178c76fe9'),('f8c9cd2e623d5c6c3','Process Job Queue q0',0,'Success','2026-11-15 09:08:48',233,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:48','2026-11-15 09:08:48',100,1,NULL,NULL,NULL,'2026-11-15 09:08:48','2026-11-15 09:08:48','5750be1f178c76fe9'),('f99b993f74e438d0f','Process Job Queue q0',0,'Success','2026-11-15 09:01:31',102,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:01:31','2026-11-15 09:01:31',122,1,NULL,NULL,NULL,'2026-11-15 09:01:31','2026-11-15 09:01:31','5750be1f178c76fe9'),('fa303f914c9cb2a6c','Process Job Queue e0',0,'Success','2026-11-15 09:07:38',209,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:07:38','2026-11-15 09:07:38',69,1,NULL,NULL,NULL,'2026-11-15 09:07:38','2026-11-15 09:07:38','5f75cd3ef25340f25'),('faafc4b04398b83ec','Submit Popup Reminders',0,'Success','2026-11-15 09:10:08',263,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:10:08','2026-11-15 09:10:08',141,1,NULL,NULL,NULL,'2026-11-15 09:10:08','2026-11-15 09:10:08','bcd1c259a799fac87'),('fb00e7420f2f453ea','Submit Popup Reminders',0,'Success','2026-11-15 09:15:58',383,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:15:58','2026-11-15 09:15:58',293,1,NULL,NULL,NULL,'2026-11-15 09:15:58','2026-11-15 09:15:58','bcd1c259a799fac87'),('fb64989ad27eccc91','Process Job Queue q0',0,'Success','2026-11-15 09:07:58',214,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:07:58','2026-11-15 09:07:58',76,1,NULL,NULL,NULL,'2026-11-15 09:07:58','2026-11-15 09:07:58','5750be1f178c76fe9'),('fb8a941c3b17f6c46','Process Job Queue q0',0,'Success','2026-11-15 09:17:08',406,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:17:08','2026-11-15 09:17:08',324,1,NULL,NULL,NULL,'2026-11-15 09:17:08','2026-11-15 09:17:08','5750be1f178c76fe9'),('fbba14007eb12f277','Process Job Queue q0',0,'Success','2026-11-15 09:28:01',509,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:28:01','2026-11-15 09:28:01',23,1,NULL,NULL,NULL,'2026-11-15 09:28:01','2026-11-15 09:28:01','5750be1f178c76fe9'),('fbf4718f18c72adb7','Submit Popup Reminders',0,'Success','2026-11-15 09:08:28',229,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:08:28','2026-11-15 09:08:28',94,1,NULL,NULL,NULL,'2026-11-15 09:08:28','2026-11-15 09:08:28','bcd1c259a799fac87'),('fc5477409a2d8d987','Process Job Queue e0',0,'Success','2026-11-15 08:58:01',30,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:01','2026-11-15 08:58:01',31,1,NULL,NULL,NULL,'2026-11-15 08:58:01','2026-11-15 08:58:01','5f75cd3ef25340f25'),('fc7377705595e4bdd','Submit Popup Reminders',0,'Success','2026-11-15 09:16:08',388,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:16:08','2026-11-15 09:16:08',301,1,NULL,NULL,NULL,'2026-11-15 09:16:08','2026-11-15 09:16:08','bcd1c259a799fac87'),('fc91e4e056f8e6384','Submit Popup Reminders',0,'Success','2026-11-15 08:58:51',48,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:58:51','2026-11-15 08:58:51',52,1,NULL,NULL,NULL,'2026-11-15 08:58:51','2026-11-15 08:58:51','bcd1c259a799fac87'),('fc94d3ff2afb0e17e','Process Job Queue e0',0,'Success','2026-11-15 09:15:48',379,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:15:48','2026-11-15 09:15:48',288,1,NULL,NULL,NULL,'2026-11-15 09:15:48','2026-11-15 09:15:48','5f75cd3ef25340f25'),('fcf13d51a19ad6f23','Submit Popup Reminders',0,'Success','2026-11-15 09:19:18',454,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:19:18','2026-11-15 09:19:18',384,1,NULL,NULL,NULL,'2026-11-15 09:19:18','2026-11-15 09:19:18','bcd1c259a799fac87'),('fd54a7d5cfd338219','Process Job Queue e0',0,'Success','2026-11-15 09:18:38',440,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:38','2026-11-15 09:18:38',366,1,NULL,NULL,NULL,'2026-11-15 09:18:38','2026-11-15 09:18:38','5f75cd3ef25340f25'),('ff0f76f02d57ecb00','Process Job Queue e0',0,'Success','2026-11-15 09:18:58',446,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:18:58','2026-11-15 09:18:58',374,1,NULL,NULL,NULL,'2026-11-15 09:18:58','2026-11-15 09:18:58','5f75cd3ef25340f25'),('ff2518b6358fc6450','Submit Popup Reminders',0,'Success','2026-11-15 09:12:18',311,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:12:18','2026-11-15 09:12:18',199,1,NULL,NULL,NULL,'2026-11-15 09:12:18','2026-11-15 09:12:18','bcd1c259a799fac87'),('ff545a56b64af20fe','Submit Popup Reminders',0,'Success','2026-11-15 09:20:28',480,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:20:28','2026-11-15 09:20:28',417,1,NULL,NULL,NULL,'2026-11-15 09:20:28','2026-11-15 09:20:28','bcd1c259a799fac87'),('ff564518d6238fd77','Process Job Queue e0',0,'Success','2026-11-15 09:14:38',357,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:14:38','2026-11-15 09:14:38',259,1,NULL,NULL,NULL,'2026-11-15 09:14:38','2026-11-15 09:14:38','5f75cd3ef25340f25'),('ff71e27f8313dc776','Process Job Queue e0',0,'Success','2026-11-15 09:13:18',329,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 09:13:18','2026-11-15 09:13:18',223,1,NULL,NULL,NULL,'2026-11-15 09:13:18','2026-11-15 09:13:18','5f75cd3ef25340f25'),('ff9b3a51070d44729','Process Job Queue q0',0,'Success','2026-11-15 08:57:31',18,NULL,NULL,NULL,NULL,NULL,NULL,'2026-11-15 08:57:31','2026-11-15 08:57:31',14,1,NULL,NULL,NULL,'2026-11-15 08:57:31','2026-11-15 08:57:31','5750be1f178c76fe9');
/*!40000 ALTER TABLE `job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kanban_order`
--

DROP TABLE IF EXISTS `kanban_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kanban_order` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `order` smallint DEFAULT NULL,
  `group` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ENTITY_USER_ID` (`entity_type`,`entity_id`,`user_id`),
  KEY `IDX_ENTITY_TYPE` (`entity_type`),
  KEY `IDX_ENTITY_TYPE_USER_ID` (`entity_type`,`user_id`),
  KEY `IDX_ENTITY` (`entity_id`,`entity_type`),
  KEY `IDX_USER` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kanban_order`
--

LOCK TABLES `kanban_order` WRITE;
/*!40000 ALTER TABLE `kanban_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `kanban_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_base_article`
--

DROP TABLE IF EXISTS `knowledge_base_article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_base_article` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Draft',
  `language` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Article',
  `publish_date` date DEFAULT NULL,
  `expiration_date` date DEFAULT NULL,
  `order` int DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `body` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `body_plain` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_html` tinyint NOT NULL DEFAULT '0',
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  FULLTEXT KEY `IDX_SYSTEM_FULL_TEXT_SEARCH` (`name`,`body_plain`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base_article`
--

LOCK TABLES `knowledge_base_article` WRITE;
/*!40000 ALTER TABLE `knowledge_base_article` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_base_article` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_base_article_knowledge_base_category`
--

DROP TABLE IF EXISTS `knowledge_base_article_knowledge_base_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_base_article_knowledge_base_category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `knowledge_base_article_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `knowledge_base_category_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_KNOWLEDGE_BASE_ARTICLE_ID_KNOWLEDGE_BASE_CATEGORY_ID` (`knowledge_base_article_id`,`knowledge_base_category_id`),
  KEY `IDX_KNOWLEDGE_BASE_ARTICLE_ID` (`knowledge_base_article_id`),
  KEY `IDX_KNOWLEDGE_BASE_CATEGORY_ID` (`knowledge_base_category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base_article_knowledge_base_category`
--

LOCK TABLES `knowledge_base_article_knowledge_base_category` WRITE;
/*!40000 ALTER TABLE `knowledge_base_article_knowledge_base_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_base_article_knowledge_base_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_base_article_portal`
--

DROP TABLE IF EXISTS `knowledge_base_article_portal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_base_article_portal` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `portal_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `knowledge_base_article_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_PORTAL_ID_KNOWLEDGE_BASE_ARTICLE_ID` (`portal_id`,`knowledge_base_article_id`),
  KEY `IDX_PORTAL_ID` (`portal_id`),
  KEY `IDX_KNOWLEDGE_BASE_ARTICLE_ID` (`knowledge_base_article_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base_article_portal`
--

LOCK TABLES `knowledge_base_article_portal` WRITE;
/*!40000 ALTER TABLE `knowledge_base_article_portal` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_base_article_portal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_base_category`
--

DROP TABLE IF EXISTS `knowledge_base_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_base_category` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `order` int DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base_category`
--

LOCK TABLES `knowledge_base_category` WRITE;
/*!40000 ALTER TABLE `knowledge_base_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_base_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `knowledge_base_category_path`
--

DROP TABLE IF EXISTS `knowledge_base_category_path`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `knowledge_base_category_path` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ascendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ASCENDOR_ID` (`ascendor_id`),
  KEY `IDX_DESCENDOR_ID` (`descendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `knowledge_base_category_path`
--

LOCK TABLES `knowledge_base_category_path` WRITE;
/*!40000 ALTER TABLE `knowledge_base_category_path` DISABLE KEYS */;
/*!40000 ALTER TABLE `knowledge_base_category_path` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `layout_record`
--

DROP TABLE IF EXISTS `layout_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `layout_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `layout_set_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_NAME_LAYOUT_SET_ID` (`name`,`layout_set_id`),
  KEY `IDX_LAYOUT_SET_ID` (`layout_set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `layout_record`
--

LOCK TABLES `layout_record` WRITE;
/*!40000 ALTER TABLE `layout_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `layout_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `layout_set`
--

DROP TABLE IF EXISTS `layout_set`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `layout_set` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `layout_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `layout_set`
--

LOCK TABLES `layout_set` WRITE;
/*!40000 ALTER TABLE `layout_set` DISABLE KEYS */;
/*!40000 ALTER TABLE `layout_set` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead`
--

DROP TABLE IF EXISTS `lead`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `salutation_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'New',
  `source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `industry` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opportunity_amount` double DEFAULT NULL,
  `website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_postal_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `do_not_call` tinyint NOT NULL DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `converted_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `account_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `middle_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opportunity_amount_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_opportunity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_FIRST_NAME` (`first_name`,`deleted`),
  KEY `IDX_NAME` (`first_name`,`last_name`),
  KEY `IDX_STATUS` (`status`,`deleted`),
  KEY `IDX_CREATED_AT` (`created_at`,`deleted`),
  KEY `IDX_CREATED_AT_STATUS` (`created_at`,`status`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_ASSIGNED_USER_STATUS` (`assigned_user_id`,`status`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_CREATED_ACCOUNT_ID` (`created_account_id`),
  KEY `IDX_CREATED_CONTACT_ID` (`created_contact_id`),
  KEY `IDX_CREATED_OPPORTUNITY_ID` (`created_opportunity_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead`
--

LOCK TABLES `lead` WRITE;
/*!40000 ALTER TABLE `lead` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_capture`
--

DROP TABLE IF EXISTS `lead_capture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_capture` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `is_active` tinyint NOT NULL DEFAULT '1',
  `subscribe_to_target_list` tinyint NOT NULL DEFAULT '1',
  `subscribe_contact_to_target_list` tinyint NOT NULL DEFAULT '1',
  `field_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `field_params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `duplicate_check` tinyint NOT NULL DEFAULT '1',
  `opt_in_confirmation` tinyint NOT NULL DEFAULT '0',
  `opt_in_confirmation_lifetime` int DEFAULT '48',
  `opt_in_confirmation_success_message` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `create_lead_before_opt_in_confirmation` tinyint NOT NULL DEFAULT '0',
  `skip_opt_in_confirmation_if_subscribed` tinyint NOT NULL DEFAULT '0',
  `lead_source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Web Site',
  `api_key` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_enabled` tinyint NOT NULL DEFAULT '0',
  `form_title` varchar(80) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_theme` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_text` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `form_success_text` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `form_success_redirect_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_language` varchar(5) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `form_frame_ancestors` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `form_captcha` tinyint NOT NULL DEFAULT '0',
  `phone_number_country` varchar(2) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opt_in_confirmation_email_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pipeline_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inbound_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`),
  KEY `IDX_OPT_IN_CONFIRMATION_EMAIL_TEMPLATE_ID` (`opt_in_confirmation_email_template_id`),
  KEY `IDX_PIPELINE_ID` (`pipeline_id`),
  KEY `IDX_TARGET_TEAM_ID` (`target_team_id`),
  KEY `IDX_INBOUND_EMAIL_ID` (`inbound_email_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_capture`
--

LOCK TABLES `lead_capture` WRITE;
/*!40000 ALTER TABLE `lead_capture` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_capture` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_capture_log_record`
--

DROP TABLE IF EXISTS `lead_capture_log_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_capture_log_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `number` int unsigned NOT NULL AUTO_INCREMENT,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `is_created` tinyint NOT NULL DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `lead_capture_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_LEAD_CAPTURE_ID` (`lead_capture_id`),
  KEY `IDX_TARGET` (`target_id`,`target_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_capture_log_record`
--

LOCK TABLES `lead_capture_log_record` WRITE;
/*!40000 ALTER TABLE `lead_capture_log_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_capture_log_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_meeting`
--

DROP TABLE IF EXISTS `lead_meeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_meeting` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `lead_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meeting_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_LEAD_ID_MEETING_ID` (`lead_id`,`meeting_id`),
  KEY `IDX_LEAD_ID` (`lead_id`),
  KEY `IDX_MEETING_ID` (`meeting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_meeting`
--

LOCK TABLES `lead_meeting` WRITE;
/*!40000 ALTER TABLE `lead_meeting` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_meeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lead_target_list`
--

DROP TABLE IF EXISTS `lead_target_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lead_target_list` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `lead_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opted_out` tinyint DEFAULT '0',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_LEAD_ID_TARGET_LIST_ID` (`lead_id`,`target_list_id`),
  KEY `IDX_LEAD_ID` (`lead_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lead_target_list`
--

LOCK TABLES `lead_target_list` WRITE;
/*!40000 ALTER TABLE `lead_target_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `lead_target_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mass_action`
--

DROP TABLE IF EXISTS `mass_action`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mass_action` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `entity_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `processed_count` int DEFAULT NULL,
  `notify_on_finish` tinyint NOT NULL DEFAULT '0',
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mass_action`
--

LOCK TABLES `mass_action` WRITE;
/*!40000 ALTER TABLE `mass_action` DISABLE KEYS */;
/*!40000 ALTER TABLE `mass_action` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mass_email`
--

DROP TABLE IF EXISTS `mass_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mass_email` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `store_sent_emails` tinyint NOT NULL DEFAULT '0',
  `opt_out_entirely` tinyint NOT NULL DEFAULT '0',
  `from_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_to_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reply_to_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `email_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inbound_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_EMAIL_TEMPLATE_ID` (`email_template_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_INBOUND_EMAIL_ID` (`inbound_email_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mass_email`
--

LOCK TABLES `mass_email` WRITE;
/*!40000 ALTER TABLE `mass_email` DISABLE KEYS */;
/*!40000 ALTER TABLE `mass_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mass_email_target_list`
--

DROP TABLE IF EXISTS `mass_email_target_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mass_email_target_list` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `mass_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_MASS_EMAIL_ID_TARGET_LIST_ID` (`mass_email_id`,`target_list_id`),
  KEY `IDX_MASS_EMAIL_ID` (`mass_email_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mass_email_target_list`
--

LOCK TABLES `mass_email_target_list` WRITE;
/*!40000 ALTER TABLE `mass_email_target_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `mass_email_target_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mass_email_target_list_excluding`
--

DROP TABLE IF EXISTS `mass_email_target_list_excluding`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mass_email_target_list_excluding` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `mass_email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_MASS_EMAIL_ID_TARGET_LIST_ID` (`mass_email_id`,`target_list_id`),
  KEY `IDX_MASS_EMAIL_ID` (`mass_email_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mass_email_target_list_excluding`
--

LOCK TABLES `mass_email_target_list_excluding` WRITE;
/*!40000 ALTER TABLE `mass_email_target_list_excluding` DISABLE KEYS */;
/*!40000 ALTER TABLE `mass_email_target_list_excluding` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meeting`
--

DROP TABLE IF EXISTS `meeting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meeting` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Planned',
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `is_all_day` tinyint NOT NULL DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `uid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `join_url` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `external_service` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `date_start_date` date DEFAULT NULL,
  `date_end_date` date DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_DATE_START_STATUS` (`date_start`,`status`),
  KEY `IDX_DATE_START` (`date_start`,`deleted`),
  KEY `IDX_STATUS` (`status`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_ASSIGNED_USER_STATUS` (`assigned_user_id`,`status`),
  KEY `IDX_UID` (`uid`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting`
--

LOCK TABLES `meeting` WRITE;
/*!40000 ALTER TABLE `meeting` DISABLE KEYS */;
/*!40000 ALTER TABLE `meeting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meeting_user`
--

DROP TABLE IF EXISTS `meeting_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meeting_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meeting_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'None',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ID_MEETING_ID` (`user_id`,`meeting_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_MEETING_ID` (`meeting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meeting_user`
--

LOCK TABLES `meeting_user` WRITE;
/*!40000 ALTER TABLE `meeting_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `meeting_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `next_number`
--

DROP TABLE IF EXISTS `next_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `next_number` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` int DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `IDX_ENTITY_TYPE_FIELD_NAME` (`entity_type`,`field_name`),
  KEY `IDX_ENTITY_TYPE` (`entity_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `next_number`
--

LOCK TABLES `next_number` WRITE;
/*!40000 ALTER TABLE `next_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `next_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note`
--

DROP TABLE IF EXISTS `note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `post` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `type` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Post',
  `target_type` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number` bigint unsigned NOT NULL AUTO_INCREMENT,
  `is_global` tinyint NOT NULL DEFAULT '0',
  `is_internal` tinyint NOT NULL DEFAULT '0',
  `is_pinned` tinyint NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `super_parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `super_parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_CREATED_BY_NUMBER` (`created_by_id`,`number`),
  KEY `IDX_TYPE` (`type`),
  KEY `IDX_TARGET_TYPE` (`target_type`),
  KEY `IDX_PARENT_ID` (`parent_id`),
  KEY `IDX_PARENT_TYPE` (`parent_type`),
  KEY `IDX_RELATED_ID` (`related_id`),
  KEY `IDX_RELATED_TYPE` (`related_type`),
  KEY `IDX_SUPER_PARENT_TYPE` (`super_parent_type`),
  KEY `IDX_SUPER_PARENT_ID` (`super_parent_id`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_RELATED` (`related_id`,`related_type`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_SUPER_PARENT` (`super_parent_id`,`super_parent_type`),
  FULLTEXT KEY `IDX_SYSTEM_FULL_TEXT_SEARCH` (`post`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note`
--

LOCK TABLES `note` WRITE;
/*!40000 ALTER TABLE `note` DISABLE KEYS */;
INSERT INTO `note` VALUES ('07cddae7859482a0e',0,NULL,'{\"assignedUserId\":\"ee34b5ae997ac8935\",\"assignedUserName\":\"Максим Сидоров\",\"statusValue\":\"Pending\",\"statusField\":\"status\"}','Create',NULL,17,0,0,0,'2026-11-15 09:01:52','2026-11-15 09:01:52','65a60b6ec788951ef','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'a8e74ae736347bba7','Account'),('0cd09803c5bdc34a8',0,NULL,'{\"assignedUserId\":\"39ce8dc9b1c5e0553\",\"assignedUserName\":\"Марина Козлова\",\"statusValue\":\"New\",\"statusField\":\"status\"}','Create',NULL,42,0,0,0,'2026-11-15 09:01:58','2026-11-15 09:01:58','a4be3e56e0ed0bef6','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'31d97c49e066562c5','Account'),('0e455abf7565c3ef3',0,NULL,'{}','Create',NULL,4,0,0,0,'2026-11-15 09:01:46','2026-11-15 09:01:46','05e7f68d108176fc6','Account',NULL,NULL,'2f1e0b7f89ae3c497',NULL,NULL,NULL),('0e60d8ffb32f57c71',0,NULL,'{\"assignedUserId\":\"ee34b5ae997ac8935\",\"assignedUserName\":\"Максим Сидоров\",\"statusValue\":\"Pending\",\"statusField\":\"status\"}','Create',NULL,41,0,0,0,'2026-11-15 09:01:58','2026-11-15 09:01:58','949eca0fe2cdc9e46','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'a8e74ae736347bba7','Account'),('17584a49620466270',0,NULL,'{}','Create',NULL,1,0,0,0,'2026-11-15 09:01:45','2026-11-15 09:01:45','a8e74ae736347bba7','Account',NULL,NULL,'2f1e0b7f89ae3c497',NULL,NULL,NULL),('1863facb1ca5edcf5',0,NULL,'{}','Create',NULL,6,0,0,0,'2026-11-15 09:01:47','2026-11-15 09:01:47','3fdff7c1df3e0d18d','Account',NULL,NULL,'2f1e0b7f89ae3c497',NULL,NULL,NULL),('19c3b4ed53fcb6f07',0,NULL,'{\"assignedUserId\":\"5345f9133074952bc\",\"assignedUserName\":\"Анна Иванова\",\"statusValue\":\"Closed\",\"statusField\":\"status\"}','Create',NULL,46,0,0,0,'2026-11-15 09:01:59','2026-11-15 09:01:59','620a42f1842ce4dec','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'3fdff7c1df3e0d18d','Account'),('1c21d8ea448ecf298',0,NULL,'{\"assignedUserId\":\"39ce8dc9b1c5e0553\",\"assignedUserName\":\"Марина Козлова\",\"statusValue\":\"Assigned\",\"statusField\":\"status\"}','Create',NULL,39,0,0,0,'2026-11-15 09:01:57','2026-11-15 09:01:57','3063a6cbfe0357f7c','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'5872ce100493fa929','Account'),('23c72dd4786c6e24b',0,NULL,'{}','Create',NULL,11,0,0,0,'2026-11-15 09:01:49','2026-11-15 09:01:49','869e5631ffd4bb052','Contact',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'aec01fbd5ffab15aa','Account'),('2b87df614eb813e01',0,NULL,'{}','Create',NULL,9,0,0,0,'2026-11-15 09:01:48','2026-11-15 09:01:48','40e512e4ee76a1d4c','Contact',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'a8e74ae736347bba7','Account'),('3c1f8cdca9d2571ad',0,NULL,'{\"assignedUserId\":\"ee34b5ae997ac8935\",\"assignedUserName\":\"Максим Сидоров\",\"statusValue\":\"New\",\"statusField\":\"status\"}','Create',NULL,26,0,0,0,'2026-11-15 09:01:54','2026-11-15 09:01:54','478a3e886297a7c29','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'31d97c49e066562c5','Account'),('40484a5030eae7b56',0,NULL,'{\"assignedUserId\":\"5345f9133074952bc\",\"assignedUserName\":\"Анна Иванова\",\"statusValue\":\"New\",\"statusField\":\"status\"}','Create',NULL,37,0,0,0,'2026-11-15 09:01:57','2026-11-15 09:01:57','ba3e914dd98685eb9','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'cab96c889d6e86e00','Account'),('45808b9a6a6246945',0,NULL,'{\"assignedUserId\":\"39ce8dc9b1c5e0553\",\"assignedUserName\":\"Марина Козлова\",\"statusValue\":\"Pending\",\"statusField\":\"status\"}','Create',NULL,27,0,0,0,'2026-11-15 09:01:54','2026-11-15 09:01:54','b71d6f8aa3d764ec8','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'aec01fbd5ffab15aa','Account'),('474f498d604472cb7',0,NULL,'{\"assignedUserId\":\"5345f9133074952bc\",\"assignedUserName\":\"Анна Иванова\",\"statusValue\":\"Closed\",\"statusField\":\"status\"}','Create',NULL,40,0,0,0,'2026-11-15 09:01:57','2026-11-15 09:01:57','0b93c4296977533fc','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'69c3fae08cc458585','Account'),('4c92ed7e561dd9b81',0,NULL,'{\"assignedUserId\":\"5345f9133074952bc\",\"assignedUserName\":\"Анна Иванова\",\"statusValue\":\"Assigned\",\"statusField\":\"status\"}','Create',NULL,25,0,0,0,'2026-11-15 09:01:54','2026-11-15 09:01:54','8c493904f49418113','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'a8e74ae736347bba7','Account'),('4f2345b7de5571b41',0,NULL,'{\"assignedUserId\":\"5345f9133074952bc\",\"assignedUserName\":\"Анна Иванова\",\"statusValue\":\"Assigned\",\"statusField\":\"status\"}','Create',NULL,43,0,0,0,'2026-11-15 09:01:58','2026-11-15 09:01:58','31008b4847f19f412','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'aec01fbd5ffab15aa','Account'),('512c7f0f16ef67bcb',0,NULL,'{}','Create',NULL,5,0,0,0,'2026-11-15 09:01:47','2026-11-15 09:01:47','cab96c889d6e86e00','Account',NULL,NULL,'2f1e0b7f89ae3c497',NULL,NULL,NULL),('561eb15aea25080c5',0,NULL,'{\"assignedUserId\":\"5345f9133074952bc\",\"assignedUserName\":\"Анна Иванова\",\"statusValue\":\"Closed\",\"statusField\":\"status\"}','Create',NULL,22,0,0,0,'2026-11-15 09:01:53','2026-11-15 09:01:53','ded6744bf77097e3e','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'3fdff7c1df3e0d18d','Account'),('58caae19a7963c9e2',0,NULL,'{}','Create',NULL,13,0,0,0,'2026-11-15 09:01:50','2026-11-15 09:01:50','1873952383da2a4ee','Contact',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'cab96c889d6e86e00','Account'),('5a90911071a0f1aed',0,NULL,'{}','Create',NULL,7,0,0,0,'2026-11-15 09:01:47','2026-11-15 09:01:47','5872ce100493fa929','Account',NULL,NULL,'2f1e0b7f89ae3c497',NULL,NULL,NULL),('5ffafe574cd069cb6',0,NULL,'{}','Create',NULL,16,0,0,0,'2026-11-15 09:01:51','2026-11-15 09:01:51','d426d7e7c574ff1ad','Contact',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'69c3fae08cc458585','Account'),('614c66096a028864e',0,NULL,'{\"assignedUserId\":\"ee34b5ae997ac8935\",\"assignedUserName\":\"Максим Сидоров\",\"statusValue\":\"Closed\",\"statusField\":\"status\"}','Create',NULL,23,0,0,0,'2026-11-15 09:01:53','2026-11-15 09:01:53','cee9cbea77de54915','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'5872ce100493fa929','Account'),('730ff4e733011d3a1',0,NULL,'{}','Create',NULL,8,0,0,0,'2026-11-15 09:01:48','2026-11-15 09:01:48','69c3fae08cc458585','Account',NULL,NULL,'2f1e0b7f89ae3c497',NULL,NULL,NULL),('8011c22d9500fe348',0,NULL,'{\"assignedUserId\":\"39ce8dc9b1c5e0553\",\"assignedUserName\":\"Марина Козлова\",\"statusValue\":\"Assigned\",\"statusField\":\"status\"}','Create',NULL,21,0,0,0,'2026-11-15 09:01:53','2026-11-15 09:01:53','2218cde2db4d2f8c6','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'cab96c889d6e86e00','Account'),('88269d311e98019de',0,NULL,'{}','Create',NULL,3,0,0,0,'2026-11-15 09:01:46','2026-11-15 09:01:46','aec01fbd5ffab15aa','Account',NULL,NULL,'2f1e0b7f89ae3c497',NULL,NULL,NULL),('8a74d8c196f578cea',0,NULL,'{\"assignedUserId\":\"ee34b5ae997ac8935\",\"assignedUserName\":\"Максим Сидоров\",\"statusValue\":\"Pending\",\"statusField\":\"status\"}','Create',NULL,38,0,0,0,'2026-11-15 09:01:57','2026-11-15 09:01:57','2df27f5cb9c6fa34b','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'3fdff7c1df3e0d18d','Account'),('90f1a6e650e6cc7ce',0,NULL,'{\"assignedUserId\":\"39ce8dc9b1c5e0553\",\"assignedUserName\":\"Марина Козлова\",\"statusValue\":\"New\",\"statusField\":\"status\"}','Create',NULL,33,0,0,0,'2026-11-15 09:01:56','2026-11-15 09:01:56','ec6704302761c2e15','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'a8e74ae736347bba7','Account'),('91701ed77730c3681',0,NULL,'{\"assignedUserId\":\"39ce8dc9b1c5e0553\",\"assignedUserName\":\"Марина Козлова\",\"statusValue\":\"Pending\",\"statusField\":\"status\"}','Create',NULL,36,0,0,0,'2026-11-15 09:01:56','2026-11-15 09:01:56','63b051e166f107916','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'05e7f68d108176fc6','Account'),('957ab67e283c83238',0,NULL,'{\"assignedUserId\":\"39ce8dc9b1c5e0553\",\"assignedUserName\":\"Марина Козлова\",\"statusValue\":\"Closed\",\"statusField\":\"status\"}','Create',NULL,30,0,0,0,'2026-11-15 09:01:55','2026-11-15 09:01:55','101571574991cdfcc','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'3fdff7c1df3e0d18d','Account'),('95a1ae4bffb2f0fb8',0,NULL,'{\"assignedUserId\":\"ee34b5ae997ac8935\",\"assignedUserName\":\"Максим Сидоров\",\"statusValue\":\"Closed\",\"statusField\":\"status\"}','Create',NULL,35,0,0,0,'2026-11-15 09:01:56','2026-11-15 09:01:56','2f3391890e9cf8f07','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'aec01fbd5ffab15aa','Account'),('9a191522cb0f94bc7',0,NULL,'{\"assignedUserId\":\"39ce8dc9b1c5e0553\",\"assignedUserName\":\"Марина Козлова\",\"statusValue\":\"Assigned\",\"statusField\":\"status\"}','Create',NULL,45,0,0,0,'2026-11-15 09:01:59','2026-11-15 09:01:59','1e8e4646ff308f743','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'cab96c889d6e86e00','Account'),('9f861e45f6baaebb4',0,NULL,'{\"assignedUserId\":\"5345f9133074952bc\",\"assignedUserName\":\"Анна Иванова\",\"statusValue\":\"Assigned\",\"statusField\":\"status\"}','Create',NULL,31,0,0,0,'2026-11-15 09:01:55','2026-11-15 09:01:55','a0fb7b2f12bae0c77','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'5872ce100493fa929','Account'),('a5d29cf9064e34f8a',0,NULL,'{\"assignedUserId\":\"ee34b5ae997ac8935\",\"assignedUserName\":\"Максим Сидоров\",\"statusValue\":\"New\",\"statusField\":\"status\"}','Create',NULL,20,0,0,0,'2026-11-15 09:01:52','2026-11-15 09:01:52','293246eb718f79a6d','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'05e7f68d108176fc6','Account'),('b2685d4a59b7bd21c',0,NULL,'{\"assignedUserId\":\"5345f9133074952bc\",\"assignedUserName\":\"Анна Иванова\",\"statusValue\":\"Assigned\",\"statusField\":\"status\"}','Create',NULL,19,0,0,0,'2026-11-15 09:01:52','2026-11-15 09:01:52','3a9cf76b6672706d0','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'aec01fbd5ffab15aa','Account'),('b2834aa28984d24ec',0,NULL,'{}','Create',NULL,12,0,0,0,'2026-11-15 09:01:50','2026-11-15 09:01:50','7a846e2436bbb7f3b','Contact',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'05e7f68d108176fc6','Account'),('b362e28acebb002b5',0,NULL,'{\"assignedUserId\":\"ee34b5ae997ac8935\",\"assignedUserName\":\"Максим Сидоров\",\"statusValue\":\"Pending\",\"statusField\":\"status\"}','Create',NULL,32,0,0,0,'2026-11-15 09:01:55','2026-11-15 09:01:55','1abc8152e84b9e536','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'69c3fae08cc458585','Account'),('c20bce08ea34bd17a',0,NULL,'{\"assignedUserId\":\"5345f9133074952bc\",\"assignedUserName\":\"Анна Иванова\",\"statusValue\":\"Assigned\",\"statusField\":\"status\"}','Create',NULL,34,0,0,0,'2026-11-15 09:01:56','2026-11-15 09:01:56','5ed5d7d94b82a7bf7','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'31d97c49e066562c5','Account'),('ce8d29d08ee79e2c8',0,NULL,'{\"assignedUserId\":\"39ce8dc9b1c5e0553\",\"assignedUserName\":\"Марина Козлова\",\"statusValue\":\"Pending\",\"statusField\":\"status\"}','Create',NULL,24,0,0,0,'2026-11-15 09:01:53','2026-11-15 09:01:53','50e213c04e65df5a9','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'69c3fae08cc458585','Account'),('d580a8bc4aca1b9ec',0,NULL,'{}','Create',NULL,10,0,0,0,'2026-11-15 09:01:49','2026-11-15 09:01:49','cf75a49bf4fbdc950','Contact',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'31d97c49e066562c5','Account'),('d846d5374ceea0de7',0,NULL,'{}','Create',NULL,2,0,0,0,'2026-11-15 09:01:45','2026-11-15 09:01:45','31d97c49e066562c5','Account',NULL,NULL,'2f1e0b7f89ae3c497',NULL,NULL,NULL),('d8f461ccd26247b6b',0,NULL,'{\"assignedUserId\":\"ee34b5ae997ac8935\",\"assignedUserName\":\"Максим Сидоров\",\"statusValue\":\"Pending\",\"statusField\":\"status\"}','Create',NULL,44,0,0,0,'2026-11-15 09:01:58','2026-11-15 09:01:58','e5856416d61b70d80','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'05e7f68d108176fc6','Account'),('de79d0fc66b4abf95',0,NULL,'{\"assignedUserId\":\"5345f9133074952bc\",\"assignedUserName\":\"Анна Иванова\",\"statusValue\":\"Pending\",\"statusField\":\"status\"}','Create',NULL,28,0,0,0,'2026-11-15 09:01:54','2026-11-15 09:01:54','a615cdfea165e8422','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'05e7f68d108176fc6','Account'),('df06f4be611971b6a',0,NULL,'{\"assignedUserId\":\"39ce8dc9b1c5e0553\",\"assignedUserName\":\"Марина Козлова\",\"statusValue\":\"Pending\",\"statusField\":\"status\"}','Create',NULL,18,0,0,0,'2026-11-15 09:01:52','2026-11-15 09:01:52','7836722a11c884c82','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'31d97c49e066562c5','Account'),('e43e7ab337365f590',0,NULL,'{}','Create',NULL,14,0,0,0,'2026-11-15 09:01:51','2026-11-15 09:01:51','026aa6805f059dd51','Contact',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'3fdff7c1df3e0d18d','Account'),('f5be6fce928d182e1',0,NULL,'{\"assignedUserId\":\"ee34b5ae997ac8935\",\"assignedUserName\":\"Максим Сидоров\",\"statusValue\":\"Closed\",\"statusField\":\"status\"}','Create',NULL,29,0,0,0,'2026-11-15 09:01:55','2026-11-15 09:01:55','dd4aee2c0aae367df','Case',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'cab96c889d6e86e00','Account'),('fb94389af0036090f',0,NULL,'{}','Create',NULL,15,0,0,0,'2026-11-15 09:01:51','2026-11-15 09:01:51','b6d2ca787bd9318ff','Contact',NULL,NULL,'2f1e0b7f89ae3c497',NULL,'5872ce100493fa929','Account');
/*!40000 ALTER TABLE `note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_portal`
--

DROP TABLE IF EXISTS `note_portal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_portal` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `note_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portal_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NOTE_ID_PORTAL_ID` (`note_id`,`portal_id`),
  KEY `IDX_NOTE_ID` (`note_id`),
  KEY `IDX_PORTAL_ID` (`portal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_portal`
--

LOCK TABLES `note_portal` WRITE;
/*!40000 ALTER TABLE `note_portal` DISABLE KEYS */;
/*!40000 ALTER TABLE `note_portal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_team`
--

DROP TABLE IF EXISTS `note_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_team` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `note_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NOTE_ID_TEAM_ID` (`note_id`,`team_id`),
  KEY `IDX_NOTE_ID` (`note_id`),
  KEY `IDX_TEAM_ID` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_team`
--

LOCK TABLES `note_team` WRITE;
/*!40000 ALTER TABLE `note_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `note_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `note_user`
--

DROP TABLE IF EXISTS `note_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `note_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `note_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NOTE_ID_USER_ID` (`note_id`,`user_id`),
  KEY `IDX_NOTE_ID` (`note_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `note_user`
--

LOCK TABLES `note_user` WRITE;
/*!40000 ALTER TABLE `note_user` DISABLE KEYS */;
INSERT INTO `note_user` VALUES (1,'07cddae7859482a0e','ee34b5ae997ac8935',0),(2,'df06f4be611971b6a','39ce8dc9b1c5e0553',0),(3,'b2685d4a59b7bd21c','5345f9133074952bc',0),(4,'a5d29cf9064e34f8a','ee34b5ae997ac8935',0),(5,'8011c22d9500fe348','39ce8dc9b1c5e0553',0),(6,'561eb15aea25080c5','5345f9133074952bc',0),(7,'614c66096a028864e','ee34b5ae997ac8935',0),(8,'ce8d29d08ee79e2c8','39ce8dc9b1c5e0553',0),(9,'4c92ed7e561dd9b81','5345f9133074952bc',0),(10,'3c1f8cdca9d2571ad','ee34b5ae997ac8935',0),(11,'45808b9a6a6246945','39ce8dc9b1c5e0553',0),(12,'de79d0fc66b4abf95','5345f9133074952bc',0),(13,'f5be6fce928d182e1','ee34b5ae997ac8935',0),(14,'957ab67e283c83238','39ce8dc9b1c5e0553',0),(15,'9f861e45f6baaebb4','5345f9133074952bc',0),(16,'b362e28acebb002b5','ee34b5ae997ac8935',0),(17,'90f1a6e650e6cc7ce','39ce8dc9b1c5e0553',0),(18,'c20bce08ea34bd17a','5345f9133074952bc',0),(19,'95a1ae4bffb2f0fb8','ee34b5ae997ac8935',0),(20,'91701ed77730c3681','39ce8dc9b1c5e0553',0),(21,'40484a5030eae7b56','5345f9133074952bc',0),(22,'8a74d8c196f578cea','ee34b5ae997ac8935',0),(23,'1c21d8ea448ecf298','39ce8dc9b1c5e0553',0),(24,'474f498d604472cb7','5345f9133074952bc',0),(25,'0e60d8ffb32f57c71','ee34b5ae997ac8935',0),(26,'0cd09803c5bdc34a8','39ce8dc9b1c5e0553',0),(27,'4f2345b7de5571b41','5345f9133074952bc',0),(28,'d8f461ccd26247b6b','ee34b5ae997ac8935',0),(29,'9a191522cb0f94bc7','39ce8dc9b1c5e0553',0),(30,'19c3b4ed53fcb6f07','5345f9133074952bc',0);
/*!40000 ALTER TABLE `note_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notification` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `number` bigint unsigned NOT NULL AUTO_INCREMENT,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `read` tinyint NOT NULL DEFAULT '0',
  `email_is_processed` tinyint NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `message` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `action_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_featured` tinyint NOT NULL DEFAULT '0',
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `related_parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_USER` (`user_id`,`number`),
  KEY `IDX_USER_ID_READ_RELATED_PARENT_TYPE` (`user_id`,`deleted`,`read`,`related_parent_type`),
  KEY `IDX_ACTION_ID` (`action_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_RELATED` (`related_id`,`related_type`),
  KEY `IDX_RELATED_PARENT` (`related_parent_id`,`related_parent_type`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification`
--

LOCK TABLES `notification` WRITE;
/*!40000 ALTER TABLE `notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `notification` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `o_auth_access_token`
--

DROP TABLE IF EXISTS `o_auth_access_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `o_auth_access_token` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `expires_at` datetime DEFAULT NULL,
  `scopes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_HASH` (`hash`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_EXPIRES_AT_STATUS` (`expires_at`,`status`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_CLIENT_ID` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `o_auth_access_token`
--

LOCK TABLES `o_auth_access_token` WRITE;
/*!40000 ALTER TABLE `o_auth_access_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `o_auth_access_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `o_auth_account`
--

DROP TABLE IF EXISTS `o_auth_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `o_auth_account` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `access_token` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `refresh_token` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `provider_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_PROVIDER_ID` (`provider_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `o_auth_account`
--

LOCK TABLES `o_auth_account` WRITE;
/*!40000 ALTER TABLE `o_auth_account` DISABLE KEYS */;
/*!40000 ALTER TABLE `o_auth_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `o_auth_authorization_code`
--

DROP TABLE IF EXISTS `o_auth_authorization_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `o_auth_authorization_code` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `redirect_uri` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `expires_at` datetime DEFAULT NULL,
  `scopes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_HASH` (`hash`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_EXPIRES_AT_STATUS` (`expires_at`,`status`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_CLIENT_ID` (`client_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `o_auth_authorization_code`
--

LOCK TABLES `o_auth_authorization_code` WRITE;
/*!40000 ALTER TABLE `o_auth_authorization_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `o_auth_authorization_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `o_auth_client`
--

DROP TABLE IF EXISTS `o_auth_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `o_auth_client` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `client_type` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Confidential',
  `identifier` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `redirect_uris` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `scopes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_IDENTIFIER` (`identifier`),
  KEY `IDX_NAME` (`name`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `o_auth_client`
--

LOCK TABLES `o_auth_client` WRITE;
/*!40000 ALTER TABLE `o_auth_client` DISABLE KEYS */;
/*!40000 ALTER TABLE `o_auth_client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `o_auth_client_secret`
--

DROP TABLE IF EXISTS `o_auth_client_secret`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `o_auth_client_secret` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `hash` tinytext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `expiration_date` date DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `client_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_STATUS_EXPIRATION_DATE` (`status`,`expiration_date`),
  KEY `IDX_CLIENT_ID_STATUS_CREATED_AT` (`client_id`,`status`,`created_at`),
  KEY `IDX_CLIENT_ID` (`client_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `o_auth_client_secret`
--

LOCK TABLES `o_auth_client_secret` WRITE;
/*!40000 ALTER TABLE `o_auth_client_secret` DISABLE KEYS */;
/*!40000 ALTER TABLE `o_auth_client_secret` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `o_auth_provider`
--

DROP TABLE IF EXISTS `o_auth_provider`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `o_auth_provider` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `is_active` tinyint NOT NULL DEFAULT '1',
  `client_id` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_secret` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `authorization_endpoint` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `token_endpoint` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `authorization_prompt` varchar(14) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'none',
  `authorization_pkce` tinyint NOT NULL DEFAULT '0',
  `scopes` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `authorization_params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `scope_separator` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `o_auth_provider`
--

LOCK TABLES `o_auth_provider` WRITE;
/*!40000 ALTER TABLE `o_auth_provider` DISABLE KEYS */;
/*!40000 ALTER TABLE `o_auth_provider` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `o_auth_refresh_token`
--

DROP TABLE IF EXISTS `o_auth_refresh_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `o_auth_refresh_token` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `hash` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `expires_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_token_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_HASH` (`hash`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_EXPIRES_AT_STATUS` (`expires_at`,`status`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_CLIENT_ID` (`client_id`),
  KEY `IDX_ACCESS_TOKEN_ID` (`access_token_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `o_auth_refresh_token`
--

LOCK TABLES `o_auth_refresh_token` WRITE;
/*!40000 ALTER TABLE `o_auth_refresh_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `o_auth_refresh_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `opportunity`
--

DROP TABLE IF EXISTS `opportunity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `opportunity` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `amount` double DEFAULT NULL,
  `stage` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Prospecting',
  `last_stage` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `probability` int DEFAULT NULL,
  `lead_source` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `close_date` date DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `amount_currency` varchar(3) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `campaign_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_CREATED_AT_ID` (`created_at`,`id`),
  KEY `IDX_STAGE` (`stage`,`deleted`),
  KEY `IDX_LAST_STAGE` (`last_stage`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_CREATED_AT` (`created_at`,`deleted`),
  KEY `IDX_STAGE_CREATED_AT` (`stage`,`created_at`),
  KEY `IDX_ASSIGNED_USER_STAGE` (`assigned_user_id`,`stage`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_CAMPAIGN_ID` (`campaign_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `opportunity`
--

LOCK TABLES `opportunity` WRITE;
/*!40000 ALTER TABLE `opportunity` DISABLE KEYS */;
/*!40000 ALTER TABLE `opportunity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_change_request`
--

DROP TABLE IF EXISTS `password_change_request`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_change_request` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `request_id` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_REQUEST_ID` (`request_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_change_request`
--

LOCK TABLES `password_change_request` WRITE;
/*!40000 ALTER TABLE `password_change_request` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_change_request` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `phone_number`
--

DROP TABLE IF EXISTS `phone_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `phone_number` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `numeric` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invalid` tinyint NOT NULL DEFAULT '0',
  `opt_out` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IDX_NAME` (`name`),
  KEY `IDX_NUMERIC` (`numeric`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `phone_number`
--

LOCK TABLES `phone_number` WRITE;
/*!40000 ALTER TABLE `phone_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `phone_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pipeline`
--

DROP TABLE IF EXISTS `pipeline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pipeline` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `order` int DEFAULT NULL,
  `status` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `color` int DEFAULT NULL,
  `is_available_for_all` tinyint NOT NULL DEFAULT '1',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ENTITY_TYPE_STATUS` (`entity_type`,`status`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pipeline`
--

LOCK TABLES `pipeline` WRITE;
/*!40000 ALTER TABLE `pipeline` DISABLE KEYS */;
/*!40000 ALTER TABLE `pipeline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pipeline_stage`
--

DROP TABLE IF EXISTS `pipeline_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pipeline_stage` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `order` int DEFAULT NULL,
  `mapped_status` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `pipeline_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_PIPELINE_ID` (`pipeline_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pipeline_stage`
--

LOCK TABLES `pipeline_stage` WRITE;
/*!40000 ALTER TABLE `pipeline_stage` DISABLE KEYS */;
/*!40000 ALTER TABLE `pipeline_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal`
--

DROP TABLE IF EXISTS `portal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `custom_id` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `tab_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `quick_create_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `application_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme_params` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `language` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_zone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_format` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_format` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `week_start` int DEFAULT '-1',
  `default_currency` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dashboard_layout` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `dashlets_options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `custom_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_token_lifetime` double DEFAULT NULL,
  `auth_token_max_idle_time` double DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `modified_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `logo_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `company_logo_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `layout_set_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authentication_provider_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CUSTOM_ID` (`custom_id`),
  KEY `IDX_LAYOUT_SET_ID` (`layout_set_id`),
  KEY `IDX_AUTHENTICATION_PROVIDER_ID` (`authentication_provider_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal`
--

LOCK TABLES `portal` WRITE;
/*!40000 ALTER TABLE `portal` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_portal_role`
--

DROP TABLE IF EXISTS `portal_portal_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_portal_role` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `portal_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `portal_role_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_PORTAL_ID_PORTAL_ROLE_ID` (`portal_id`,`portal_role_id`),
  KEY `IDX_PORTAL_ID` (`portal_id`),
  KEY `IDX_PORTAL_ROLE_ID` (`portal_role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_portal_role`
--

LOCK TABLES `portal_portal_role` WRITE;
/*!40000 ALTER TABLE `portal_portal_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_portal_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_role`
--

DROP TABLE IF EXISTS `portal_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_role` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `field_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `export_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `mass_update_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_role`
--

LOCK TABLES `portal_role` WRITE;
/*!40000 ALTER TABLE `portal_role` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_role_user`
--

DROP TABLE IF EXISTS `portal_role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_role_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `portal_role_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_PORTAL_ROLE_ID_USER_ID` (`portal_role_id`,`user_id`),
  KEY `IDX_PORTAL_ROLE_ID` (`portal_role_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_role_user`
--

LOCK TABLES `portal_role_user` WRITE;
/*!40000 ALTER TABLE `portal_role_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `portal_user`
--

DROP TABLE IF EXISTS `portal_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `portal_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `portal_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_PORTAL_ID_USER_ID` (`portal_id`,`user_id`),
  KEY `IDX_PORTAL_ID` (`portal_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `portal_user`
--

LOCK TABLES `portal_user` WRITE;
/*!40000 ALTER TABLE `portal_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `portal_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preferences`
--

DROP TABLE IF EXISTS `preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `preferences` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preferences`
--

LOCK TABLES `preferences` WRITE;
/*!40000 ALTER TABLE `preferences` DISABLE KEYS */;
INSERT INTO `preferences` VALUES ('2f1e0b7f89ae3c497','{\n    \"id\": \"2f1e0b7f89ae3c497\",\n    \"timeZone\": \"Asia\\/Yekaterinburg\",\n    \"dateFormat\": \"DD.MM.YYYY\",\n    \"timeFormat\": \"HH:mm\",\n    \"weekStart\": 1,\n    \"defaultCurrency\": \"RUB\",\n    \"thousandSeparator\": \",\",\n    \"decimalMark\": \".\",\n    \"dashboardLayout\": [\n        {\n            \"name\": \"My Espo\",\n            \"layout\": [\n                {\n                    \"id\": \"default-activities\",\n                    \"name\": \"Activities\",\n                    \"x\": 2,\n                    \"y\": 2,\n                    \"width\": 2,\n                    \"height\": 4\n                },\n                {\n                    \"id\": \"default-stream\",\n                    \"name\": \"Stream\",\n                    \"x\": 0,\n                    \"y\": 0,\n                    \"width\": 2,\n                    \"height\": 4\n                }\n            ]\n        }\n    ],\n    \"dashletsOptions\": {},\n    \"language\": \"ru_RU\",\n    \"exportDelimiter\": \",\",\n    \"receiveAssignmentEmailNotifications\": true,\n    \"receiveMentionEmailNotifications\": true,\n    \"receiveStreamEmailNotifications\": true,\n    \"assignmentNotificationsIgnoreEntityTypeList\": [],\n    \"reactionNotifications\": true,\n    \"reactionNotificationsNotFollowed\": false,\n    \"notificationGrouping\": true,\n    \"notificationSound\": false,\n    \"defaultReminders\": [],\n    \"defaultRemindersTask\": [],\n    \"pageContentWidth\": null,\n    \"recordContentWidth\": null,\n    \"useCustomTabList\": false,\n    \"addCustomTabs\": false,\n    \"emailReplyToAllByDefault\": true,\n    \"emailReplyForceHtml\": true,\n    \"doNotFillAssignedUserIfNotRequired\": true,\n    \"followEntityOnStreamPost\": true,\n    \"followCreatedEntities\": false,\n    \"followCreatedEntityTypeList\": [],\n    \"followAsCollaborator\": true,\n    \"emailUseExternalClient\": false,\n    \"scopeColorsDisabled\": false,\n    \"tabColorsDisabled\": false,\n    \"textSearchStoringDisabled\": false,\n    \"calendarSlotDuration\": null,\n    \"calendarScrollHour\": null\n}');
/*!40000 ALTER TABLE `preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reminder`
--

DROP TABLE IF EXISTS `reminder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reminder` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `remind_at` datetime DEFAULT NULL,
  `start_at` datetime DEFAULT NULL,
  `type` varchar(36) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Popup',
  `seconds` int DEFAULT '0',
  `is_submitted` tinyint NOT NULL DEFAULT '0',
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_REMIND_AT` (`remind_at`),
  KEY `IDX_START_AT` (`start_at`),
  KEY `IDX_TYPE` (`type`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_ENTITY` (`entity_id`,`entity_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reminder`
--

LOCK TABLES `reminder` WRITE;
/*!40000 ALTER TABLE `reminder` DISABLE KEYS */;
/*!40000 ALTER TABLE `reminder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `assignment_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `user_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `message_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `portal_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `group_email_account_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `export_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `mass_update_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `data_privacy_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `follower_management_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `audit_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `mention_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `user_calendar_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `lock_permission` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'not-set',
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `field_data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_team`
--

DROP TABLE IF EXISTS `role_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_team` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `role_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ROLE_ID_TEAM_ID` (`role_id`,`team_id`),
  KEY `IDX_ROLE_ID` (`role_id`),
  KEY `IDX_TEAM_ID` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_team`
--

LOCK TABLES `role_team` WRITE;
/*!40000 ALTER TABLE `role_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_user`
--

DROP TABLE IF EXISTS `role_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `role_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_ROLE_ID_USER_ID` (`role_id`,`user_id`),
  KEY `IDX_ROLE_ID` (`role_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_user`
--

LOCK TABLES `role_user` WRITE;
/*!40000 ALTER TABLE `role_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheduled_job`
--

DROP TABLE IF EXISTS `scheduled_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scheduled_job` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `job` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `scheduling` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_run` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `is_internal` tinyint NOT NULL DEFAULT '0',
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheduled_job`
--

LOCK TABLES `scheduled_job` WRITE;
/*!40000 ALTER TABLE `scheduled_job` DISABLE KEYS */;
INSERT INTO `scheduled_job` VALUES ('0199adc75e4a5b384','Sync Currency Rates',0,'SyncCurrencyRates','Active','2 0 * * *',NULL,'2026-11-15 08:56:59','2026-11-15 08:56:59',1,NULL,NULL),('0b7acb5686d6a8ab6','Check Group Email Accounts',0,'CheckInboundEmails','Active','*/1 * * * *',NULL,'2026-11-15 08:57:00','2026-11-15 08:57:00',0,'system',NULL),('12bc3005413458351','Clean-up',0,'Cleanup','Active','1 1 * * 0',NULL,'2026-11-15 08:57:00','2026-11-15 08:57:00',0,'system',NULL),('21d54ebc3118f06b6','Process Job Group',0,'ProcessJobGroup','Active','* * * * *',NULL,'2026-11-15 08:56:59','2026-11-15 08:56:59',1,NULL,NULL),('31b38e5ba1a9db741','OAuth Server Control',0,'OAuthServerControl','Active','3 0 * * *',NULL,'2026-11-15 08:56:59','2026-11-15 08:56:59',1,NULL,NULL),('38c14103df40c8494','Send Email Reminders',0,'SendEmailReminders','Active','*/2 * * * *','2026-11-15 09:27:42','2026-11-15 08:57:00','2026-11-15 08:57:00',0,'system',NULL),('3991133e504330b53','Check for New Versions of Installed Extensions',0,'CheckNewExtensionVersion','Active','25 5 * * *',NULL,'2026-11-15 08:56:59','2026-11-15 08:56:59',1,NULL,NULL),('4a6a036f21dffd48a','Process Webhook Queue',0,'ProcessWebhookQueue','Active','*/2 * * * *','2026-11-15 09:27:42','2026-11-15 08:57:00','2026-11-15 08:57:00',0,'system',NULL),('5750be1f178c76fe9','Process Job Queue q0',0,'ProcessJobQueueQ0','Active','* * * * *','2026-11-15 09:28:11','2026-11-15 08:56:59','2026-11-15 08:56:59',1,NULL,NULL),('5f75cd3ef25340f25','Process Job Queue e0',0,'ProcessJobQueueE0','Active','* * * * *','2026-11-15 09:28:11','2026-11-15 08:56:59','2026-11-15 08:56:59',1,NULL,NULL),('8413c58638261267b','Send Mass Emails',0,'ProcessMassEmail','Active','10,30,50 * * * *','2026-11-15 09:10:08','2026-11-15 08:57:00','2026-11-15 08:57:00',0,'system',NULL),('84fc0d8a0ff896000','Control Knowledge Base Article Status',0,'ControlKnowledgeBaseArticleStatus','Active','10 1 * * *',NULL,'2026-11-15 08:57:00','2026-11-15 08:57:00',0,'system',NULL),('8acb9d4370891b421','Dummy',0,'Dummy','Active','1 */12 * * *',NULL,'2026-11-15 08:56:59','2026-11-15 08:56:59',1,NULL,NULL),('aae0063f8388741f2','Check for New Version',0,'CheckNewVersion','Active','15 5 * * *',NULL,'2026-11-15 08:56:59','2026-11-15 08:56:59',1,NULL,NULL),('bcd1c259a799fac87','Submit Popup Reminders',0,'SubmitPopupReminders','Active','* * * * *','2026-11-15 09:28:11','2026-11-15 08:56:59','2026-11-15 08:56:59',1,NULL,NULL),('bd8679e7fa94e66e6','Check Personal Email Accounts',0,'CheckEmailAccounts','Active','*/1 * * * *',NULL,'2026-11-15 08:57:00','2026-11-15 08:57:00',0,'system',NULL),('c96bb4400337657cf','Send Scheduled Emails',0,'SendScheduledEmails','Active','*/10 * * * *','2026-11-15 09:20:08','2026-11-15 08:57:00','2026-11-15 08:57:00',0,'system',NULL),('e9d6c9980d694fb42','Send Email Notifications',0,'SendEmailNotifications','Active','*/2 * * * *','2026-11-15 09:27:42','2026-11-15 08:57:00','2026-11-15 08:57:00',0,'system',NULL),('ea1678c7ea92717de','Process Job Queue q1',0,'ProcessJobQueueQ1','Active','*/1 * * * *','2026-11-15 09:27:42','2026-11-15 08:56:59','2026-11-15 08:56:59',1,NULL,NULL),('eeb2498dde7129c23','Auth Token Control',0,'AuthTokenControl','Active','*/6 * * * *','2026-11-15 09:27:42','2026-11-15 08:57:00','2026-11-15 08:57:00',0,'system',NULL);
/*!40000 ALTER TABLE `scheduled_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `scheduled_job_log_record`
--

DROP TABLE IF EXISTS `scheduled_job_log_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `scheduled_job_log_record` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `execution_time` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `scheduled_job_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_SCHEDULED_JOB_ID_EXECUTION_TIME` (`scheduled_job_id`,`execution_time`),
  KEY `IDX_SCHEDULED_JOB_ID` (`scheduled_job_id`),
  KEY `IDX_TARGET` (`target_id`,`target_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `scheduled_job_log_record`
--

LOCK TABLES `scheduled_job_log_record` WRITE;
/*!40000 ALTER TABLE `scheduled_job_log_record` DISABLE KEYS */;
INSERT INTO `scheduled_job_log_record` VALUES ('00bd3934115857978','Submit Popup Reminders',0,'Success','2026-11-15 09:02:51','2026-11-15 09:02:51','bcd1c259a799fac87',NULL,NULL),('00ed53b55312f886a','Submit Popup Reminders',0,'Success','2026-11-15 09:00:31','2026-11-15 09:00:31','bcd1c259a799fac87',NULL,NULL),('01186ca915c707c2d','Process Job Queue q0',0,'Success','2026-11-15 09:18:28','2026-11-15 09:18:28','5750be1f178c76fe9',NULL,NULL),('0135499dddccb1426','Submit Popup Reminders',0,'Success','2026-11-15 09:14:28','2026-11-15 09:14:28','bcd1c259a799fac87',NULL,NULL),('01574a39d61d54a71','Process Job Queue q0',0,'Success','2026-11-15 09:13:38','2026-11-15 09:13:38','5750be1f178c76fe9',NULL,NULL),('017a9980650df9c07','Submit Popup Reminders',0,'Success','2026-11-15 09:13:28','2026-11-15 09:13:28','bcd1c259a799fac87',NULL,NULL),('02fb1f37b74b585c6','Submit Popup Reminders',0,'Success','2026-11-15 09:17:58','2026-11-15 09:17:58','bcd1c259a799fac87',NULL,NULL),('0404ad19f27e695ca','Process Job Queue e0',0,'Success','2026-11-15 09:02:41','2026-11-15 09:02:41','5f75cd3ef25340f25',NULL,NULL),('041c71f260382860c','Submit Popup Reminders',0,'Success','2026-11-15 08:58:01','2026-11-15 08:58:01','bcd1c259a799fac87',NULL,NULL),('046dc0fe325b1b310','Process Job Queue q0',0,'Success','2026-11-15 09:19:48','2026-11-15 09:19:48','5750be1f178c76fe9',NULL,NULL),('047ef6d19e471f382','Submit Popup Reminders',0,'Success','2026-11-15 09:01:31','2026-11-15 09:01:31','bcd1c259a799fac87',NULL,NULL),('056a6d67b5937063d','Send Email Reminders',0,'Success','2026-11-15 09:06:08','2026-11-15 09:06:08','38c14103df40c8494',NULL,NULL),('05dd90b43d52188ac','Send Email Reminders',0,'Success','2026-11-15 09:20:08','2026-11-15 09:20:08','38c14103df40c8494',NULL,NULL),('060ec3e6888f0248c','Process Job Queue e0',0,'Success','2026-11-15 09:08:18','2026-11-15 09:08:18','5f75cd3ef25340f25',NULL,NULL),('061763adf16177a45','Process Job Queue e0',0,'Success','2026-11-15 09:14:08','2026-11-15 09:14:08','5f75cd3ef25340f25',NULL,NULL),('06918e7b0370e141e','Process Job Queue e0',0,'Success','2026-11-15 09:20:48','2026-11-15 09:20:48','5f75cd3ef25340f25',NULL,NULL),('07179d1a0d9dffaa4','Process Job Queue e0',0,'Success','2026-11-15 09:15:58','2026-11-15 09:15:58','5f75cd3ef25340f25',NULL,NULL),('07273e4d39bc02175','Process Job Queue q0',0,'Success','2026-11-15 09:07:58','2026-11-15 09:07:58','5750be1f178c76fe9',NULL,NULL),('075c51590978968b8','Submit Popup Reminders',0,'Success','2026-11-15 09:01:01','2026-11-15 09:01:01','bcd1c259a799fac87',NULL,NULL),('080e4df55fabef715','Process Job Queue e0',0,'Success','2026-11-15 09:14:28','2026-11-15 09:14:28','5f75cd3ef25340f25',NULL,NULL),('087bc49c4d954fd7c','Process Job Queue q0',0,'Success','2026-11-15 09:19:38','2026-11-15 09:19:39','5750be1f178c76fe9',NULL,NULL),('0acd75ad4a3964dea','Process Job Queue e0',0,'Success','2026-11-15 09:19:58','2026-11-15 09:19:58','5f75cd3ef25340f25',NULL,NULL),('0b26d28a9332282ae','Process Job Queue e0',0,'Success','2026-11-15 09:02:11','2026-11-15 09:02:11','5f75cd3ef25340f25',NULL,NULL),('0b451d249ca4a045b','Process Webhook Queue',0,'Success','2026-11-15 09:20:08','2026-11-15 09:20:08','4a6a036f21dffd48a',NULL,NULL),('0ba6b76b7eac107f4','Process Job Queue q0',0,'Success','2026-11-15 09:02:21','2026-11-15 09:02:21','5750be1f178c76fe9',NULL,NULL),('0c26acf5d9e7699fc','Process Job Queue q1',0,'Success','2026-11-15 09:02:01','2026-11-15 09:02:01','ea1678c7ea92717de',NULL,NULL),('0c287184fabd97ba7','Submit Popup Reminders',0,'Success','2026-11-15 09:20:48','2026-11-15 09:20:48','bcd1c259a799fac87',NULL,NULL),('0d197eb2bbd5a1310','Process Job Queue q0',0,'Success','2026-11-15 09:10:58','2026-11-15 09:10:58','5750be1f178c76fe9',NULL,NULL),('0d230e0c7245cff32','Submit Popup Reminders',0,'Success','2026-11-15 08:59:01','2026-11-15 08:59:01','bcd1c259a799fac87',NULL,NULL),('0d9c79ea2d7e4a13a','Process Job Queue e0',0,'Success','2026-11-15 09:15:28','2026-11-15 09:15:28','5f75cd3ef25340f25',NULL,NULL),('0e24d981a30466a4d','Process Job Queue q0',0,'Success','2026-11-15 09:02:41','2026-11-15 09:02:41','5750be1f178c76fe9',NULL,NULL),('0e86ff2e8e26ae99a','Process Job Queue q1',0,'Success','2026-11-15 09:19:08','2026-11-15 09:19:08','ea1678c7ea92717de',NULL,NULL),('0f925db18a99e29ff','Process Job Queue e0',0,'Success','2026-11-15 09:17:48','2026-11-15 09:17:48','5f75cd3ef25340f25',NULL,NULL),('0fa8feb598998c6d1','Submit Popup Reminders',0,'Success','2026-11-15 09:14:48','2026-11-15 09:14:48','bcd1c259a799fac87',NULL,NULL),('0fa90fec45095728e','Submit Popup Reminders',0,'Success','2026-11-15 09:02:11','2026-11-15 09:02:11','bcd1c259a799fac87',NULL,NULL),('101657c7d9e312acf','Submit Popup Reminders',0,'Success','2026-11-15 09:00:11','2026-11-15 09:00:11','bcd1c259a799fac87',NULL,NULL),('10b30b064a0cb5638','Process Job Queue q0',0,'Success','2026-11-15 09:17:28','2026-11-15 09:17:28','5750be1f178c76fe9',NULL,NULL),('10de668e89550bb90','Process Job Queue e0',0,'Success','2026-11-15 09:14:48','2026-11-15 09:14:48','5f75cd3ef25340f25',NULL,NULL),('1107c9fb0fec487ba','Submit Popup Reminders',0,'Success','2026-11-15 09:16:48','2026-11-15 09:16:48','bcd1c259a799fac87',NULL,NULL),('11b76ccd922fe43db','Process Job Queue e0',0,'Success','2026-11-15 09:08:48','2026-11-15 09:08:48','5f75cd3ef25340f25',NULL,NULL),('11d07902f5d529b57','Submit Popup Reminders',0,'Success','2026-11-15 09:09:28','2026-11-15 09:09:28','bcd1c259a799fac87',NULL,NULL),('11f11656ce69fb989','Process Job Queue e0',0,'Success','2026-11-15 09:05:38','2026-11-15 09:05:38','5f75cd3ef25340f25',NULL,NULL),('1238d3d547de65f90','Process Job Queue q1',0,'Success','2026-11-15 09:27:42','2026-11-15 09:27:42','ea1678c7ea92717de',NULL,NULL),('12b2923d5fc67a868','Submit Popup Reminders',0,'Success','2026-11-15 09:12:38','2026-11-15 09:12:38','bcd1c259a799fac87',NULL,NULL),('13222116194b10849','Process Job Queue q0',0,'Success','2026-11-15 09:19:58','2026-11-15 09:19:58','5750be1f178c76fe9',NULL,NULL),('145262b775295f08f','Auth Token Control',0,'Success','2026-11-15 09:06:08','2026-11-15 09:06:08','eeb2498dde7129c23',NULL,NULL),('14b46ad9fe8f9809f','Process Job Queue q1',0,'Success','2026-11-15 08:58:01','2026-11-15 08:58:01','ea1678c7ea92717de',NULL,NULL),('14b67fc2f9056254f','Process Job Queue q0',0,'Success','2026-11-15 09:10:28','2026-11-15 09:10:28','5750be1f178c76fe9',NULL,NULL),('14f9758a991bb7ae1','Process Job Queue q0',0,'Success','2026-11-15 09:09:38','2026-11-15 09:09:38','5750be1f178c76fe9',NULL,NULL),('1564bab90aa8c505a','Process Job Queue e0',0,'Success','2026-11-15 09:16:08','2026-11-15 09:16:08','5f75cd3ef25340f25',NULL,NULL),('1564f3fee0fa137fa','Process Job Queue e0',0,'Success','2026-11-15 09:07:08','2026-11-15 09:07:08','5f75cd3ef25340f25',NULL,NULL),('1614ad44f502ade4a','Process Job Queue e0',0,'Success','2026-11-15 09:05:58','2026-11-15 09:05:58','5f75cd3ef25340f25',NULL,NULL),('16f3a8255c0f01a33','Process Job Queue e0',0,'Success','2026-11-15 09:03:21','2026-11-15 09:03:21','5f75cd3ef25340f25',NULL,NULL),('17b96bd086d1a73bc','Process Job Queue e0',0,'Success','2026-11-15 08:57:31','2026-11-15 08:57:31','5f75cd3ef25340f25',NULL,NULL),('17d3a9ac199d9306a','Send Email Reminders',0,'Success','2026-11-15 08:58:01','2026-11-15 08:58:01','38c14103df40c8494',NULL,NULL),('17f2733b8835f1d8f','Process Job Queue q0',0,'Success','2026-11-15 09:09:58','2026-11-15 09:09:58','5750be1f178c76fe9',NULL,NULL),('18a777b76c79b0114','Submit Popup Reminders',0,'Success','2026-11-15 09:14:08','2026-11-15 09:14:08','bcd1c259a799fac87',NULL,NULL),('18da053f68977f0d3','Process Job Queue q0',0,'Success','2026-11-15 08:58:21','2026-11-15 08:58:21','5750be1f178c76fe9',NULL,NULL),('190164669a8ffdeaa','Process Webhook Queue',0,'Success','2026-11-15 09:04:01','2026-11-15 09:04:01','4a6a036f21dffd48a',NULL,NULL),('19a45953c03efa046','Process Job Queue e0',0,'Success','2026-11-15 09:18:28','2026-11-15 09:18:28','5f75cd3ef25340f25',NULL,NULL),('1ab751364b6156068','Submit Popup Reminders',0,'Success','2026-11-15 09:15:28','2026-11-15 09:15:28','bcd1c259a799fac87',NULL,NULL),('1ad0b94edd2a75e0c','Submit Popup Reminders',0,'Success','2026-11-15 09:02:41','2026-11-15 09:02:41','bcd1c259a799fac87',NULL,NULL),('1b81f55bafb37312f','Process Job Queue e0',0,'Success','2026-11-15 09:19:28','2026-11-15 09:19:28','5f75cd3ef25340f25',NULL,NULL),('1b9a77f60808d0d63','Submit Popup Reminders',0,'Success','2026-11-15 09:07:48','2026-11-15 09:07:48','bcd1c259a799fac87',NULL,NULL),('1b9ae3c515a1291c2','Submit Popup Reminders',0,'Success','2026-11-15 09:19:38','2026-11-15 09:19:39','bcd1c259a799fac87',NULL,NULL),('1be326cc9aea232ee','Process Job Queue e0',0,'Success','2026-11-15 08:58:41','2026-11-15 08:58:41','5f75cd3ef25340f25',NULL,NULL),('1c179732f2bff9a6b','Send Email Notifications',0,'Success','2026-11-15 09:18:08','2026-11-15 09:18:08','e9d6c9980d694fb42',NULL,NULL),('1c22719d753c726bb','Send Email Reminders',0,'Success','2026-11-15 09:10:08','2026-11-15 09:10:08','38c14103df40c8494',NULL,NULL),('1c696d99a3580102e','Process Job Queue e0',0,'Success','2026-11-15 08:57:51','2026-11-15 08:57:51','5f75cd3ef25340f25',NULL,NULL),('1d408ad820551bc91','Submit Popup Reminders',0,'Success','2026-11-15 09:20:18','2026-11-15 09:20:18','bcd1c259a799fac87',NULL,NULL),('1e7f8acc2854fd891','Submit Popup Reminders',0,'Success','2026-11-15 09:06:58','2026-11-15 09:06:58','bcd1c259a799fac87',NULL,NULL),('1e96a15973ac5a65d','Process Job Queue e0',0,'Success','2026-11-15 09:28:01','2026-11-15 09:28:01','5f75cd3ef25340f25',NULL,NULL),('1ef2c6ac786bb518c','Process Job Queue q0',0,'Success','2026-11-15 08:57:51','2026-11-15 08:57:51','5750be1f178c76fe9',NULL,NULL),('1f89871d815d29fa5','Submit Popup Reminders',0,'Success','2026-11-15 09:19:58','2026-11-15 09:19:58','bcd1c259a799fac87',NULL,NULL),('203529dd22bf0eedf','Process Job Queue q0',0,'Success','2026-11-15 09:02:01','2026-11-15 09:02:01','5750be1f178c76fe9',NULL,NULL),('2051aca4551d47ced','Submit Popup Reminders',0,'Success','2026-11-15 09:13:08','2026-11-15 09:13:08','bcd1c259a799fac87',NULL,NULL),('21f915e63db12f542','Process Job Queue e0',0,'Success','2026-11-15 09:08:58','2026-11-15 09:08:58','5f75cd3ef25340f25',NULL,NULL),('2206bf1ee9265938a','Process Job Queue e0',0,'Success','2026-11-15 09:13:58','2026-11-15 09:13:58','5f75cd3ef25340f25',NULL,NULL),('2438270bfc7b62504','Process Job Queue q0',0,'Success','2026-11-15 09:00:11','2026-11-15 09:00:11','5750be1f178c76fe9',NULL,NULL),('2605476cecd32ff9c','Process Job Queue e0',0,'Success','2026-11-15 09:11:18','2026-11-15 09:11:18','5f75cd3ef25340f25',NULL,NULL),('2782ffc097a15c7d3','Process Job Queue q0',0,'Success','2026-11-15 09:01:21','2026-11-15 09:01:21','5750be1f178c76fe9',NULL,NULL),('27baa41e523959040','Process Job Queue e0',0,'Success','2026-11-15 09:00:41','2026-11-15 09:00:41','5f75cd3ef25340f25',NULL,NULL),('28376f1835d426bd6','Process Job Queue q0',0,'Success','2026-11-15 08:58:11','2026-11-15 08:58:11','5750be1f178c76fe9',NULL,NULL),('28b7b8612b9e302f6','Process Job Queue q0',0,'Success','2026-11-15 09:27:42','2026-11-15 09:27:42','5750be1f178c76fe9',NULL,NULL),('2a634221868e5562b','Submit Popup Reminders',0,'Success','2026-11-15 09:07:18','2026-11-15 09:07:18','bcd1c259a799fac87',NULL,NULL),('2a9dbab95c46336d4','Process Job Queue q0',0,'Success','2026-11-15 09:13:08','2026-11-15 09:13:08','5750be1f178c76fe9',NULL,NULL),('2b43e71fc889ed974','Process Job Queue q0',0,'Success','2026-11-15 09:17:18','2026-11-15 09:17:18','5750be1f178c76fe9',NULL,NULL),('2b7a700606ec362ff','Process Job Queue e0',0,'Success','2026-11-15 09:06:58','2026-11-15 09:06:58','5f75cd3ef25340f25',NULL,NULL),('2b962982bc7c73fea','Submit Popup Reminders',0,'Success','2026-11-15 09:03:51','2026-11-15 09:03:51','bcd1c259a799fac87',NULL,NULL),('2bb7b2c7596dab697','Process Job Queue e0',0,'Success','2026-11-15 09:20:28','2026-11-15 09:20:28','5f75cd3ef25340f25',NULL,NULL),('2c6c2a01d956546a7','Process Job Queue q0',0,'Success','2026-11-15 09:10:18','2026-11-15 09:10:18','5750be1f178c76fe9',NULL,NULL),('2ca10bf63f7db0d43','Submit Popup Reminders',0,'Success','2026-11-15 09:09:48','2026-11-15 09:09:48','bcd1c259a799fac87',NULL,NULL),('2d134dd5e5af280f8','Submit Popup Reminders',0,'Success','2026-11-15 09:00:51','2026-11-15 09:00:51','bcd1c259a799fac87',NULL,NULL),('2d2c22ba81ae409ec','Process Job Queue e0',0,'Success','2026-11-15 08:58:31','2026-11-15 08:58:31','5f75cd3ef25340f25',NULL,NULL),('2dce10a89545c4888','Send Scheduled Emails',0,'Success','2026-11-15 09:00:01','2026-11-15 09:00:01','c96bb4400337657cf',NULL,NULL),('2de70e1aa94e0ade7','Process Job Queue e0',0,'Success','2026-11-15 09:02:51','2026-11-15 09:02:51','5f75cd3ef25340f25',NULL,NULL),('2e5c6f41e159c1478','Process Job Queue q0',0,'Success','2026-11-15 09:07:38','2026-11-15 09:07:38','5750be1f178c76fe9',NULL,NULL),('2e86a4c9011f2afc1','Submit Popup Reminders',0,'Success','2026-11-15 09:03:21','2026-11-15 09:03:21','bcd1c259a799fac87',NULL,NULL),('2ec0cc4107d19fa8d','Process Job Queue q0',0,'Success','2026-11-15 09:12:38','2026-11-15 09:12:38','5750be1f178c76fe9',NULL,NULL),('2ee10aea31c2dc85a','Auth Token Control',0,'Success','2026-11-15 09:27:42','2026-11-15 09:27:42','eeb2498dde7129c23',NULL,NULL),('2fde870abd095afa1','Process Job Queue q0',0,'Success','2026-11-15 09:00:51','2026-11-15 09:00:51','5750be1f178c76fe9',NULL,NULL),('306f0aaa7b70393ab','Submit Popup Reminders',0,'Success','2026-11-15 09:19:28','2026-11-15 09:19:28','bcd1c259a799fac87',NULL,NULL),('30851afd97428b97f','Submit Popup Reminders',0,'Success','2026-11-15 09:05:38','2026-11-15 09:05:38','bcd1c259a799fac87',NULL,NULL),('31056a90feaa450eb','Process Job Queue q0',0,'Success','2026-11-15 09:14:28','2026-11-15 09:14:28','5750be1f178c76fe9',NULL,NULL),('31f2227c7122a4b2b','Send Email Notifications',0,'Success','2026-11-15 09:04:01','2026-11-15 09:04:01','e9d6c9980d694fb42',NULL,NULL),('323623c87eb370dda','Send Email Reminders',0,'Success','2026-11-15 09:00:01','2026-11-15 09:00:01','38c14103df40c8494',NULL,NULL),('328c24c9cdf75bccf','Process Job Queue e0',0,'Success','2026-11-15 08:59:01','2026-11-15 08:59:01','5f75cd3ef25340f25',NULL,NULL),('33407318add5eba7b','Submit Popup Reminders',0,'Success','2026-11-15 08:57:31','2026-11-15 08:57:31','bcd1c259a799fac87',NULL,NULL),('34c3e11a64cbb47ce','Submit Popup Reminders',0,'Success','2026-11-15 09:01:41','2026-11-15 09:01:41','bcd1c259a799fac87',NULL,NULL),('34fc1e7da932d18e6','Process Job Queue q1',0,'Success','2026-11-15 09:09:08','2026-11-15 09:09:08','ea1678c7ea92717de',NULL,NULL),('359938674c5d6be34','Process Job Queue q1',0,'Success','2026-11-15 09:07:08','2026-11-15 09:07:08','ea1678c7ea92717de',NULL,NULL),('36263c18c1d70416d','Send Email Reminders',0,'Success','2026-11-15 09:02:01','2026-11-15 09:02:01','38c14103df40c8494',NULL,NULL),('3627993e7af897132','Submit Popup Reminders',0,'Success','2026-11-15 09:13:48','2026-11-15 09:13:48','bcd1c259a799fac87',NULL,NULL),('386f2903ea9dbaba3','Process Job Queue q0',0,'Success','2026-11-15 09:13:58','2026-11-15 09:13:58','5750be1f178c76fe9',NULL,NULL),('394e7cdb6d673a930','Process Job Queue q0',0,'Success','2026-11-15 09:01:11','2026-11-15 09:01:11','5750be1f178c76fe9',NULL,NULL),('3956bdda3212d0d07','Process Job Queue q0',0,'Success','2026-11-15 09:16:48','2026-11-15 09:16:48','5750be1f178c76fe9',NULL,NULL),('3ab394bad9ce440a7','Process Job Queue q0',0,'Success','2026-11-15 09:15:48','2026-11-15 09:15:48','5750be1f178c76fe9',NULL,NULL),('3b19413c1a531cd4a','Process Job Queue q1',0,'Success','2026-11-15 09:15:08','2026-11-15 09:15:08','ea1678c7ea92717de',NULL,NULL),('3b4499dd911ecad91','Process Job Queue q0',0,'Success','2026-11-15 09:10:38','2026-11-15 09:10:38','5750be1f178c76fe9',NULL,NULL),('3b462b3b04c24b1e1','Process Job Queue q0',0,'Success','2026-11-15 09:11:28','2026-11-15 09:11:28','5750be1f178c76fe9',NULL,NULL),('3b4ede547cdcd45c6','Submit Popup Reminders',0,'Success','2026-11-15 09:04:11','2026-11-15 09:04:11','bcd1c259a799fac87',NULL,NULL),('3bd5252aef234ed4b','Process Job Queue e0',0,'Success','2026-11-15 09:11:28','2026-11-15 09:11:28','5f75cd3ef25340f25',NULL,NULL),('3cabcdf3ba3f93acd','Process Job Queue q0',0,'Success','2026-11-15 09:20:28','2026-11-15 09:20:28','5750be1f178c76fe9',NULL,NULL),('3d12036bdf0bf06b6','Submit Popup Reminders',0,'Success','2026-11-15 09:08:48','2026-11-15 09:08:48','bcd1c259a799fac87',NULL,NULL),('3e1df94ea1983e778','Process Job Queue e0',0,'Success','2026-11-15 09:10:48','2026-11-15 09:10:48','5f75cd3ef25340f25',NULL,NULL),('3efe397d6ffb46a24','Process Job Queue q0',0,'Success','2026-11-15 09:12:28','2026-11-15 09:12:28','5750be1f178c76fe9',NULL,NULL),('3f59368aa82e823da','Process Job Queue q0',0,'Success','2026-11-15 09:14:58','2026-11-15 09:14:58','5750be1f178c76fe9',NULL,NULL),('3f72efb87dbb4fac1','Process Job Queue q0',0,'Success','2026-11-15 09:03:51','2026-11-15 09:03:51','5750be1f178c76fe9',NULL,NULL),('3f732c392c690806b','Process Job Queue e0',0,'Success','2026-11-15 09:10:28','2026-11-15 09:10:28','5f75cd3ef25340f25',NULL,NULL),('3ff27a43c0962bf62','Send Email Notifications',0,'Success','2026-11-15 09:27:42','2026-11-15 09:27:42','e9d6c9980d694fb42',NULL,NULL),('428d275de1ee286c8','Submit Popup Reminders',0,'Success','2026-11-15 09:20:38','2026-11-15 09:20:38','bcd1c259a799fac87',NULL,NULL),('432db1012a86679d6','Process Job Queue q1',0,'Success','2026-11-15 09:17:08','2026-11-15 09:17:08','ea1678c7ea92717de',NULL,NULL),('458446493aedaa85f','Process Job Queue e0',0,'Success','2026-11-15 09:20:38','2026-11-15 09:20:38','5f75cd3ef25340f25',NULL,NULL),('45f63c75d58892c9f','Process Job Queue q0',0,'Success','2026-11-15 09:20:18','2026-11-15 09:20:18','5750be1f178c76fe9',NULL,NULL),('46b7e6ff5dcdb4759','Process Job Queue q0',0,'Success','2026-11-15 09:06:08','2026-11-15 09:06:08','5750be1f178c76fe9',NULL,NULL),('47e2bf644c7adb461','Process Job Queue e0',0,'Success','2026-11-15 09:05:48','2026-11-15 09:05:48','5f75cd3ef25340f25',NULL,NULL),('47fb41c6aa886c95c','Submit Popup Reminders',0,'Success','2026-11-15 09:09:38','2026-11-15 09:09:38','bcd1c259a799fac87',NULL,NULL),('492e1598e6c4ea86f','Submit Popup Reminders',0,'Success','2026-11-15 09:17:28','2026-11-15 09:17:28','bcd1c259a799fac87',NULL,NULL),('49e24015bdf392143','Process Job Queue q0',0,'Success','2026-11-15 09:00:01','2026-11-15 09:00:01','5750be1f178c76fe9',NULL,NULL),('4bc83f7fbfc01af4b','Submit Popup Reminders',0,'Success','2026-11-15 09:12:48','2026-11-15 09:12:48','bcd1c259a799fac87',NULL,NULL),('4c62872c0cbc29ffb','Submit Popup Reminders',0,'Success','2026-11-15 09:01:11','2026-11-15 09:01:11','bcd1c259a799fac87',NULL,NULL),('4c65bdf87f9e97fc8','Process Job Queue q0',0,'Success','2026-11-15 09:03:31','2026-11-15 09:03:31','5750be1f178c76fe9',NULL,NULL),('4c93b8eeebd0223f7','Process Job Queue q0',0,'Success','2026-11-15 09:18:38','2026-11-15 09:18:38','5750be1f178c76fe9',NULL,NULL),('4cf310713f06c339e','Submit Popup Reminders',0,'Success','2026-11-15 09:07:08','2026-11-15 09:07:08','bcd1c259a799fac87',NULL,NULL),('4d0aabe9cf34147f3','Process Job Queue e0',0,'Success','2026-11-15 09:16:28','2026-11-15 09:16:28','5f75cd3ef25340f25',NULL,NULL),('4d7cc9b804913c8ac','Process Job Queue q0',0,'Success','2026-11-15 09:07:18','2026-11-15 09:07:18','5750be1f178c76fe9',NULL,NULL),('4dfb5484aea8ff5e8','Process Job Queue q1',0,'Success','2026-11-15 09:12:08','2026-11-15 09:12:08','ea1678c7ea92717de',NULL,NULL),('4e2680d401b8ce2ed','Process Job Queue e0',0,'Success','2026-11-15 09:06:18','2026-11-15 09:06:18','5f75cd3ef25340f25',NULL,NULL),('4e55b9828fc45c647','Process Job Queue e0',0,'Success','2026-11-15 09:19:08','2026-11-15 09:19:08','5f75cd3ef25340f25',NULL,NULL),('50cf8ef9bbad5d4e0','Process Job Queue q0',0,'Success','2026-11-15 09:00:31','2026-11-15 09:00:31','5750be1f178c76fe9',NULL,NULL),('510268c5f34b52fa9','Process Job Queue e0',0,'Success','2026-11-15 09:12:38','2026-11-15 09:12:38','5f75cd3ef25340f25',NULL,NULL),('518592dcb03be2168','Process Job Queue e0',0,'Success','2026-11-15 09:08:08','2026-11-15 09:08:08','5f75cd3ef25340f25',NULL,NULL),('51e14095c6bd53c05','Submit Popup Reminders',0,'Success','2026-11-15 09:07:38','2026-11-15 09:07:38','bcd1c259a799fac87',NULL,NULL),('52ac769fa6f49ff66','Process Job Queue e0',0,'Success','2026-11-15 09:13:18','2026-11-15 09:13:18','5f75cd3ef25340f25',NULL,NULL),('539d50462a8830dbc','Process Job Queue q0',0,'Success','2026-11-15 09:14:48','2026-11-15 09:14:48','5750be1f178c76fe9',NULL,NULL),('54182132aa5f0fa57','Submit Popup Reminders',0,'Success','2026-11-15 09:00:21','2026-11-15 09:00:21','bcd1c259a799fac87',NULL,NULL),('55c6e07590476eac7','Process Job Queue q0',0,'Success','2026-11-15 09:07:08','2026-11-15 09:07:08','5750be1f178c76fe9',NULL,NULL),('575a8148edb1ba917','Submit Popup Reminders',0,'Success','2026-11-15 09:08:58','2026-11-15 09:08:58','bcd1c259a799fac87',NULL,NULL),('57896ee70f8cea7fb','Submit Popup Reminders',0,'Success','2026-11-15 08:59:41','2026-11-15 08:59:41','bcd1c259a799fac87',NULL,NULL),('5799b9cbd0b2d68e3','Process Job Queue e0',0,'Success','2026-11-15 09:16:48','2026-11-15 09:16:48','5f75cd3ef25340f25',NULL,NULL),('57c6cef6806aef454','Process Job Queue q1',0,'Success','2026-11-15 09:18:08','2026-11-15 09:18:08','ea1678c7ea92717de',NULL,NULL),('5831e06bc4357baf8','Submit Popup Reminders',0,'Success','2026-11-15 09:11:18','2026-11-15 09:11:18','bcd1c259a799fac87',NULL,NULL),('587e7bcf537546a82','Process Webhook Queue',0,'Success','2026-11-15 09:00:01','2026-11-15 09:00:01','4a6a036f21dffd48a',NULL,NULL),('58bedefe74f2864b8','Submit Popup Reminders',0,'Success','2026-11-15 09:18:38','2026-11-15 09:18:38','bcd1c259a799fac87',NULL,NULL),('58c835681d45d7193','Process Job Queue e0',0,'Success','2026-11-15 09:15:48','2026-11-15 09:15:48','5f75cd3ef25340f25',NULL,NULL),('58e6ed4494f17b486','Process Job Queue q0',0,'Success','2026-11-15 09:17:58','2026-11-15 09:17:58','5750be1f178c76fe9',NULL,NULL),('593df4687e5149ef5','Process Job Queue e0',0,'Success','2026-11-15 09:20:08','2026-11-15 09:20:08','5f75cd3ef25340f25',NULL,NULL),('595c0f1ed38535860','Submit Popup Reminders',0,'Success','2026-11-15 09:09:08','2026-11-15 09:09:08','bcd1c259a799fac87',NULL,NULL),('595dc1258657bc338','Submit Popup Reminders',0,'Success','2026-11-15 09:03:11','2026-11-15 09:03:11','bcd1c259a799fac87',NULL,NULL),('599f2dd99f217c83d','Process Webhook Queue',0,'Success','2026-11-15 09:12:08','2026-11-15 09:12:08','4a6a036f21dffd48a',NULL,NULL),('59cda184c9c64efd7','Process Job Queue q0',0,'Success','2026-11-15 09:10:08','2026-11-15 09:10:08','5750be1f178c76fe9',NULL,NULL),('5a1e03ea8c5bbda3d','Process Job Queue e0',0,'Success','2026-11-15 09:14:58','2026-11-15 09:14:58','5f75cd3ef25340f25',NULL,NULL),('5a28af58778202506','Process Job Queue q0',0,'Success','2026-11-15 09:14:08','2026-11-15 09:14:08','5750be1f178c76fe9',NULL,NULL),('5a3c0767e2608cdd7','Process Job Queue e0',0,'Success','2026-11-15 09:07:48','2026-11-15 09:07:48','5f75cd3ef25340f25',NULL,NULL),('5a82076355e66f9b9','Submit Popup Reminders',0,'Success','2026-11-15 09:14:18','2026-11-15 09:14:18','bcd1c259a799fac87',NULL,NULL),('5b96ff11119d95d3d','Process Job Queue q0',0,'Success','2026-11-15 09:09:08','2026-11-15 09:09:08','5750be1f178c76fe9',NULL,NULL),('5ba0b1e212f1e4e5b','Process Job Queue q0',0,'Success','2026-11-15 09:18:48','2026-11-15 09:18:48','5750be1f178c76fe9',NULL,NULL),('5be717815dd8a9758','Process Job Queue q0',0,'Success','2026-11-15 09:00:41','2026-11-15 09:00:41','5750be1f178c76fe9',NULL,NULL),('5c54666267ac5d765','Process Job Queue e0',0,'Success','2026-11-15 09:06:38','2026-11-15 09:06:38','5f75cd3ef25340f25',NULL,NULL),('5c5cc6a573e56d990','Process Job Queue e0',0,'Success','2026-11-15 09:20:58','2026-11-15 09:20:58','5f75cd3ef25340f25',NULL,NULL),('5d2c520f1e191a7b2','Process Job Queue q0',0,'Success','2026-11-15 09:16:08','2026-11-15 09:16:08','5750be1f178c76fe9',NULL,NULL),('5d5b456d2e13db2b9','Send Email Notifications',0,'Success','2026-11-15 09:16:08','2026-11-15 09:16:08','e9d6c9980d694fb42',NULL,NULL),('5d71df33c4dfd71f4','Submit Popup Reminders',0,'Success','2026-11-15 09:08:38','2026-11-15 09:08:38','bcd1c259a799fac87',NULL,NULL),('5dcaa140236aaf2a2','Submit Popup Reminders',0,'Success','2026-11-15 09:17:08','2026-11-15 09:17:08','bcd1c259a799fac87',NULL,NULL),('5de6d157caedfca11','Process Job Queue q0',0,'Success','2026-11-15 09:06:28','2026-11-15 09:06:28','5750be1f178c76fe9',NULL,NULL),('5e5099440e51ecca5','Submit Popup Reminders',0,'Success','2026-11-15 09:08:08','2026-11-15 09:08:08','bcd1c259a799fac87',NULL,NULL),('5e584e3ff1a877db0','Process Job Queue e0',0,'Success','2026-11-15 09:07:18','2026-11-15 09:07:18','5f75cd3ef25340f25',NULL,NULL),('5e6f9c4258c48950d','Submit Popup Reminders',0,'Success','2026-11-15 09:01:21','2026-11-15 09:01:21','bcd1c259a799fac87',NULL,NULL),('5f13475710e00da99','Send Scheduled Emails',0,'Success','2026-11-15 09:10:08','2026-11-15 09:10:08','c96bb4400337657cf',NULL,NULL),('5fcaf73dd815a1e38','Submit Popup Reminders',0,'Success','2026-11-15 09:08:28','2026-11-15 09:08:28','bcd1c259a799fac87',NULL,NULL),('605eb525b8c91580f','Process Job Queue q0',0,'Success','2026-11-15 09:06:18','2026-11-15 09:06:18','5750be1f178c76fe9',NULL,NULL),('607694486c341f237','Process Job Queue e0',0,'Success','2026-11-15 09:02:21','2026-11-15 09:02:21','5f75cd3ef25340f25',NULL,NULL),('61004fb76ee4fb19b','Process Job Queue e0',0,'Success','2026-11-15 09:16:18','2026-11-15 09:16:18','5f75cd3ef25340f25',NULL,NULL),('611acb279c4988e32','Process Job Queue e0',0,'Success','2026-11-15 09:12:08','2026-11-15 09:12:08','5f75cd3ef25340f25',NULL,NULL),('614d91d809af0498d','Process Job Queue q0',0,'Success','2026-11-15 09:11:58','2026-11-15 09:11:58','5750be1f178c76fe9',NULL,NULL),('619287cf11e638843','Process Job Queue q0',0,'Success','2026-11-15 09:18:18','2026-11-15 09:18:18','5750be1f178c76fe9',NULL,NULL),('61fa20dad0cc8bce7','Process Job Queue q1',0,'Success','2026-11-15 09:01:01','2026-11-15 09:01:01','ea1678c7ea92717de',NULL,NULL),('6229c5319e2c12c35','Process Job Queue e0',0,'Success','2026-11-15 08:57:41','2026-11-15 08:57:41','5f75cd3ef25340f25',NULL,NULL),('6285bc975db31ee3b','Process Job Queue e0',0,'Success','2026-11-15 09:13:48','2026-11-15 09:13:48','5f75cd3ef25340f25',NULL,NULL),('62970265085bab1a8','Auth Token Control',0,'Success','2026-11-15 09:12:08','2026-11-15 09:12:08','eeb2498dde7129c23',NULL,NULL),('62b93ffd1d6b0ad84','Send Email Notifications',0,'Success','2026-11-15 08:58:01','2026-11-15 08:58:01','e9d6c9980d694fb42',NULL,NULL),('64e3a68d97ac10205','Submit Popup Reminders',0,'Success','2026-11-15 09:13:18','2026-11-15 09:13:18','bcd1c259a799fac87',NULL,NULL),('6551b73c28f365f90','Submit Popup Reminders',0,'Success','2026-11-15 09:12:18','2026-11-15 09:12:18','bcd1c259a799fac87',NULL,NULL),('65df58d762231aa58','Submit Popup Reminders',0,'Success','2026-11-15 09:18:08','2026-11-15 09:18:08','bcd1c259a799fac87',NULL,NULL),('662197bc36a33e068','Submit Popup Reminders',0,'Success','2026-11-15 09:16:08','2026-11-15 09:16:08','bcd1c259a799fac87',NULL,NULL),('662b2c683e13337d7','Process Job Queue q0',0,'Success','2026-11-15 09:05:28','2026-11-15 09:05:28','5750be1f178c76fe9',NULL,NULL),('6664837ed31fe0e93','Process Webhook Queue',0,'Success','2026-11-15 09:10:08','2026-11-15 09:10:08','4a6a036f21dffd48a',NULL,NULL),('66e759bd9a7c66d49','Submit Popup Reminders',0,'Success','2026-11-15 09:10:48','2026-11-15 09:10:48','bcd1c259a799fac87',NULL,NULL),('67d85689c044c87fb','Auth Token Control',0,'Success','2026-11-15 09:18:08','2026-11-15 09:18:08','eeb2498dde7129c23',NULL,NULL),('67e3aefa31fb24d1b','Submit Popup Reminders',0,'Success','2026-11-15 09:03:41','2026-11-15 09:03:41','bcd1c259a799fac87',NULL,NULL),('68260c67176ca207e','Process Webhook Queue',0,'Success','2026-11-15 09:08:08','2026-11-15 09:08:08','4a6a036f21dffd48a',NULL,NULL),('68e6630a0666c3178','Process Job Queue q0',0,'Success','2026-11-15 09:03:41','2026-11-15 09:03:41','5750be1f178c76fe9',NULL,NULL),('692a44ea4f930b5c7','Submit Popup Reminders',0,'Success','2026-11-15 09:06:38','2026-11-15 09:06:38','bcd1c259a799fac87',NULL,NULL),('69dede7697403e038','Process Job Queue q0',0,'Success','2026-11-15 08:58:01','2026-11-15 08:58:01','5750be1f178c76fe9',NULL,NULL),('69ea8658464caf92d','Process Job Queue q0',0,'Success','2026-11-15 09:17:48','2026-11-15 09:17:48','5750be1f178c76fe9',NULL,NULL),('6a7bc07013740f35b','Submit Popup Reminders',0,'Success','2026-11-15 08:59:51','2026-11-15 08:59:51','bcd1c259a799fac87',NULL,NULL),('6ae0e9139284fb0e6','Process Job Queue q0',0,'Success','2026-11-15 09:09:28','2026-11-15 09:09:28','5750be1f178c76fe9',NULL,NULL),('6c1c57051f2f8ea71','Process Job Queue q0',0,'Success','2026-11-15 08:59:31','2026-11-15 08:59:31','5750be1f178c76fe9',NULL,NULL),('6c339c4332936924e','Process Job Queue q0',0,'Success','2026-11-15 09:06:58','2026-11-15 09:06:58','5750be1f178c76fe9',NULL,NULL),('6c4f07fc67b9b69b1','Process Job Queue e0',0,'Success','2026-11-15 09:18:18','2026-11-15 09:18:18','5f75cd3ef25340f25',NULL,NULL),('6cd921c1fca96cfc9','Process Job Queue q0',0,'Success','2026-11-15 09:10:48','2026-11-15 09:10:48','5750be1f178c76fe9',NULL,NULL),('6d0b6421fb2e14ee3','Process Job Queue e0',0,'Success','2026-11-15 09:07:58','2026-11-15 09:07:58','5f75cd3ef25340f25',NULL,NULL),('6d49aa61ea52498cb','Process Job Queue e0',0,'Success','2026-11-15 09:18:08','2026-11-15 09:18:08','5f75cd3ef25340f25',NULL,NULL),('6e7c0d4608cd6ff1c','Process Job Queue q0',0,'Success','2026-11-15 09:20:58','2026-11-15 09:20:58','5750be1f178c76fe9',NULL,NULL),('6e8927ccff4840a7a','Process Job Queue e0',0,'Success','2026-11-15 09:08:38','2026-11-15 09:08:38','5f75cd3ef25340f25',NULL,NULL),('6f2586783cfebfe00','Process Job Queue q1',0,'Success','2026-11-15 09:16:08','2026-11-15 09:16:08','ea1678c7ea92717de',NULL,NULL),('704d0c46a279d80a1','Process Job Queue e0',0,'Success','2026-11-15 09:14:38','2026-11-15 09:14:38','5f75cd3ef25340f25',NULL,NULL),('70f381d22b08e333c','Submit Popup Reminders',0,'Success','2026-11-15 09:11:58','2026-11-15 09:11:58','bcd1c259a799fac87',NULL,NULL),('71769f8cb07cd0ab2','Send Email Reminders',0,'Success','2026-11-15 09:08:08','2026-11-15 09:08:08','38c14103df40c8494',NULL,NULL),('71c913d6752d4b4db','Send Email Reminders',0,'Success','2026-11-15 09:27:42','2026-11-15 09:27:42','38c14103df40c8494',NULL,NULL),('72aed974474befc59','Submit Popup Reminders',0,'Success','2026-11-15 09:09:18','2026-11-15 09:09:18','bcd1c259a799fac87',NULL,NULL),('72d61b4c17b52530f','Process Job Queue e0',0,'Success','2026-11-15 09:11:48','2026-11-15 09:11:48','5f75cd3ef25340f25',NULL,NULL),('7427d225e73116685','Send Email Reminders',0,'Success','2026-11-15 09:12:08','2026-11-15 09:12:08','38c14103df40c8494',NULL,NULL),('746d56c049fbf0338','Submit Popup Reminders',0,'Success','2026-11-15 09:06:48','2026-11-15 09:06:48','bcd1c259a799fac87',NULL,NULL),('74738d4fb5ff22c9c','Submit Popup Reminders',0,'Success','2026-11-15 08:57:21','2026-11-15 08:57:21','bcd1c259a799fac87',NULL,NULL),('754c7241e0d8d3f75','Process Job Queue e0',0,'Success','2026-11-15 09:01:21','2026-11-15 09:01:21','5f75cd3ef25340f25',NULL,NULL),('7573a87d088fb9ace','Process Job Queue q0',0,'Success','2026-11-15 09:11:18','2026-11-15 09:11:18','5750be1f178c76fe9',NULL,NULL),('758471678ce7f26bb','Process Webhook Queue',0,'Success','2026-11-15 09:27:42','2026-11-15 09:27:42','4a6a036f21dffd48a',NULL,NULL),('765f6b720c8399256','Process Job Queue e0',0,'Success','2026-11-15 09:18:58','2026-11-15 09:18:58','5f75cd3ef25340f25',NULL,NULL),('773fac5e27d27be05','Process Job Queue q0',0,'Success','2026-11-15 09:12:08','2026-11-15 09:12:08','5750be1f178c76fe9',NULL,NULL),('7821c9e16ca4e46b0','Process Job Queue q0',0,'Success','2026-11-15 08:57:21','2026-11-15 08:57:21','5750be1f178c76fe9',NULL,NULL),('7985786d717b09983','Send Scheduled Emails',0,'Success','2026-11-15 09:20:08','2026-11-15 09:20:08','c96bb4400337657cf',NULL,NULL),('7989f8b5d38422196','Submit Popup Reminders',0,'Success','2026-11-15 09:05:28','2026-11-15 09:05:28','bcd1c259a799fac87',NULL,NULL),('799646e2f8f54bbf0','Process Job Queue e0',0,'Success','2026-11-15 09:12:18','2026-11-15 09:12:18','5f75cd3ef25340f25',NULL,NULL),('79a6742598fdd3fa8','Process Job Queue q0',0,'Success','2026-11-15 09:16:28','2026-11-15 09:16:28','5750be1f178c76fe9',NULL,NULL),('79b9b0ccc3a222417','Process Job Queue q0',0,'Success','2026-11-15 09:02:11','2026-11-15 09:02:11','5750be1f178c76fe9',NULL,NULL),('7a60d147007b7ba8a','Process Job Queue e0',0,'Success','2026-11-15 09:03:51','2026-11-15 09:03:51','5f75cd3ef25340f25',NULL,NULL),('7aea49ae420a03ecd','Submit Popup Reminders',0,'Success','2026-11-15 09:27:51','2026-11-15 09:27:52','bcd1c259a799fac87',NULL,NULL),('7b95d4fca0344e680','Submit Popup Reminders',0,'Success','2026-11-15 09:06:28','2026-11-15 09:06:28','bcd1c259a799fac87',NULL,NULL),('7ca005b50625155c5','Process Job Queue e0',0,'Success','2026-11-15 09:03:41','2026-11-15 09:03:41','5f75cd3ef25340f25',NULL,NULL),('7cb6d7011f5d29722','Process Job Queue q0',0,'Success','2026-11-15 09:03:21','2026-11-15 09:03:21','5750be1f178c76fe9',NULL,NULL),('7e9f97ef2bb9c2870','Process Job Queue q0',0,'Success','2026-11-15 09:16:38','2026-11-15 09:16:38','5750be1f178c76fe9',NULL,NULL),('7f95a9d207bab55c1','Process Webhook Queue',0,'Success','2026-11-15 08:58:01','2026-11-15 08:58:01','4a6a036f21dffd48a',NULL,NULL),('7fa79a4fbcbb27a3c','Submit Popup Reminders',0,'Success','2026-11-15 09:10:58','2026-11-15 09:10:58','bcd1c259a799fac87',NULL,NULL),('8050e4c12873e933e','Submit Popup Reminders',0,'Success','2026-11-15 09:16:18','2026-11-15 09:16:18','bcd1c259a799fac87',NULL,NULL),('80cc74b4c20273e03','Submit Popup Reminders',0,'Success','2026-11-15 09:11:38','2026-11-15 09:11:38','bcd1c259a799fac87',NULL,NULL),('80d9d9a0683a45f7b','Submit Popup Reminders',0,'Success','2026-11-15 09:04:01','2026-11-15 09:04:01','bcd1c259a799fac87',NULL,NULL),('811a50add9e19bd78','Process Job Queue e0',0,'Success','2026-11-15 08:59:11','2026-11-15 08:59:11','5f75cd3ef25340f25',NULL,NULL),('81612cc59a1873950','Process Job Queue q1',0,'Success','2026-11-15 09:14:08','2026-11-15 09:14:08','ea1678c7ea92717de',NULL,NULL),('8309b2b02f0cae20b','Process Job Queue e0',0,'Success','2026-11-15 09:17:18','2026-11-15 09:17:18','5f75cd3ef25340f25',NULL,NULL),('83724ade786719680','Submit Popup Reminders',0,'Success','2026-11-15 09:17:38','2026-11-15 09:17:38','bcd1c259a799fac87',NULL,NULL),('83a105489a02b30f5','Process Job Queue e0',0,'Success','2026-11-15 09:00:31','2026-11-15 09:00:31','5f75cd3ef25340f25',NULL,NULL),('83b2bf8eb8b4509e6','Process Job Queue q0',0,'Success','2026-11-15 09:06:48','2026-11-15 09:06:48','5750be1f178c76fe9',NULL,NULL),('84a4861884ea02a06','Send Email Notifications',0,'Success','2026-11-15 09:12:08','2026-11-15 09:12:08','e9d6c9980d694fb42',NULL,NULL),('85eb745492cb74f6c','Process Job Queue e0',0,'Success','2026-11-15 08:58:21','2026-11-15 08:58:21','5f75cd3ef25340f25',NULL,NULL),('8645c2247be0aa17b','Process Job Queue q0',0,'Success','2026-11-15 09:17:08','2026-11-15 09:17:08','5750be1f178c76fe9',NULL,NULL),('86faf735d3a61a1b6','Process Job Queue e0',0,'Success','2026-11-15 09:10:08','2026-11-15 09:10:08','5f75cd3ef25340f25',NULL,NULL),('87231afff279a4392','Submit Popup Reminders',0,'Success','2026-11-15 09:14:58','2026-11-15 09:14:58','bcd1c259a799fac87',NULL,NULL),('8728e8aad82cb1cdc','Process Job Queue q0',0,'Success','2026-11-15 09:12:48','2026-11-15 09:12:48','5750be1f178c76fe9',NULL,NULL),('877d5e510a9560ade','Process Job Queue e0',0,'Success','2026-11-15 08:58:11','2026-11-15 08:58:11','5f75cd3ef25340f25',NULL,NULL),('87911db36518569a6','Process Job Queue e0',0,'Success','2026-11-15 09:09:38','2026-11-15 09:09:38','5f75cd3ef25340f25',NULL,NULL),('8862e67129720d476','Process Job Queue e0',0,'Success','2026-11-15 08:57:21','2026-11-15 08:57:21','5f75cd3ef25340f25',NULL,NULL),('88a63afa9c1da5d8d','Submit Popup Reminders',0,'Success','2026-11-15 08:58:11','2026-11-15 08:58:11','bcd1c259a799fac87',NULL,NULL),('89ca48486c7c71de8','Process Job Queue q0',0,'Success','2026-11-15 09:20:38','2026-11-15 09:20:38','5750be1f178c76fe9',NULL,NULL),('8a1b40ddabde451de','Process Job Queue e0',0,'Success','2026-11-15 09:00:11','2026-11-15 09:00:11','5f75cd3ef25340f25',NULL,NULL),('8a692deee88cbf160','Process Job Queue q1',0,'Success','2026-11-15 09:13:08','2026-11-15 09:13:08','ea1678c7ea92717de',NULL,NULL),('8ad889260ddd96fcc','Process Job Queue e0',0,'Success','2026-11-15 09:06:48','2026-11-15 09:06:48','5f75cd3ef25340f25',NULL,NULL),('8af96cca67a5d79d2','Process Job Queue e0',0,'Success','2026-11-15 08:59:21','2026-11-15 08:59:21','5f75cd3ef25340f25',NULL,NULL),('8b189172174e48acd','Process Job Queue q0',0,'Success','2026-11-15 09:11:38','2026-11-15 09:11:38','5750be1f178c76fe9',NULL,NULL),('8b87148e20548cb2c','Process Job Queue e0',0,'Success','2026-11-15 09:19:48','2026-11-15 09:19:48','5f75cd3ef25340f25',NULL,NULL),('8bc67d249512056f1','Process Job Queue e0',0,'Success','2026-11-15 09:02:01','2026-11-15 09:02:01','5f75cd3ef25340f25',NULL,NULL),('8bedfa031c2f972aa','Process Job Queue q0',0,'Success','2026-11-15 08:59:41','2026-11-15 08:59:41','5750be1f178c76fe9',NULL,NULL),('8d9e03d644869d5a3','Process Job Queue q0',0,'Success','2026-11-15 09:15:38','2026-11-15 09:15:38','5750be1f178c76fe9',NULL,NULL),('8ec603cca73735653','Process Job Queue e0',0,'Success','2026-11-15 09:19:18','2026-11-15 09:19:18','5f75cd3ef25340f25',NULL,NULL),('902c05c093de3c6a1','Process Job Queue q0',0,'Success','2026-11-15 09:28:11','2026-11-15 09:28:11','5750be1f178c76fe9',NULL,NULL),('91963f44e8351502f','Process Job Queue e0',0,'Success','2026-11-15 09:19:38','2026-11-15 09:19:39','5f75cd3ef25340f25',NULL,NULL),('91a86740fbbdb9028','Process Job Queue e0',0,'Success','2026-11-15 09:28:11','2026-11-15 09:28:11','5f75cd3ef25340f25',NULL,NULL),('92050d86c1deaf02f','Process Job Queue q0',0,'Success','2026-11-15 09:01:51','2026-11-15 09:01:51','5750be1f178c76fe9',NULL,NULL),('9220f125de2b59f84','Process Job Queue q0',0,'Success','2026-11-15 09:01:01','2026-11-15 09:01:01','5750be1f178c76fe9',NULL,NULL),('92859eb56904c850c','Process Job Queue q1',0,'Success','2026-11-15 09:04:01','2026-11-15 09:04:01','ea1678c7ea92717de',NULL,NULL),('93019a85386d200c7','Process Job Queue q0',0,'Success','2026-11-15 09:15:08','2026-11-15 09:15:08','5750be1f178c76fe9',NULL,NULL),('93ad19d83cfc9057d','Process Job Queue q0',0,'Success','2026-11-15 09:12:58','2026-11-15 09:12:58','5750be1f178c76fe9',NULL,NULL),('94cb54696d324bcb0','Submit Popup Reminders',0,'Success','2026-11-15 09:07:58','2026-11-15 09:07:58','bcd1c259a799fac87',NULL,NULL),('9521c7ca3091e015e','Process Job Queue e0',0,'Success','2026-11-15 09:09:08','2026-11-15 09:09:08','5f75cd3ef25340f25',NULL,NULL),('959e9d4bee41ad9dd','Process Job Queue e0',0,'Success','2026-11-15 09:01:11','2026-11-15 09:01:11','5f75cd3ef25340f25',NULL,NULL),('95c8b6e13280f247d','Submit Popup Reminders',0,'Success','2026-11-15 09:15:58','2026-11-15 09:15:58','bcd1c259a799fac87',NULL,NULL),('96db5335cc60868f7','Process Job Queue q0',0,'Success','2026-11-15 09:18:08','2026-11-15 09:18:08','5750be1f178c76fe9',NULL,NULL),('96feada8e3d32b1b0','Process Job Queue q1',0,'Success','2026-11-15 08:59:01','2026-11-15 08:59:01','ea1678c7ea92717de',NULL,NULL),('98a78a0aad540ac80','Process Job Queue q0',0,'Success','2026-11-15 09:07:48','2026-11-15 09:07:48','5750be1f178c76fe9',NULL,NULL),('98b688a8002e1d2c0','Submit Popup Reminders',0,'Success','2026-11-15 09:12:28','2026-11-15 09:12:28','bcd1c259a799fac87',NULL,NULL),('99411726d80ee38fe','Process Job Queue q0',0,'Success','2026-11-15 09:08:18','2026-11-15 09:08:18','5750be1f178c76fe9',NULL,NULL),('99c97a245dcf26712','Submit Popup Reminders',0,'Success','2026-11-15 09:14:38','2026-11-15 09:14:38','bcd1c259a799fac87',NULL,NULL),('99d1928cc6995ea54','Process Job Queue q1',0,'Success','2026-11-15 09:20:08','2026-11-15 09:20:08','ea1678c7ea92717de',NULL,NULL),('9afd4bf139168d00d','Process Job Queue q0',0,'Success','2026-11-15 09:00:21','2026-11-15 09:00:21','5750be1f178c76fe9',NULL,NULL),('9b907aaf5bcc50aa4','Process Job Queue e0',0,'Success','2026-11-15 09:02:31','2026-11-15 09:02:31','5f75cd3ef25340f25',NULL,NULL),('9bc6e2fcbe4b74cc7','Process Job Queue q0',0,'Success','2026-11-15 09:20:08','2026-11-15 09:20:08','5750be1f178c76fe9',NULL,NULL),('9be90048822a00081','Process Job Queue q0',0,'Success','2026-11-15 09:11:08','2026-11-15 09:11:08','5750be1f178c76fe9',NULL,NULL),('9dd1c18854dfbd1cd','Submit Popup Reminders',0,'Success','2026-11-15 09:17:48','2026-11-15 09:17:48','bcd1c259a799fac87',NULL,NULL),('9f21be15d06df7f2f','Process Job Queue q0',0,'Success','2026-11-15 09:11:48','2026-11-15 09:11:48','5750be1f178c76fe9',NULL,NULL),('9f95c33ee9921643f','Send Email Notifications',0,'Success','2026-11-15 09:00:01','2026-11-15 09:00:01','e9d6c9980d694fb42',NULL,NULL),('9fcc533e94bf794af','Process Job Queue e0',0,'Success','2026-11-15 09:15:38','2026-11-15 09:15:38','5f75cd3ef25340f25',NULL,NULL),('a0a46393249c63329','Process Webhook Queue',0,'Success','2026-11-15 09:14:08','2026-11-15 09:14:08','4a6a036f21dffd48a',NULL,NULL),('a1b2939f779bb2004','Process Job Queue e0',0,'Success','2026-11-15 09:01:01','2026-11-15 09:01:01','5f75cd3ef25340f25',NULL,NULL),('a4204756f38e63979','Submit Popup Reminders',0,'Success','2026-11-15 09:09:58','2026-11-15 09:09:58','bcd1c259a799fac87',NULL,NULL),('a42f5b376c72107fc','Submit Popup Reminders',0,'Success','2026-11-15 09:10:28','2026-11-15 09:10:28','bcd1c259a799fac87',NULL,NULL),('a4399108f7e2370e1','Process Job Queue e0',0,'Success','2026-11-15 09:01:51','2026-11-15 09:01:51','5f75cd3ef25340f25',NULL,NULL),('a55e84df2cdf0ba44','Submit Popup Reminders',0,'Success','2026-11-15 09:16:38','2026-11-15 09:16:38','bcd1c259a799fac87',NULL,NULL),('a638c7814aaeb86f8','Process Job Queue q1',0,'Success','2026-11-15 09:08:08','2026-11-15 09:08:08','ea1678c7ea92717de',NULL,NULL),('a64e288eb3b335b5e','Process Job Queue q0',0,'Success','2026-11-15 08:59:51','2026-11-15 08:59:51','5750be1f178c76fe9',NULL,NULL),('a6ae5324dbc16cbb9','Submit Popup Reminders',0,'Success','2026-11-15 08:57:41','2026-11-15 08:57:41','bcd1c259a799fac87',NULL,NULL),('a6f587a58e06860d8','Process Job Queue e0',0,'Success','2026-11-15 09:20:18','2026-11-15 09:20:18','5f75cd3ef25340f25',NULL,NULL),('a764f8d3f8bd88361','Process Job Queue q1',0,'Success','2026-11-15 09:03:01','2026-11-15 09:03:01','ea1678c7ea92717de',NULL,NULL),('a7b9304a35dc7b66b','Process Job Queue e0',0,'Success','2026-11-15 09:03:31','2026-11-15 09:03:31','5f75cd3ef25340f25',NULL,NULL),('a843892aeb39cb671','Process Job Queue e0',0,'Success','2026-11-15 09:00:51','2026-11-15 09:00:51','5f75cd3ef25340f25',NULL,NULL),('a921a535f9886e7b0','Process Job Queue e0',0,'Success','2026-11-15 09:03:01','2026-11-15 09:03:01','5f75cd3ef25340f25',NULL,NULL),('a9b2ea6d0d1fcb9fb','Process Job Queue e0',0,'Success','2026-11-15 09:12:48','2026-11-15 09:12:48','5f75cd3ef25340f25',NULL,NULL),('ab2f3d040d5aade44','Process Job Queue q0',0,'Success','2026-11-15 08:58:31','2026-11-15 08:58:31','5750be1f178c76fe9',NULL,NULL),('ab46995b6ed728723','Process Job Queue e0',0,'Success','2026-11-15 08:59:31','2026-11-15 08:59:31','5f75cd3ef25340f25',NULL,NULL),('abbda83636e7c57b0','Process Job Queue q0',0,'Success','2026-11-15 09:08:28','2026-11-15 09:08:28','5750be1f178c76fe9',NULL,NULL),('abc2efd65e9e1c50b','Submit Popup Reminders',0,'Success','2026-11-15 09:18:28','2026-11-15 09:18:28','bcd1c259a799fac87',NULL,NULL),('ac0d18650164dc9c9','Process Webhook Queue',0,'Success','2026-11-15 09:18:08','2026-11-15 09:18:08','4a6a036f21dffd48a',NULL,NULL),('acd64da439e4a8b30','Process Job Queue q0',0,'Success','2026-11-15 09:15:58','2026-11-15 09:15:58','5750be1f178c76fe9',NULL,NULL),('ae016b2b0cbe649e2','Process Job Queue e0',0,'Success','2026-11-15 09:10:38','2026-11-15 09:10:38','5f75cd3ef25340f25',NULL,NULL),('ae3e3832d24de95a8','Process Job Queue e0',0,'Success','2026-11-15 09:12:28','2026-11-15 09:12:28','5f75cd3ef25340f25',NULL,NULL),('ae5f45ac37cc866ef','Submit Popup Reminders',0,'Success','2026-11-15 09:11:28','2026-11-15 09:11:28','bcd1c259a799fac87',NULL,NULL),('aeb221649e088f7aa','Submit Popup Reminders',0,'Success','2026-11-15 09:18:58','2026-11-15 09:18:58','bcd1c259a799fac87',NULL,NULL),('af1a5ad87772be625','Submit Popup Reminders',0,'Success','2026-11-15 09:01:51','2026-11-15 09:01:51','bcd1c259a799fac87',NULL,NULL),('af1faf43cc8d05eed','Process Job Queue e0',0,'Success','2026-11-15 08:59:41','2026-11-15 08:59:41','5f75cd3ef25340f25',NULL,NULL),('b0a00f2eec3fe2c94','Auth Token Control',0,'Success','2026-11-15 09:00:01','2026-11-15 09:00:01','eeb2498dde7129c23',NULL,NULL),('b0a28a2c94799031d','Process Job Queue e0',0,'Success','2026-11-15 09:04:01','2026-11-15 09:04:01','5f75cd3ef25340f25',NULL,NULL),('b113d273cc37d351b','Process Job Queue q0',0,'Success','2026-11-15 09:28:01','2026-11-15 09:28:01','5750be1f178c76fe9',NULL,NULL),('b3659b4a849715189','Process Job Queue q0',0,'Success','2026-11-15 09:03:01','2026-11-15 09:03:01','5750be1f178c76fe9',NULL,NULL),('b411be79829a94509','Submit Popup Reminders',0,'Success','2026-11-15 09:15:18','2026-11-15 09:15:18','bcd1c259a799fac87',NULL,NULL),('b4d5cc5e6bfe83975','Send Email Reminders',0,'Success','2026-11-15 09:16:08','2026-11-15 09:16:08','38c14103df40c8494',NULL,NULL),('b4ff61ed06f5b2b2c','Process Job Queue q0',0,'Success','2026-11-15 09:14:18','2026-11-15 09:14:18','5750be1f178c76fe9',NULL,NULL),('b687b035627556f43','Send Email Notifications',0,'Success','2026-11-15 09:20:08','2026-11-15 09:20:08','e9d6c9980d694fb42',NULL,NULL),('b6ef844d2290973b4','Process Job Queue q0',0,'Success','2026-11-15 08:59:11','2026-11-15 08:59:11','5750be1f178c76fe9',NULL,NULL),('b8f007ccc56cfbab2','Process Job Queue e0',0,'Success','2026-11-15 08:58:51','2026-11-15 08:58:51','5f75cd3ef25340f25',NULL,NULL),('b96f13328df9971b2','Process Job Queue e0',0,'Success','2026-11-15 09:09:48','2026-11-15 09:09:48','5f75cd3ef25340f25',NULL,NULL),('b9cd62f0fe0fd7b16','Submit Popup Reminders',0,'Success','2026-11-15 09:03:01','2026-11-15 09:03:01','bcd1c259a799fac87',NULL,NULL),('ba027c6d89b4ab754','Submit Popup Reminders',0,'Success','2026-11-15 08:59:21','2026-11-15 08:59:21','bcd1c259a799fac87',NULL,NULL),('ba6b6126fbd3fb0dc','Process Job Queue q0',0,'Success','2026-11-15 09:17:38','2026-11-15 09:17:38','5750be1f178c76fe9',NULL,NULL),('ba7529aba0479ca9e','Process Job Queue e0',0,'Success','2026-11-15 09:13:28','2026-11-15 09:13:28','5f75cd3ef25340f25',NULL,NULL),('ba7b299218745c121','Process Job Queue e0',0,'Success','2026-11-15 09:10:58','2026-11-15 09:10:58','5f75cd3ef25340f25',NULL,NULL),('bb1a450af1aa1e92f','Submit Popup Reminders',0,'Success','2026-11-15 09:28:01','2026-11-15 09:28:01','bcd1c259a799fac87',NULL,NULL),('bbdede9e6d4d1c5d8','Process Job Queue e0',0,'Success','2026-11-15 09:15:18','2026-11-15 09:15:18','5f75cd3ef25340f25',NULL,NULL),('bc02bfdcbdfe336d4','Process Job Queue q0',0,'Success','2026-11-15 09:12:18','2026-11-15 09:12:18','5750be1f178c76fe9',NULL,NULL),('bcebe8d83b785d93a','Send Email Reminders',0,'Success','2026-11-15 09:18:08','2026-11-15 09:18:08','38c14103df40c8494',NULL,NULL),('bd07fdea2f3f7c227','Submit Popup Reminders',0,'Success','2026-11-15 09:13:58','2026-11-15 09:13:58','bcd1c259a799fac87',NULL,NULL),('bd249454545efd089','Submit Popup Reminders',0,'Success','2026-11-15 09:11:48','2026-11-15 09:11:48','bcd1c259a799fac87',NULL,NULL),('bdfe10336ad852bf1','Submit Popup Reminders',0,'Success','2026-11-15 08:58:21','2026-11-15 08:58:21','bcd1c259a799fac87',NULL,NULL),('beb7f98b49ddfc1cb','Process Job Queue q0',0,'Success','2026-11-15 09:27:51','2026-11-15 09:27:51','5750be1f178c76fe9',NULL,NULL),('bf5808a8be0a1cf7e','Process Webhook Queue',0,'Success','2026-11-15 09:06:08','2026-11-15 09:06:08','4a6a036f21dffd48a',NULL,NULL),('bfa44f3ae09cd6ca8','Send Email Notifications',0,'Success','2026-11-15 09:14:08','2026-11-15 09:14:08','e9d6c9980d694fb42',NULL,NULL),('c024f1756a9ffa023','Submit Popup Reminders',0,'Success','2026-11-15 09:10:08','2026-11-15 09:10:08','bcd1c259a799fac87',NULL,NULL),('c0da058931dacdf14','Submit Popup Reminders',0,'Success','2026-11-15 09:13:38','2026-11-15 09:13:38','bcd1c259a799fac87',NULL,NULL),('c13d2bc618c5f8c4e','Process Job Queue e0',0,'Success','2026-11-15 09:04:11','2026-11-15 09:04:11','5f75cd3ef25340f25',NULL,NULL),('c17f3cb962223d5c6','Process Job Queue q1',0,'Success','2026-11-15 09:11:08','2026-11-15 09:11:08','ea1678c7ea92717de',NULL,NULL),('c1b07dd9ae267d825','Submit Popup Reminders',0,'Success','2026-11-15 08:57:51','2026-11-15 08:57:51','bcd1c259a799fac87',NULL,NULL),('c2db55bb419f81535','Process Job Queue q0',0,'Success','2026-11-15 09:09:18','2026-11-15 09:09:18','5750be1f178c76fe9',NULL,NULL),('c38a244499bc17ca9','Submit Popup Reminders',0,'Success','2026-11-15 09:20:08','2026-11-15 09:20:08','bcd1c259a799fac87',NULL,NULL),('c3f195e82edd2f75f','Submit Popup Reminders',0,'Success','2026-11-15 08:58:51','2026-11-15 08:58:51','bcd1c259a799fac87',NULL,NULL),('c41d97c4c20222bc7','Process Webhook Queue',0,'Success','2026-11-15 09:02:01','2026-11-15 09:02:01','4a6a036f21dffd48a',NULL,NULL),('c47bcf42c0b6363bf','Process Job Queue q1',0,'Success','2026-11-15 09:05:28','2026-11-15 09:05:28','ea1678c7ea92717de',NULL,NULL),('c497fca46a66e38ef','Submit Popup Reminders',0,'Success','2026-11-15 09:20:28','2026-11-15 09:20:28','bcd1c259a799fac87',NULL,NULL),('c5d51bac23d2e69eb','Process Job Queue e0',0,'Success','2026-11-15 08:59:51','2026-11-15 08:59:51','5f75cd3ef25340f25',NULL,NULL),('c5ed0b7d0735f308f','Send Mass Emails',0,'Success','2026-11-15 09:10:08','2026-11-15 09:10:08','8413c58638261267b',NULL,NULL),('c6962dc1e194efc4e','Process Job Queue q0',0,'Success','2026-11-15 09:04:01','2026-11-15 09:04:01','5750be1f178c76fe9',NULL,NULL),('c6a2951928d9816d8','Process Job Queue q0',0,'Success','2026-11-15 09:03:11','2026-11-15 09:03:11','5750be1f178c76fe9',NULL,NULL),('c6fcd3d42615b2a89','Submit Popup Reminders',0,'Success','2026-11-15 09:16:58','2026-11-15 09:16:58','bcd1c259a799fac87',NULL,NULL),('c7aca86f7cf8158c6','Process Job Queue e0',0,'Success','2026-11-15 09:14:18','2026-11-15 09:14:18','5f75cd3ef25340f25',NULL,NULL),('c86e6fa9538c218f2','Process Job Queue q0',0,'Success','2026-11-15 09:02:51','2026-11-15 09:02:51','5750be1f178c76fe9',NULL,NULL),('c88212c56b6cb3e3d','Submit Popup Reminders',0,'Success','2026-11-15 09:16:28','2026-11-15 09:16:28','bcd1c259a799fac87',NULL,NULL),('c8b6a0c47336877b7','Process Job Queue q0',0,'Success','2026-11-15 09:05:58','2026-11-15 09:05:58','5750be1f178c76fe9',NULL,NULL),('c9b0569277293e1f2','Process Job Queue e0',0,'Success','2026-11-15 09:09:58','2026-11-15 09:09:58','5f75cd3ef25340f25',NULL,NULL),('c9c3d423f3f6014e4','Submit Popup Reminders',0,'Success','2026-11-15 09:19:48','2026-11-15 09:19:48','bcd1c259a799fac87',NULL,NULL),('ca006ccd6bd0b9225','Submit Popup Reminders',0,'Success','2026-11-15 09:06:18','2026-11-15 09:06:18','bcd1c259a799fac87',NULL,NULL),('ca6b5a83a39f8b030','Send Email Reminders',0,'Success','2026-11-15 09:14:08','2026-11-15 09:14:08','38c14103df40c8494',NULL,NULL),('cad55349f6095b7a9','Process Job Queue q0',0,'Success','2026-11-15 09:08:48','2026-11-15 09:08:48','5750be1f178c76fe9',NULL,NULL),('cbe2181ce7d1d82c6','Process Job Queue e0',0,'Success','2026-11-15 09:07:38','2026-11-15 09:07:38','5f75cd3ef25340f25',NULL,NULL),('cbf2ee90adc59a0a7','Process Job Queue e0',0,'Success','2026-11-15 09:08:28','2026-11-15 09:08:28','5f75cd3ef25340f25',NULL,NULL),('cc7b21c896120633c','Process Job Queue q0',0,'Success','2026-11-15 09:01:41','2026-11-15 09:01:41','5750be1f178c76fe9',NULL,NULL),('cd7b82d27581adf52','Process Job Queue q0',0,'Success','2026-11-15 09:04:11','2026-11-15 09:04:11','5750be1f178c76fe9',NULL,NULL),('cdbdd5d8495e1f9ea','Submit Popup Reminders',0,'Success','2026-11-15 09:18:18','2026-11-15 09:18:18','bcd1c259a799fac87',NULL,NULL),('cde11efed1878695c','Submit Popup Reminders',0,'Success','2026-11-15 09:12:58','2026-11-15 09:12:58','bcd1c259a799fac87',NULL,NULL),('cf0b9eebceeaff360','Submit Popup Reminders',0,'Success','2026-11-15 09:00:41','2026-11-15 09:00:41','bcd1c259a799fac87',NULL,NULL),('cf385d25e5ffcf066','Process Job Queue e0',0,'Success','2026-11-15 09:18:38','2026-11-15 09:18:38','5f75cd3ef25340f25',NULL,NULL),('cf3ec9aca6bd27ec3','Process Job Queue e0',0,'Success','2026-11-15 09:17:58','2026-11-15 09:17:58','5f75cd3ef25340f25',NULL,NULL),('cf432c173ce897e9e','Submit Popup Reminders',0,'Success','2026-11-15 09:02:31','2026-11-15 09:02:31','bcd1c259a799fac87',NULL,NULL),('d01061e10c2786b24','Process Job Queue q0',0,'Success','2026-11-15 09:08:08','2026-11-15 09:08:08','5750be1f178c76fe9',NULL,NULL),('d187412df77919999','Submit Popup Reminders',0,'Success','2026-11-15 09:03:31','2026-11-15 09:03:31','bcd1c259a799fac87',NULL,NULL),('d2341981c62940c8a','Process Job Queue q0',0,'Success','2026-11-15 09:19:08','2026-11-15 09:19:08','5750be1f178c76fe9',NULL,NULL),('d2a2718ade96b4481','Submit Popup Reminders',0,'Success','2026-11-15 08:59:31','2026-11-15 08:59:31','bcd1c259a799fac87',NULL,NULL),('d4029248e34224b08','Process Job Queue q0',0,'Success','2026-11-15 08:59:01','2026-11-15 08:59:01','5750be1f178c76fe9',NULL,NULL),('d445fb51b4a9b1839','Process Job Queue q0',0,'Success','2026-11-15 09:14:38','2026-11-15 09:14:38','5750be1f178c76fe9',NULL,NULL),('d46341b04dc9eb33e','Process Job Queue e0',0,'Success','2026-11-15 09:17:08','2026-11-15 09:17:08','5f75cd3ef25340f25',NULL,NULL),('d5190a4fe3f6d0334','Submit Popup Reminders',0,'Success','2026-11-15 09:20:58','2026-11-15 09:20:58','bcd1c259a799fac87',NULL,NULL),('d58affc46951be267','Submit Popup Reminders',0,'Success','2026-11-15 09:28:11','2026-11-15 09:28:11','bcd1c259a799fac87',NULL,NULL),('d6dae9433914fff17','Send Email Notifications',0,'Success','2026-11-15 09:10:08','2026-11-15 09:10:08','e9d6c9980d694fb42',NULL,NULL),('d792c8ab59d383083','Process Job Queue e0',0,'Success','2026-11-15 09:16:38','2026-11-15 09:16:38','5f75cd3ef25340f25',NULL,NULL),('d7a9f0360e40d1d0f','Submit Popup Reminders',0,'Success','2026-11-15 09:05:58','2026-11-15 09:05:58','bcd1c259a799fac87',NULL,NULL),('d8c5b2c3b33604ff2','Submit Popup Reminders',0,'Success','2026-11-15 09:19:18','2026-11-15 09:19:18','bcd1c259a799fac87',NULL,NULL),('d950be529841bfe7f','Process Job Queue q0',0,'Success','2026-11-15 09:05:38','2026-11-15 09:05:38','5750be1f178c76fe9',NULL,NULL),('da697f5531dc1804d','Process Job Queue e0',0,'Success','2026-11-15 09:09:18','2026-11-15 09:09:18','5f75cd3ef25340f25',NULL,NULL),('daf69027b6f6f5885','Submit Popup Reminders',0,'Success','2026-11-15 09:15:48','2026-11-15 09:15:48','bcd1c259a799fac87',NULL,NULL),('dbcaf0b90a5e990cb','Submit Popup Reminders',0,'Success','2026-11-15 09:15:38','2026-11-15 09:15:38','bcd1c259a799fac87',NULL,NULL),('dc3dbb738b204b6f1','Submit Popup Reminders',0,'Success','2026-11-15 09:10:38','2026-11-15 09:10:38','bcd1c259a799fac87',NULL,NULL),('dc7a87d1db835d36c','Process Job Queue q0',0,'Success','2026-11-15 09:13:18','2026-11-15 09:13:18','5750be1f178c76fe9',NULL,NULL),('dc969613ffde67233','Submit Popup Reminders',0,'Success','2026-11-15 08:58:31','2026-11-15 08:58:31','bcd1c259a799fac87',NULL,NULL),('dcd4dfae178414cac','Process Job Queue q0',0,'Success','2026-11-15 09:05:48','2026-11-15 09:05:48','5750be1f178c76fe9',NULL,NULL),('ddfed555bddd9b4f1','Process Job Queue q0',0,'Success','2026-11-15 09:06:38','2026-11-15 09:06:38','5750be1f178c76fe9',NULL,NULL),('dedd42b75988d8016','Process Job Queue q0',0,'Success','2026-11-15 09:20:48','2026-11-15 09:20:48','5750be1f178c76fe9',NULL,NULL),('dee74b8b021348235','Process Job Queue e0',0,'Success','2026-11-15 09:01:31','2026-11-15 09:01:31','5f75cd3ef25340f25',NULL,NULL),('df1bc7ed873715e51','Process Job Queue q0',0,'Success','2026-11-15 08:58:51','2026-11-15 08:58:51','5750be1f178c76fe9',NULL,NULL),('df50f262821ee07f4','Process Webhook Queue',0,'Success','2026-11-15 09:16:08','2026-11-15 09:16:08','4a6a036f21dffd48a',NULL,NULL),('e071da2386d6da651','Process Job Queue e0',0,'Success','2026-11-15 09:01:41','2026-11-15 09:01:41','5f75cd3ef25340f25',NULL,NULL),('e07fdf0da369188b8','Process Job Queue q0',0,'Success','2026-11-15 09:19:28','2026-11-15 09:19:28','5750be1f178c76fe9',NULL,NULL),('e12bab351211bf739','Submit Popup Reminders',0,'Success','2026-11-15 09:12:08','2026-11-15 09:12:08','bcd1c259a799fac87',NULL,NULL),('e1f0f9e210190eac2','Process Job Queue e0',0,'Success','2026-11-15 09:00:21','2026-11-15 09:00:21','5f75cd3ef25340f25',NULL,NULL),('e2881c198d51d8af2','Process Job Queue e0',0,'Success','2026-11-15 09:00:01','2026-11-15 09:00:01','5f75cd3ef25340f25',NULL,NULL),('e2d4aa9a1fdf80e9c','Process Job Queue e0',0,'Success','2026-11-15 09:17:28','2026-11-15 09:17:28','5f75cd3ef25340f25',NULL,NULL),('e2db91727b780a4a2','Process Job Queue q1',0,'Success','2026-11-15 09:10:08','2026-11-15 09:10:08','ea1678c7ea92717de',NULL,NULL),('e4403f2688ee5737c','Process Job Queue e0',0,'Success','2026-11-15 09:07:28','2026-11-15 09:07:28','5f75cd3ef25340f25',NULL,NULL),('e4482d138c98701e0','Submit Popup Reminders',0,'Success','2026-11-15 09:08:18','2026-11-15 09:08:18','bcd1c259a799fac87',NULL,NULL),('e4b2e17033aee49cd','Process Job Queue q0',0,'Success','2026-11-15 09:15:28','2026-11-15 09:15:28','5750be1f178c76fe9',NULL,NULL),('e5050d6cb32f1a983','Process Job Queue q0',0,'Success','2026-11-15 09:09:48','2026-11-15 09:09:48','5750be1f178c76fe9',NULL,NULL),('e595606401d80905a','Process Job Queue e0',0,'Success','2026-11-15 09:05:28','2026-11-15 09:05:28','5f75cd3ef25340f25',NULL,NULL),('e5b98781def351853','Submit Popup Reminders',0,'Success','2026-11-15 09:19:08','2026-11-15 09:19:08','bcd1c259a799fac87',NULL,NULL),('e60bbfa1d7a494003','Process Job Queue e0',0,'Success','2026-11-15 09:17:38','2026-11-15 09:17:38','5f75cd3ef25340f25',NULL,NULL),('e7486570bb203d573','Process Job Queue q0',0,'Success','2026-11-15 09:01:31','2026-11-15 09:01:31','5750be1f178c76fe9',NULL,NULL),('e7601f15a096790d9','Process Job Queue e0',0,'Success','2026-11-15 09:18:48','2026-11-15 09:18:48','5f75cd3ef25340f25',NULL,NULL),('e99ee096e3db11878','Process Job Queue e0',0,'Success','2026-11-15 09:03:11','2026-11-15 09:03:11','5f75cd3ef25340f25',NULL,NULL),('ea3d99070161fea96','Submit Popup Reminders',0,'Success','2026-11-15 09:05:48','2026-11-15 09:05:48','bcd1c259a799fac87',NULL,NULL),('eaa9513b8af63e632','Submit Popup Reminders',0,'Success','2026-11-15 09:17:18','2026-11-15 09:17:18','bcd1c259a799fac87',NULL,NULL),('eaad50bc4352e92c4','Process Job Queue e0',0,'Success','2026-11-15 09:13:38','2026-11-15 09:13:38','5f75cd3ef25340f25',NULL,NULL),('eafb5d17e6f92d672','Send Email Notifications',0,'Success','2026-11-15 09:06:08','2026-11-15 09:06:08','e9d6c9980d694fb42',NULL,NULL),('eb09013513b2f154d','Process Job Queue q0',0,'Success','2026-11-15 09:15:18','2026-11-15 09:15:18','5750be1f178c76fe9',NULL,NULL),('ebe2cc9bd0e1e547c','Submit Popup Reminders',0,'Success','2026-11-15 09:06:08','2026-11-15 09:06:08','bcd1c259a799fac87',NULL,NULL),('ec98a4d688966aa56','Process Job Queue e0',0,'Success','2026-11-15 09:10:18','2026-11-15 09:10:18','5f75cd3ef25340f25',NULL,NULL),('ed05c84ac1da610d7','Process Job Queue q0',0,'Success','2026-11-15 09:19:18','2026-11-15 09:19:18','5750be1f178c76fe9',NULL,NULL),('ed4e1090b171c24b8','Submit Popup Reminders',0,'Success','2026-11-15 09:00:02','2026-11-15 09:00:02','bcd1c259a799fac87',NULL,NULL),('ee2b63fe3c91d3650','Submit Popup Reminders',0,'Success','2026-11-15 08:58:41','2026-11-15 08:58:41','bcd1c259a799fac87',NULL,NULL),('ee8043b7e4cb714ed','Process Job Queue q0',0,'Success','2026-11-15 09:07:28','2026-11-15 09:07:28','5750be1f178c76fe9',NULL,NULL),('ee91b77de5a30d25d','Submit Popup Reminders',0,'Success','2026-11-15 09:15:08','2026-11-15 09:15:08','bcd1c259a799fac87',NULL,NULL),('eeaf8eddbd55c34ee','Process Job Queue q0',0,'Success','2026-11-15 08:57:41','2026-11-15 08:57:41','5750be1f178c76fe9',NULL,NULL),('eeca10a6232846049','Submit Popup Reminders',0,'Success','2026-11-15 09:11:08','2026-11-15 09:11:08','bcd1c259a799fac87',NULL,NULL),('eeecb7b35b3959cd5','Process Job Queue q0',0,'Success','2026-11-15 08:57:31','2026-11-15 08:57:31','5750be1f178c76fe9',NULL,NULL),('ef7cef4227d677ba3','Process Job Queue q0',0,'Success','2026-11-15 09:13:48','2026-11-15 09:13:48','5750be1f178c76fe9',NULL,NULL),('efaeb33ae17f92893','Submit Popup Reminders',0,'Success','2026-11-15 09:02:01','2026-11-15 09:02:01','bcd1c259a799fac87',NULL,NULL),('f0299d6b003e44ee7','Process Job Queue q0',0,'Success','2026-11-15 09:02:31','2026-11-15 09:02:31','5750be1f178c76fe9',NULL,NULL),('f0c70ca835ec730f1','Process Job Queue e0',0,'Success','2026-11-15 09:06:08','2026-11-15 09:06:08','5f75cd3ef25340f25',NULL,NULL),('f11f5280cc869f2a1','Process Job Queue e0',0,'Success','2026-11-15 09:12:58','2026-11-15 09:12:58','5f75cd3ef25340f25',NULL,NULL),('f1422a4295f4722e4','Process Job Queue q0',0,'Success','2026-11-15 09:08:58','2026-11-15 09:08:58','5750be1f178c76fe9',NULL,NULL),('f15f6ad5c514faf1d','Send Email Notifications',0,'Success','2026-11-15 09:02:01','2026-11-15 09:02:01','e9d6c9980d694fb42',NULL,NULL),('f1e4d734a9e5164cf','Submit Popup Reminders',0,'Success','2026-11-15 09:07:28','2026-11-15 09:07:28','bcd1c259a799fac87',NULL,NULL),('f261dfb83763b08b2','Submit Popup Reminders',0,'Success','2026-11-15 08:59:11','2026-11-15 08:59:11','bcd1c259a799fac87',NULL,NULL),('f2a1935826eed26df','Process Job Queue e0',0,'Success','2026-11-15 09:27:51','2026-11-15 09:27:51','5f75cd3ef25340f25',NULL,NULL),('f2ca499ceac8f0e65','Process Job Queue q0',0,'Success','2026-11-15 08:58:41','2026-11-15 08:58:41','5750be1f178c76fe9',NULL,NULL),('f2e19e160caee8585','Process Job Queue q0',0,'Success','2026-11-15 09:08:38','2026-11-15 09:08:38','5750be1f178c76fe9',NULL,NULL),('f3ae8eeb74325730f','Process Job Queue e0',0,'Success','2026-11-15 09:06:28','2026-11-15 09:06:28','5f75cd3ef25340f25',NULL,NULL),('f452275199eb1c2b5','Process Job Queue e0',0,'Success','2026-11-15 09:11:58','2026-11-15 09:11:58','5f75cd3ef25340f25',NULL,NULL),('f45dc2446b563d6da','Send Email Notifications',0,'Success','2026-11-15 09:08:08','2026-11-15 09:08:08','e9d6c9980d694fb42',NULL,NULL),('f4e6d74eac72694b6','Process Job Queue q1',0,'Success','2026-11-15 09:00:01','2026-11-15 09:00:01','ea1678c7ea92717de',NULL,NULL),('f4fb4301386ed67ca','Submit Popup Reminders',0,'Success','2026-11-15 09:02:21','2026-11-15 09:02:21','bcd1c259a799fac87',NULL,NULL),('f604ed3c8becfe60a','Process Job Queue e0',0,'Success','2026-11-15 09:11:38','2026-11-15 09:11:38','5f75cd3ef25340f25',NULL,NULL),('f66abe01157c24875','Process Job Queue q0',0,'Success','2026-11-15 09:16:18','2026-11-15 09:16:18','5750be1f178c76fe9',NULL,NULL),('f7536b944a2345386','Process Job Queue e0',0,'Success','2026-11-15 09:16:58','2026-11-15 09:16:58','5f75cd3ef25340f25',NULL,NULL),('f8dcba84ac2baaa11','Process Job Queue q0',0,'Success','2026-11-15 09:13:28','2026-11-15 09:13:28','5750be1f178c76fe9',NULL,NULL),('f9aabd46338dc1ae6','Process Job Queue q0',0,'Success','2026-11-15 09:18:58','2026-11-15 09:18:58','5750be1f178c76fe9',NULL,NULL),('f9c862721d8656313','Process Job Queue q0',0,'Success','2026-11-15 09:16:58','2026-11-15 09:16:58','5750be1f178c76fe9',NULL,NULL),('fbe7f1a6499c11c32','Process Job Queue e0',0,'Success','2026-11-15 09:11:08','2026-11-15 09:11:08','5f75cd3ef25340f25',NULL,NULL),('fc77d2d7e9052583b','Process Job Queue e0',0,'Success','2026-11-15 09:15:08','2026-11-15 09:15:08','5f75cd3ef25340f25',NULL,NULL),('fd4cdd6de2b9699d0','Process Job Queue e0',0,'Success','2026-11-15 09:13:08','2026-11-15 09:13:08','5f75cd3ef25340f25',NULL,NULL),('fd7b24aedee25e904','Process Job Queue e0',0,'Success','2026-11-15 08:58:01','2026-11-15 08:58:01','5f75cd3ef25340f25',NULL,NULL),('fe37c0ffc277dca36','Submit Popup Reminders',0,'Success','2026-11-15 09:10:18','2026-11-15 09:10:18','bcd1c259a799fac87',NULL,NULL),('fe4e2af4581bb21c9','Submit Popup Reminders',0,'Success','2026-11-15 09:18:48','2026-11-15 09:18:48','bcd1c259a799fac87',NULL,NULL),('feab0e3ad56081388','Send Email Reminders',0,'Success','2026-11-15 09:04:01','2026-11-15 09:04:01','38c14103df40c8494',NULL,NULL),('ff0fd07315dd28fdd','Process Job Queue q0',0,'Success','2026-11-15 08:59:21','2026-11-15 08:59:21','5750be1f178c76fe9',NULL,NULL),('ff8b5e05b840fc4ca','Process Job Queue q1',0,'Success','2026-11-15 09:06:08','2026-11-15 09:06:08','ea1678c7ea92717de',NULL,NULL),('ffcd2a61391f8349e','Process Job Queue e0',0,'Success','2026-11-15 09:09:28','2026-11-15 09:09:28','5f75cd3ef25340f25',NULL,NULL);
/*!40000 ALTER TABLE `scheduled_job_log_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms`
--

DROP TABLE IF EXISTS `sms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `from_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Archived',
  `date_sent` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `from_phone_number_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `replied_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_DATE_SENT` (`date_sent`,`deleted`),
  KEY `IDX_DATE_SENT_STATUS` (`date_sent`,`status`,`deleted`),
  KEY `IDX_FROM_PHONE_NUMBER_ID` (`from_phone_number_id`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_REPLIED_ID` (`replied_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms`
--

LOCK TABLES `sms` WRITE;
/*!40000 ALTER TABLE `sms` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_phone_number`
--

DROP TABLE IF EXISTS `sms_phone_number`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_phone_number` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `sms_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_type` varchar(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_SMS_ID_PHONE_NUMBER_ID_ADDRESS_TYPE` (`sms_id`,`phone_number_id`,`address_type`),
  KEY `IDX_SMS_ID` (`sms_id`),
  KEY `IDX_PHONE_NUMBER_ID` (`phone_number_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_phone_number`
--

LOCK TABLES `sms_phone_number` WRITE;
/*!40000 ALTER TABLE `sms_phone_number` DISABLE KEYS */;
/*!40000 ALTER TABLE `sms_phone_number` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `star_subscription`
--

DROP TABLE IF EXISTS `star_subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `star_subscription` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `deleted` tinyint DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ENTITY` (`user_id`,`entity_id`,`entity_type`),
  KEY `IDX_USER_ENTITY_TYPE` (`user_id`,`entity_type`),
  KEY `IDX_ENTITY` (`entity_id`,`entity_type`),
  KEY `IDX_USER` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `star_subscription`
--

LOCK TABLES `star_subscription` WRITE;
/*!40000 ALTER TABLE `star_subscription` DISABLE KEYS */;
/*!40000 ALTER TABLE `star_subscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stream_subscription`
--

DROP TABLE IF EXISTS `stream_subscription`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stream_subscription` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `deleted` tinyint DEFAULT '0',
  `entity_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `entity_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_USER_ENTITY` (`user_id`,`entity_id`,`entity_type`),
  KEY `IDX_ENTITY` (`entity_id`,`entity_type`),
  KEY `IDX_USER` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stream_subscription`
--

LOCK TABLES `stream_subscription` WRITE;
/*!40000 ALTER TABLE `stream_subscription` DISABLE KEYS */;
/*!40000 ALTER TABLE `stream_subscription` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_data`
--

DROP TABLE IF EXISTS `system_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_data` (
  `id` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `last_password_recovery_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_data`
--

LOCK TABLES `system_data` WRITE;
/*!40000 ALTER TABLE `system_data` DISABLE KEYS */;
INSERT INTO `system_data` VALUES ('1',0,NULL);
/*!40000 ALTER TABLE `system_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_state`
--

DROP TABLE IF EXISTS `system_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_state` (
  `id` varchar(1) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `version_number` bigint DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_state`
--

LOCK TABLES `system_state` WRITE;
/*!40000 ALTER TABLE `system_state` DISABLE KEYS */;
INSERT INTO `system_state` VALUES ('1',0);
/*!40000 ALTER TABLE `system_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `target`
--

DROP TABLE IF EXISTS `target`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `salutation_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT '',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_street` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_state` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address_postal_code` varchar(40) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `do_not_call` tinyint NOT NULL DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `middle_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_FIRST_NAME` (`first_name`,`deleted`),
  KEY `IDX_NAME` (`first_name`,`last_name`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `target`
--

LOCK TABLES `target` WRITE;
/*!40000 ALTER TABLE `target` DISABLE KEYS */;
/*!40000 ALTER TABLE `target` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `target_list`
--

DROP TABLE IF EXISTS `target_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_list` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `category_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_AT` (`created_at`,`deleted`),
  KEY `IDX_CATEGORY_ID` (`category_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `target_list`
--

LOCK TABLES `target_list` WRITE;
/*!40000 ALTER TABLE `target_list` DISABLE KEYS */;
/*!40000 ALTER TABLE `target_list` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `target_list_category`
--

DROP TABLE IF EXISTS `target_list_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_list_category` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `order` int DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_PARENT_ID` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `target_list_category`
--

LOCK TABLES `target_list_category` WRITE;
/*!40000 ALTER TABLE `target_list_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `target_list_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `target_list_category_path`
--

DROP TABLE IF EXISTS `target_list_category_path`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_list_category_path` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ascendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `descendor_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_ASCENDOR_ID` (`ascendor_id`),
  KEY `IDX_DESCENDOR_ID` (`descendor_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `target_list_category_path`
--

LOCK TABLES `target_list_category_path` WRITE;
/*!40000 ALTER TABLE `target_list_category_path` DISABLE KEYS */;
/*!40000 ALTER TABLE `target_list_category_path` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `target_list_user`
--

DROP TABLE IF EXISTS `target_list_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `target_list_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_list_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `opted_out` tinyint DEFAULT '0',
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ID_TARGET_LIST_ID` (`user_id`,`target_list_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_TARGET_LIST_ID` (`target_list_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `target_list_user`
--

LOCK TABLES `target_list_user` WRITE;
/*!40000 ALTER TABLE `target_list_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `target_list_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `task`
--

DROP TABLE IF EXISTS `task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `task` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Not Started',
  `priority` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Normal',
  `date_start` datetime DEFAULT NULL,
  `date_end` datetime DEFAULT NULL,
  `date_start_date` date DEFAULT NULL,
  `date_end_date` date DEFAULT NULL,
  `date_completed` datetime DEFAULT NULL,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `stream_updated_at` datetime DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assigned_user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint DEFAULT '0',
  `email_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_DATE_START_STATUS` (`date_start`,`status`),
  KEY `IDX_DATE_END_STATUS` (`date_end`,`status`),
  KEY `IDX_DATE_START` (`date_start`,`deleted`),
  KEY `IDX_STATUS` (`status`,`deleted`),
  KEY `IDX_ASSIGNED_USER` (`assigned_user_id`,`deleted`),
  KEY `IDX_ASSIGNED_USER_STATUS` (`assigned_user_id`,`status`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`),
  KEY `IDX_ACCOUNT_ID` (`account_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`),
  KEY `IDX_ASSIGNED_USER_ID` (`assigned_user_id`),
  KEY `IDX_EMAIL_ID` (`email_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `task`
--

LOCK TABLES `task` WRITE;
/*!40000 ALTER TABLE `task` DISABLE KEYS */;
/*!40000 ALTER TABLE `task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team`
--

DROP TABLE IF EXISTS `team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `position_list` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `layout_set_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `working_time_calendar_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_LAYOUT_SET_ID` (`layout_set_id`),
  KEY `IDX_WORKING_TIME_CALENDAR_ID` (`working_time_calendar_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team`
--

LOCK TABLES `team` WRITE;
/*!40000 ALTER TABLE `team` DISABLE KEYS */;
/*!40000 ALTER TABLE `team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `team_user`
--

DROP TABLE IF EXISTS `team_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `team_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_TEAM_ID_USER_ID` (`team_id`,`user_id`),
  KEY `IDX_TEAM_ID` (`team_id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `team_user`
--

LOCK TABLES `team_user` WRITE;
/*!40000 ALTER TABLE `team_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `team_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `template`
--

DROP TABLE IF EXISTS `template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `template` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `body` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `header` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `footer` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `entity_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(8) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Active',
  `left_margin` double DEFAULT '10',
  `right_margin` double DEFAULT '10',
  `top_margin` double DEFAULT '10',
  `bottom_margin` double DEFAULT '20',
  `print_footer` tinyint NOT NULL DEFAULT '0',
  `print_header` tinyint NOT NULL DEFAULT '0',
  `footer_position` double DEFAULT '10',
  `header_position` double DEFAULT '0',
  `style` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `page_orientation` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Portrait',
  `page_format` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'A4',
  `page_width` double DEFAULT NULL,
  `page_height` double DEFAULT NULL,
  `font_face` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filename` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `version_number` bigint DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `template`
--

LOCK TABLES `template` WRITE;
/*!40000 ALTER TABLE `template` DISABLE KEYS */;
/*!40000 ALTER TABLE `template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `two_factor_code`
--

DROP TABLE IF EXISTS `two_factor_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `two_factor_code` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `code` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `method` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `attempts_left` int DEFAULT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_AT` (`created_at`),
  KEY `IDX_USER_ID_METHOD` (`user_id`,`method`),
  KEY `IDX_USER_ID_METHOD_IS_ACTIVE` (`user_id`,`method`,`is_active`),
  KEY `IDX_USER_ID_METHOD_CREATED_AT` (`user_id`,`method`,`created_at`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `two_factor_code`
--

LOCK TABLES `two_factor_code` WRITE;
/*!40000 ALTER TABLE `two_factor_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `two_factor_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unique_id`
--

DROP TABLE IF EXISTS `unique_id`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unique_id` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `terminate_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_NAME` (`name`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_TARGET` (`target_id`,`target_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unique_id`
--

LOCK TABLES `unique_id` WRITE;
/*!40000 ALTER TABLE `unique_id` DISABLE KEYS */;
/*!40000 ALTER TABLE `unique_id` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `user_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'regular',
  `password` varchar(150) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password_version` int NOT NULL DEFAULT '0',
  `auth_method` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `api_key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `salutation_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar_color` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `middle_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delete_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `default_team_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dashboard_template_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `working_time_calendar_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `layout_set_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_NAME_DELETE_ID` (`user_name`,`delete_id`),
  KEY `IDX_USER_NAME` (`user_name`),
  KEY `IDX_TYPE` (`type`),
  KEY `IDX_DEFAULT_TEAM_ID` (`default_team_id`),
  KEY `IDX_CONTACT_ID` (`contact_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_DASHBOARD_TEMPLATE_ID` (`dashboard_template_id`),
  KEY `IDX_WORKING_TIME_CALENDAR_ID` (`working_time_calendar_id`),
  KEY `IDX_LAYOUT_SET_ID` (`layout_set_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('2f1e0b7f89ae3c497',0,'admin','admin','$2y$12$2at10IAs5T.irM/k0nSyzums1jnF5QftZ1J7GDzBCHLnaN0FCFyhi',1,NULL,NULL,NULL,NULL,'Admin',1,NULL,NULL,NULL,'2026-11-15 08:56:59','2026-11-15 08:56:59',NULL,'0',NULL,NULL,NULL,'system',NULL,NULL,NULL),('3869dda69e6770c35',1,'testuser2','regular','$2y$12$Ps/ZD26A.ky994P4IWA6AOs7Y7hQb7cb9z3iG08eLC5NYyAQLz.6O',1,NULL,NULL,NULL,'Тест','Второй',1,NULL,NULL,NULL,'2026-11-15 08:58:33','2026-11-15 09:02:23',NULL,'ad7a86f66bb1ffd7d',NULL,NULL,NULL,'2f1e0b7f89ae3c497',NULL,NULL,NULL),('39ce8dc9b1c5e0553',0,'kozlova','regular','$2y$12$uxRzvq987Jp5ciFlm6aLQurUGzSaCIcMKT71LjsD79TMVyrwBqmum',1,NULL,NULL,NULL,'Марина','Козлова',1,'Исполнитель',NULL,NULL,'2026-11-15 08:57:37','2026-11-15 08:57:37','Сергеевна','0',NULL,NULL,NULL,'2f1e0b7f89ae3c497',NULL,NULL,NULL),('5345f9133074952bc',0,'ivanova','regular','$2y$12$h2gXkUsFAX4OMDMgbWT5g.4yU.bKRJdcmOaxm9YNMYgU1amExRlZm',1,NULL,NULL,NULL,'Анна','Иванова',1,'Оператор приема',NULL,NULL,'2026-11-15 08:57:36','2026-11-15 08:57:36','Петровна','0',NULL,NULL,NULL,'2f1e0b7f89ae3c497',NULL,NULL,NULL),('7955b99c06cb6e2fa',1,'testuser1','regular','$2y$12$ZQ5YSxVMqPVa1pOLG.zGYOapckOdwD6zkC9WxKP9kO1C5di6Gfg9m',1,NULL,NULL,NULL,'Тест','Тестов',1,NULL,NULL,NULL,'2026-11-15 08:58:17','2026-11-15 09:02:23',NULL,'5dd79e87a68ac0103',NULL,NULL,NULL,'2f1e0b7f89ae3c497',NULL,NULL,NULL),('969a2b32b83dc0060',1,'testuser3','regular','$2y$12$mF/4vt1JFQMScqr98weVGugeNKTlMhhEYCwbG3OkualVrl..WXShq',1,NULL,NULL,NULL,'Тест','Третий',1,'Исполнитель',NULL,NULL,'2026-11-15 08:58:34','2026-11-15 09:02:23','Тестович','eb8c2d856157f678d',NULL,NULL,NULL,'2f1e0b7f89ae3c497',NULL,NULL,NULL),('b276a07c9d460eef6',0,'petrov','regular','$2y$12$XaFYCeiiJCOCBlCx814wy.XNZ1O4oFnLQo5JvrTZwMAeJN7yHpQvC',1,NULL,NULL,NULL,'Игорь','Петров',1,'Руководитель сервисного отдела',NULL,NULL,'2026-11-15 08:57:38','2026-11-15 08:57:38','Викторович','0',NULL,NULL,NULL,'2f1e0b7f89ae3c497',NULL,NULL,NULL),('ee34b5ae997ac8935',0,'sidorov','regular','$2y$12$vIhhKFCoQl6LA3IRG4MSounRXBIdvOBXoekxvg2wD/CulY0EbqE/2',1,NULL,NULL,NULL,'Максим','Сидоров',1,'Исполнитель',NULL,NULL,'2026-11-15 08:57:36','2026-11-15 08:57:36','Олегович','0',NULL,NULL,NULL,'2f1e0b7f89ae3c497',NULL,NULL,NULL),('system',0,'system','system',NULL,0,NULL,NULL,NULL,NULL,'System',1,NULL,NULL,NULL,'2026-11-15 08:56:59','2026-11-15 08:56:59',NULL,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_data`
--

DROP TABLE IF EXISTS `user_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_data` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `auth2_f_a` tinyint NOT NULL DEFAULT '0',
  `auth2_f_a_method` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth2_f_a_totp_secret` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth2_f_a_email_address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_data`
--

LOCK TABLES `user_data` WRITE;
/*!40000 ALTER TABLE `user_data` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_reaction`
--

DROP TABLE IF EXISTS `user_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_reaction` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_PARENT_USER_TYPE` (`parent_id`,`parent_type`,`user_id`,`type`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_PARENT` (`parent_id`,`parent_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_reaction`
--

LOCK TABLES `user_reaction` WRITE;
/*!40000 ALTER TABLE `user_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_reaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_state`
--

DROP TABLE IF EXISTS `user_state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_state` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email_filters_version_number` bigint DEFAULT '0',
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_state`
--

LOCK TABLES `user_state` WRITE;
/*!40000 ALTER TABLE `user_state` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_state` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_working_time_range`
--

DROP TABLE IF EXISTS `user_working_time_range`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user_working_time_range` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `working_time_range_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_USER_ID_WORKING_TIME_RANGE_ID` (`user_id`,`working_time_range_id`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_WORKING_TIME_RANGE_ID` (`working_time_range_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_working_time_range`
--

LOCK TABLES `user_working_time_range` WRITE;
/*!40000 ALTER TABLE `user_working_time_range` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_working_time_range` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook`
--

DROP TABLE IF EXISTS `webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `event` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(512) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `entity_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secret_key` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `skip_own` tinyint NOT NULL DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_EVENT` (`event`),
  KEY `IDX_ENTITY_TYPE_TYPE` (`entity_type`,`type`),
  KEY `IDX_ENTITY_TYPE_FIELD` (`entity_type`,`field`),
  KEY `IDX_USER_ID` (`user_id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook`
--

LOCK TABLES `webhook` WRITE;
/*!40000 ALTER TABLE `webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_event_queue_item`
--

DROP TABLE IF EXISTS `webhook_event_queue_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_event_queue_item` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `number` bigint unsigned NOT NULL AUTO_INCREMENT,
  `event` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `is_processed` tinyint NOT NULL DEFAULT '0',
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_TARGET` (`target_id`,`target_type`),
  KEY `IDX_USER_ID` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_event_queue_item`
--

LOCK TABLES `webhook_event_queue_item` WRITE;
/*!40000 ALTER TABLE `webhook_event_queue_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook_event_queue_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webhook_queue_item`
--

DROP TABLE IF EXISTS `webhook_queue_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webhook_queue_item` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `deleted` tinyint DEFAULT '0',
  `number` bigint unsigned NOT NULL AUTO_INCREMENT,
  `event` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `data` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `status` varchar(7) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Pending',
  `processed_at` datetime DEFAULT NULL,
  `attempts` int DEFAULT '0',
  `process_at` datetime DEFAULT NULL,
  `webhook_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_NUMBER` (`number`),
  KEY `IDX_WEBHOOK_ID` (`webhook_id`),
  KEY `IDX_TARGET` (`target_id`,`target_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webhook_queue_item`
--

LOCK TABLES `webhook_queue_item` WRITE;
/*!40000 ALTER TABLE `webhook_queue_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `webhook_queue_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `working_time_calendar`
--

DROP TABLE IF EXISTS `working_time_calendar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `working_time_calendar` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `time_zone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `weekday0` tinyint NOT NULL DEFAULT '0',
  `weekday1` tinyint NOT NULL DEFAULT '1',
  `weekday2` tinyint NOT NULL DEFAULT '1',
  `weekday3` tinyint NOT NULL DEFAULT '1',
  `weekday4` tinyint NOT NULL DEFAULT '1',
  `weekday5` tinyint NOT NULL DEFAULT '1',
  `weekday6` tinyint NOT NULL DEFAULT '0',
  `weekday0_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `weekday1_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `weekday2_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `weekday3_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `weekday4_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `weekday5_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `weekday6_time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `working_time_calendar`
--

LOCK TABLES `working_time_calendar` WRITE;
/*!40000 ALTER TABLE `working_time_calendar` DISABLE KEYS */;
/*!40000 ALTER TABLE `working_time_calendar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `working_time_calendar_working_time_range`
--

DROP TABLE IF EXISTS `working_time_calendar_working_time_range`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `working_time_calendar_working_time_range` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `working_time_calendar_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `working_time_range_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_WORKING_TIME_CALENDAR_ID_WORKING_TIME_RANGE_ID` (`working_time_calendar_id`,`working_time_range_id`),
  KEY `IDX_WORKING_TIME_CALENDAR_ID` (`working_time_calendar_id`),
  KEY `IDX_WORKING_TIME_RANGE_ID` (`working_time_range_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `working_time_calendar_working_time_range`
--

LOCK TABLES `working_time_calendar_working_time_range` WRITE;
/*!40000 ALTER TABLE `working_time_calendar_working_time_range` DISABLE KEYS */;
/*!40000 ALTER TABLE `working_time_calendar_working_time_range` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `working_time_range`
--

DROP TABLE IF EXISTS `working_time_range`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `working_time_range` (
  `id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `time_ranges` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `date_start` date DEFAULT NULL,
  `date_end` date DEFAULT NULL,
  `type` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT 'Non-working',
  `description` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `modified_at` datetime DEFAULT NULL,
  `created_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `modified_by_id` varchar(17) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_TYPE_RANGE` (`type`,`date_start`,`date_end`),
  KEY `IDX_TYPE` (`type`),
  KEY `IDX_CREATED_BY_ID` (`created_by_id`),
  KEY `IDX_MODIFIED_BY_ID` (`modified_by_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `working_time_range`
--

LOCK TABLES `working_time_range` WRITE;
/*!40000 ALTER TABLE `working_time_range` DISABLE KEYS */;
/*!40000 ALTER TABLE `working_time_range` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-11-15  9:28:18
